<td class="logo">
	<?php
	$logo_src = \EM_Pro\Printables\PDFs::get_logo_src();
	if ( $logo_src ) {
		echo '<img src="' . esc_attr( $logo_src ) . '" style="width:200px;">';
	} else {
		echo esc_html( get_option( 'dbem_bookings_pdf_logo_alt', get_bloginfo( 'name' ) ) );
	}
	?>
</td>

<?php
/* @var $EM_Event EM_Event */
/* @var $EM_Multiple_Booking EM_Booking */

do_action( 'em_checkout_form_before_buttons', $EM_Multiple_Booking ); //do not delete
?>
	<div class="em-booking-section em-booking-form-buttons em-booking-buttons">
		<?php do_action('em_checkout_form_buttons_header', $EM_Multiple_Booking); //do not delete ?>
		<?php
		// Use MB-specific submit button label when configured, falling back to the generic bookings submit button text.
		$mb_submit_label  = get_option('dbem_multiple_bookings_submit_button');
		$mb_submit_free   = $mb_submit_label !== '' ? $mb_submit_label : get_option('dbem_bookings_submit_button');
		$mb_submit_button = get_option('dbem_bookings_submit_button');
		?>
		<?php if( preg_match('/https?:\/\//', $mb_submit_button) ): //Settings have an image url (we assume). Use it here as the button.?>
			<input type="image" src="<?php echo $mb_submit_button; ?>" class="em-form-submit em-booking-submit" alt="<?php esc_html__('Booking Submit Button', 'events-manager'); ?>">
		<?php else: //Display normal submit button ?>
			<?php
			// show free or paid button by default
			$button_text = $EM_Multiple_Booking && $EM_Multiple_Booking->get_price_base() > 0 ?  str_replace('%s', $EM_Multiple_Booking->get_price(true), get_option('dbem_bookings_submit_button_paid')) : $mb_submit_free;
			?>
			<input type="submit" class="em-form-submit em-booking-submit em-button em-button-1" value="<?php echo esc_attr($button_text); ?>"
			       data-text-free="<?php echo esc_attr($mb_submit_free); ?>"
			       data-text-payment="<?php echo esc_attr(get_option('dbem_bookings_submit_button_paid')); ?>"
			       data-text-processing="<?php echo esc_attr(get_option('dbem_bookings_submit_button_processing')); ?>">
		<?php endif; ?>
		<?php do_action( 'em_checkout_form_buttons_footer', $EM_Multiple_Booking ); //do not delete ?>
	</div>
<?php
do_action( 'em_checkout_form_footer_after_buttons', $EM_Multiple_Booking ); //do not delete
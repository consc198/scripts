<?php
/**
 * The standalone signing page body: a thank-you state once nothing is outstanding, or a checklist —
 * one box per outstanding signature (booking-form fields, then each attendee's grouped under their ticket) —
 * the way DocuSign presents one envelope. The box itself is the trigger: clicking it opens the shared modal
 * (which carries the consent document and the pad); once signed the box ticks and offers an edit pencil to
 * re-open. Nothing renders inline, and the field's own modal/inline display option is ignored so every
 * signature behaves identically. Submit stays disabled until every box is ticked.
 *
 * @var \EM_Booking            $EM_Booking
 * @var bool                   $done
 * @var \EM_Booking_Form|false $EM_Form
 * @var \EM_Form|false         $EM_Attendee_Form
 * @var array                  $outstanding  array( 'booking' => array, 'attendees' => array ) from Signatures::outstanding()
 */
use EM\Bookings\Signatures;

$has_outstanding = ! empty( $outstanding['booking'] ) || ! empty( $outstanding['attendees'] );
?>
<div class="<?php em_template_classes( 'view-container' ); ?>" data-view="signing">
<div class="<?php em_template_classes( 'signing-wrap' ); ?>">
	<?php if ( $done || ! $has_outstanding ) : ?>
		<h1><?php esc_html_e( 'Thank you — your signature has been recorded.', 'em-pro' ); ?></h1>
		<p><?php esc_html_e( 'A copy has been emailed to you for your records.', 'em-pro' ); ?></p>
	<?php else : ?>
		<?php
		$total = count( $outstanding['booking'] );
		foreach ( $outstanding['attendees'] as $info ) {
			$total += count( $info['fields'] );
		}

		// Group outstanding attendee signatures by ticket, so the checklist reads ticket -> attendee -> signature.
		$ticket_groups = array();
		foreach ( $outstanding['attendees'] as $tbid => $info ) {
			$tb     = $info['ticket_booking'];
			$ticket = ( $tb && method_exists( $tb, 'get_ticket' ) ) ? $tb->get_ticket() : null;
			$tid    = ( $ticket && ! empty( $ticket->ticket_id ) ) ? $ticket->ticket_id : 0;
			if ( ! isset( $ticket_groups[ $tid ] ) ) {
				$ticket_groups[ $tid ] = array(
					'name'      => ( $ticket && ! empty( $ticket->ticket_name ) ) ? $ticket->ticket_name : __( 'Attendees', 'em-pro' ),
					'attendees' => array(),
				);
			}
			$ticket_groups[ $tid ]['attendees'][] = array( 'tbid' => $tbid, 'fields' => $info['fields'] );
		}

		// One box renderer, shared by booking-form and attendee signatures. $field['name'] must be set by the caller.
		$render_box = function ( $title, $field, $EM_Form ) {
			$field['options_signature_display'] = 'modal_consent'; // ignore the field's setting: consent in the modal, nothing inline
			?>
			<div class="em-signing-item" data-signed="0" role="listitem">
				<button type="button" class="em-signing-item-box" data-nostyle>
					<span class="em-signing-item-check" aria-hidden="true"></span>
					<span class="em-signing-item-title"><?php echo esc_html( $title ); ?></span>
					<span class="em-signing-item-state"><?php esc_html_e( 'Not signed', 'em-pro' ); ?></span>
					<span class="em-signing-item-edit" aria-hidden="true" hidden title="<?php esc_attr_e( 'Edit signature', 'em-pro' ); ?>">&#9998;</span>
				</button>
				<div class="em-signing-item-field"><?php Signatures::output_field_input( $EM_Form, $field, null ); ?></div>
			</div>
			<?php
		};
		?>
		<h1><?php esc_html_e( 'Please provide your signature', 'em-pro' ); ?></h1>
		<p class="em-signing-intro"><?php echo esc_html( sprintf( _n( 'Click the item below to read and sign it.', 'Click each of the %d items below to read and sign them.', $total, 'em-pro' ), $total ) ); ?></p>
		<form method="post" class="em-signing-form">
			<?php wp_nonce_field( 'em_sign_' . $EM_Booking->booking_id ); ?>
			<div class="em-signing-list" role="list">
				<?php foreach ( $outstanding['booking'] as $fid => $field ) : ?>
					<?php
					$field['name'] = $fid; // flat name on the standalone page
					$render_box( $field['label'], $field, $EM_Form );
					?>
				<?php endforeach; ?>

				<?php foreach ( $ticket_groups as $group ) : ?>
					<div class="em-signing-ticket">
						<h2 class="em-signing-ticket-title"><?php echo esc_html( $group['name'] ); ?></h2>
						<?php foreach ( $group['attendees'] as $ai => $att ) : ?>
							<div class="em-signing-attendee-group">
								<h3 class="em-signing-attendee-title"><?php echo esc_html( sprintf( __( 'Attendee %d', 'em-pro' ), $ai + 1 ) ); ?></h3>
								<?php foreach ( $att['fields'] as $fid => $field ) : ?>
									<?php
									$field['name'] = 'att[' . $att['tbid'] . '][' . $fid . ']'; // nests under this attendee's request path
									$render_box( $field['label'], $field, $EM_Attendee_Form );
									?>
								<?php endforeach; ?>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endforeach; ?>
			</div>
			<p class="em-signing-actions input">
				<button type="submit" class="button em-signing-submit" disabled><?php esc_html_e( 'Submit signatures', 'em-pro' ); ?></button>
				<span class="em-signing-progress" aria-live="polite"></span>
			</p>
		</form>
		<script>
		( function () {
			var form = document.querySelector( '.em-signing-form' );
			if ( ! form ) { return; }
			var L = {
				signed: <?php echo wp_json_encode( __( 'Signed', 'em-pro' ) ); ?>,
				notSigned: <?php echo wp_json_encode( __( 'Not signed', 'em-pro' ) ); ?>,
				progress: <?php echo wp_json_encode( __( '%1$d of %2$d signed', 'em-pro' ) ); ?>
			};
			var items = [].slice.call( form.querySelectorAll( '.em-signing-item' ) );
			var submit = form.querySelector( '.em-signing-submit' );
			var progress = form.querySelector( '.em-signing-progress' );
			var total = items.length;

			function isSigned( item ) { var d = item.querySelector( '.em-signature-data' ); return !! ( d && d.value ); }

			// The box is the trigger: clicking it opens the field's shared modal (which carries the consent + pad).
			items.forEach( function ( item ) {
				var box = item.querySelector( '.em-signing-item-box' );
				if ( box ) {
					box.addEventListener( 'click', function () {
						var trigger = item.querySelector( '.em-signature-trigger' );
						if ( trigger ) { trigger.click(); }
					} );
				}
			} );

			function refresh() {
				var signed = 0;
				items.forEach( function ( item ) {
					var s = isSigned( item );
					item.dataset.signed = s ? '1' : '0';
					item.classList.toggle( 'is-signed', s );
					var state = item.querySelector( '.em-signing-item-state' );
					if ( state ) { state.textContent = s ? L.signed : L.notSigned; }
					var edit = item.querySelector( '.em-signing-item-edit' );
					if ( edit ) { edit.hidden = ! s; }
					if ( s ) { signed++; }
				} );
				if ( progress ) { progress.textContent = L.progress.replace( '%1$d', signed ).replace( '%2$d', total ); }
				if ( submit ) { submit.disabled = signed < total; }
			}

			// em-signature.js flips `.em-signature-is-signed` on the field's trigger when a signature is applied.
			var mo = new MutationObserver( function ( muts ) {
				for ( var i = 0; i < muts.length; i++ ) {
					if ( 'class' === muts[ i ].attributeName ) { refresh(); return; }
				}
			} );
			form.querySelectorAll( '.em-signature-trigger' ).forEach( function ( tr ) {
				mo.observe( tr, { attributes: true, attributeFilter: [ 'class' ] } );
			} );

			refresh();
		} )();
		</script>
	<?php endif; ?>
</div>
</div>

<?php
/**
 * The signature field: the consent document (when set), the click-to-sign area for modal/full-page
 * display modes or the inline capture host, the caption and the hidden inputs the JS writes into.
 *
 * @var string $field_id
 * @var string $field_name
 * @var string $name_field    nested name for the typed-name sub-input
 * @var string $esign_field   nested name for the acknowledgement sub-input
 * @var string $doc_field     nested name for the consent-document hash sub-input
 * @var string $doc_hash      sha256 of the canonical consent as displayed here
 * @var string $modes         draw|type|both
 * @var string $display       modal|modal_consent|inline
 * @var string $version
 * @var string $consent       canonical consent (placeholders resolved, wp_kses_post'd, pre-wpautop)
 * @var string $esign_text
 * @var bool   $require_ack
 * @var string $label
 * @var bool   $already
 * @var string $preview_url
 * @var array  $field_value
 */
use EM\Bookings\Signatures;
?>
<div class="em-signature-field" data-field-id="<?php echo esc_attr( $field_id ); ?>" data-modes="<?php echo esc_attr( $modes ); ?>" data-display="<?php echo esc_attr( $display ); ?>" data-label="<?php echo esc_attr( $label ); ?>" data-esign="<?php echo esc_attr( $esign_text ); ?>" data-require-ack="<?php echo $require_ack ? '1' : '0'; ?>" data-version="<?php echo esc_attr( $version ); ?>" data-preview="<?php echo $already ? esc_url( $preview_url ) : ''; ?>">
	<?php if ( $consent !== '' ) : ?>
		<?php // For "modal with consent text" the wording lives in the pop-up, so it's carried here hidden and moved in when the modal opens. ?>
		<div class="em-signature-consent"<?php echo $display === 'modal_consent' ? ' hidden' : ''; ?>>
			<?php echo wpautop( $consent ); // already placeholder-resolved + wp_kses_post'd; wpautop is presentation only, outside the hashed canonical ?>
		</div>
	<?php endif; ?>
	<?php if ( $display === 'inline' ) : ?>
		<div class="em-signature-inline"></div>
	<?php else : ?>
		<button type="button" class="em-signature-trigger<?php echo $already ? ' em-signature-is-signed' : ''; ?>" aria-haspopup="dialog">
			<span class="em-signature-trigger-empty"<?php echo $already ? ' hidden' : ''; ?>>
				<span class="em-signature-icon" aria-hidden="true">&#9998;</span>
				<span class="em-signature-trigger-label"><?php esc_html_e( 'Click to sign', 'em-pro' ); ?></span>
			</span>
			<span class="em-signature-trigger-signed"<?php echo $already ? '' : ' hidden'; ?>>
				<span class="em-signature-edit" aria-hidden="true" title="<?php esc_attr_e( 'Edit signature', 'em-pro' ); ?>">&#9998;</span>
				<img class="em-signature-preview"<?php echo $already ? ' src="' . esc_url( $preview_url ) . '"' : ''; ?> alt="<?php esc_attr_e( 'Your signature', 'em-pro' ); ?>" />
			</span>
		</button>
	<?php endif; ?>
	<p class="em-signature-caption"><small><?php echo $already ? esc_html( Signatures::caption( $field_value ) ) : ''; ?></small></p>
	<input type="hidden" name="<?php echo esc_attr( $field_name ); ?>" class="em-signature-data" value="" />
	<input type="hidden" name="<?php echo esc_attr( $name_field ); ?>" class="em-signature-name" value="" />
	<input type="hidden" name="<?php echo esc_attr( $esign_field ); ?>" class="em-signature-esign-input" value="" />
	<?php if ( $doc_hash !== '' ) : ?>
		<input type="hidden" name="<?php echo esc_attr( $doc_field ); ?>" class="em-signature-doc" value="<?php echo esc_attr( $doc_hash ); ?>" />
	<?php endif; ?>
</div>

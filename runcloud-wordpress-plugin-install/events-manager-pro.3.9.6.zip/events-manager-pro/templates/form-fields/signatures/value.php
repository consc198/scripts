<?php
/**
 * A signature formatted for admin booking screens and HTML emails. When unsigned it reads
 * "Not signed", with a sign-now link to the booking's signing page where one is available.
 * When signed it shows the image with the full verifiable audit envelope tucked behind an
 * "Advanced information" disclosure (native <details>, so the caret and toggle need no JS).
 *
 * @var bool   $signed
 * @var string $url       The signature image URL (signed only).
 * @var string $cert_url  The certificate PDF download URL (signed only; '' when none generated).
 * @var array  $envelope  Ordered label => value pairs from Signatures::envelope() (signed only).
 * @var string $sign_url  Signing-page URL for this booking (unsigned only; '' when out of scope).
 */
$cert_url = $cert_url ?? '';
?>
<?php if ( ! $signed ) : ?>
	<span class="em-signature-unsigned">
		<?php esc_html_e( 'Not signed', 'em-pro' ); ?>
		<?php if ( $sign_url !== '' ) : ?>
			&mdash; <a class="em-signature-sign-now" href="<?php echo esc_url( $sign_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Sign now', 'em-pro' ); ?></a>
		<?php endif; ?>
	</span>
<?php else : ?>
	<div class="em-signature-view">
		<img src="<?php echo esc_url( $url ); ?>" alt="<?php esc_attr_e( 'Signature', 'em-pro' ); ?>" style="max-width:250px;border:1px solid #ccc;display:block;margin-bottom:.35em;" />
		<?php if ( $cert_url !== '' ) : ?>
			<a class="em-signature-certificate" href="<?php echo esc_url( $cert_url ); ?>" target="_blank" rel="noopener" style="font-size:90%;display:inline-block;margin-bottom:.35em;"><?php esc_html_e( 'Certificate (PDF)', 'em-pro' ); ?></a>
		<?php endif; ?>
		<details class="em-signature-advanced">
			<summary style="cursor:pointer;font-size:90%;opacity:.85;"><?php esc_html_e( 'Advanced information', 'em-pro' ); ?></summary>
			<table class="em-signature-envelope" style="font-size:90%;border-collapse:collapse;margin-top:.35em;">
				<?php foreach ( $envelope as $label => $val ) : ?>
					<?php if ( $val === '' ) { continue; } ?>
					<tr>
						<th style="text-align:left;padding-right:1em;font-weight:600;vertical-align:top;"><?php echo esc_html( $label ); ?></th>
						<td><?php echo esc_html( $val ); ?></td>
					</tr>
				<?php endforeach; ?>
			</table>
		</details>
	</div>
<?php endif; ?>

<?php
/**
 * Signature certificate of completion — the dompdf HTML source. Rendered only from a sealed bundle
 * (EM\Bookings\Certificate::view_args), never from a fresh render of the consent text.
 *
 * @var string $site_name
 * @var string $title
 * @var string $event_name
 * @var string $consent_text
 * @var string $signature_img  data: URI, or '' when the image is unavailable
 * @var array  $envelope       label => value rows
 * @var string $seal
 * @var string $booking_uuid
 * @var string $generated_utc
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<style>
	body { font-family: 'DejaVu Sans', sans-serif; color: #222; font-size: 12px; line-height: 1.5; }
	h1 { font-size: 18px; margin: 0 0 2px; }
	.muted { color: #777; }
	.section { margin: 18px 0; }
	.label { font-weight: bold; display: block; margin-bottom: 4px; }
	.consent { border: 1px solid #dddddd; padding: 12px; white-space: pre-wrap; }
	.sig { border: 1px solid #dddddd; padding: 8px; }
	.sig img { max-height: 120px; }
	table.envelope { width: 100%; border-collapse: collapse; }
	table.envelope td { padding: 4px 8px; border-bottom: 1px solid #eeeeee; vertical-align: top; }
	table.envelope td.k { width: 175px; color: #555555; }
	.seal { margin-top: 16px; font-size: 10px; color: #777777; word-break: break-all; }
</style>
</head>
<body>
	<h1><?php echo esc_html( $title ); ?></h1>
	<div class="muted"><?php echo esc_html( $site_name ); ?></div>
	<?php if ( $event_name !== '' ) : ?>
		<div class="muted"><?php echo esc_html( $event_name ); ?></div>
	<?php endif; ?>

	<?php if ( $consent_text !== '' ) : ?>
	<div class="section">
		<span class="label"><?php esc_html_e( 'Document signed', 'em-pro' ); ?></span>
		<div class="consent"><?php echo wp_kses_post( $consent_text ); ?></div>
	</div>
	<?php endif; ?>

	<?php if ( $signature_img !== '' ) : ?>
	<div class="section">
		<span class="label"><?php esc_html_e( 'Signature', 'em-pro' ); ?></span>
		<div class="sig"><img src="<?php echo esc_attr( $signature_img ); ?>" alt="" /></div>
	</div>
	<?php endif; ?>

	<div class="section">
		<span class="label"><?php esc_html_e( 'Certificate of completion', 'em-pro' ); ?></span>
		<table class="envelope">
			<?php foreach ( $envelope as $k => $v ) : ?>
			<tr><td class="k"><?php echo esc_html( $k ); ?></td><td><?php echo esc_html( $v ); ?></td></tr>
			<?php endforeach; ?>
		</table>
	</div>

	<div class="seal">
		<?php echo esc_html( sprintf( __( 'Record seal: %s', 'em-pro' ), $seal ) ); ?><br />
		<?php echo esc_html( sprintf( __( 'Booking reference: %s', 'em-pro' ), $booking_uuid ) ); ?><br />
		<?php echo esc_html( sprintf( __( 'Certificate generated: %s UTC', 'em-pro' ), $generated_utc ) ); ?>
	</div>
</body>
</html>

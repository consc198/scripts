<?php
/**
 * Opening markup for the standalone signing page (and its error state) — a bare document shell,
 * not the site's own header, so a signer reaches nothing else about the booking.
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php wp_head(); ?>
</head>
<body class="em-signing-page">

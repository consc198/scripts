<?php
/**
 * The standalone signing page's error state — an invalid, expired or tampered link.
 *
 * @var string $message
 */
?>
<div class="<?php em_template_classes( 'view-container' ); ?>" data-view="signing">
<div class="<?php em_template_classes( 'signing-wrap' ); ?>">
	<h1><?php echo esc_html( $message ); ?></h1>
</div>
</div>

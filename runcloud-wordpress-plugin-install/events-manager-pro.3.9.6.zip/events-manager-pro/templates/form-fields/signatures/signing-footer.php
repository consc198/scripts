<?php
/**
 * Closing markup for the standalone signing page (and its error state).
 */
wp_footer();
?>
</body>
</html>

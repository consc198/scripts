<?php
/**
 * Events Manager Pro — Gutenberg blocks bootstrap.
 *
 * Registers Pro-only dynamic blocks. Render is delegated to the existing
 * widget classes / Pro rendering functions so there's one source of truth.
 *
 * The "events-manager" block category is registered by core EM's bootstrap
 * (blocks/_bootstrap.php). This file just adds blocks into it.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class EM_Pro_Blocks {

	public static function init() {
		add_action( 'init', [ __CLASS__, 'register_blocks' ], 20 );
	}

	public static function register_blocks() {
		$build_dir = __DIR__ . '/build';

		if ( file_exists( $build_dir . '/multiple-bookings-cart/block.json' ) && class_exists( 'EM_Multiple_Bookings_Widget' ) ) {
			register_block_type( $build_dir . '/multiple-bookings-cart', [
				'render_callback' => [ __CLASS__, 'render_multiple_bookings_cart' ],
			] );
		}
	}

	public static function render_multiple_bookings_cart( $attrs ) {
		if ( ! class_exists( 'EM_Multiple_Bookings_Widget' ) ) {
			return '';
		}
		$widget = new EM_Multiple_Bookings_Widget();
		$args = [
			'before_widget' => '',
			'after_widget'  => '',
			'before_title'  => '<h3 class="wp-block-events-manager__title">',
			'after_title'   => '</h3>',
		];
		ob_start();
		$widget->widget( $args, (array) $attrs );
		return ob_get_clean();
	}
}

EM_Pro_Blocks::init();

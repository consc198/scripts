# Events Manager Pro MCP Setup

Events Manager Pro adds Pro-specific Abilities for coupons, transactions, attendance, and RSVP management. These abilities use the same WordPress MCP Adapter setup as Events Manager.

Install and configure the MCP Adapter using the Events Manager guide first:

```text
wp-content/plugins/events-manager/docs/mcp/README.md
```

That guide includes the Events > Settings > General > AI / MCP Setup box, the customer-facing MCP Server URL, MCP Adapter installer UX, readiness diagnostics, least-privilege role recipes, downloadable AI agent handoff profiles, and advanced fallback setup examples for Claude Desktop, Claude Code, Codex, Cursor, VS Code, and ChatGPT. When Pro is active, it contributes Pro-specific ability groups, diagnostics, role recipes, connection profile metadata, and security notes to the same setup box.

## What Pro Exposes

Events Manager Pro abilities are registered with:

- `meta.show_in_rest: true`, so they are visible through `wp-abilities/v1`.
- `meta.mcp.public: true`, so the MCP Adapter default server can discover and execute them.
- WordPress capability checks, so the MCP user can only do what their WordPress account is allowed to do.

Pro abilities include:

- Coupons: list, get, create, update, delete.
- Transactions: list, get, delete.
- Attendance: get and set ticket check-in/check-out status.
- RSVP: get and set booking RSVP status.

Gateway callback routes are documented in OpenAPI, but are not exposed as Abilities or MCP tools because they are payment-system/browser callbacks, not agent-facing operations.

## One-URL Customer Flow

The base Events Manager setup now leads with the MCP Server URL. That is the only value a customer should need when their MCP client and site support OAuth browser approval.

Pro does not add a separate MCP URL. Pro abilities are discovered through the same MCP Adapter server URL after Events Manager Pro registers its abilities.

Do not pass Pro credentials, Application Passwords, or bearer tokens in the URL. If an MCP client cannot use OAuth yet, use the advanced Application Password fallback in the base Events Manager setup box.

## Setup Box Additions

When Events Manager Pro is active, the base Events Manager setup box adds:

- A Pro readiness diagnostic so administrators can see that Pro abilities are loaded.
- A Pro commerce and attendance least-privilege recipe using `manage_bookings` and `manage_others_bookings`.
- Pro metadata in the downloaded AI agent handoff profile, including the `emp_api_ability_mcp_public` filter and Pro feature areas.
- Extra agent safety guidance for coupon, transaction, RSVP, and attendance changes.

## Disable Pro MCP Exposure

Disable all Events Manager Pro abilities from the MCP Adapter default server:

```php
add_filter( 'emp_api_ability_mcp_public', '__return_false' );
```

Or selectively disable destructive Pro abilities:

```php
add_filter( 'emp_api_ability_mcp_public', function( $public, $name, $annotations ) {
	return empty( $annotations['destructive'] );
}, 10, 3 );
```

## Customer Setup Notes

- The WordPress user or OAuth grant supplied to the AI agent must have the required Events Manager Pro permissions.
- Coupon and transaction operations require booking management permissions.
- Attendance operations require permission to manage the related ticket booking.
- RSVP operations require either booking management permission or ownership of the booking plus RSVP change permission.
- If Pro features are disabled, their related REST routes and abilities may not be useful even though the API layer is present.

## References

- Events Manager MCP setup: `wp-content/plugins/events-manager/docs/mcp/README.md`
- WordPress MCP Adapter guide: https://developer.wordpress.org/news/2026/02/from-abilities-to-ai-agents-introducing-the-wordpress-mcp-adapter/
- MCP Adapter releases: https://github.com/WordPress/mcp-adapter/releases

/**
 * Events Manager Pro — signature field.
 * A field shows a click-to-sign area (modal / modal-with-consent display) or hosts the pad
 * directly (inline display). Both paths share one capture core (createPad): dependency-free
 * canvas drawing (mouse + touch) with quadratic smoothing and hi-DPI backing store, a typed
 * mode that renders the name in a chosen signature font, and an e-sign acknowledgement gate.
 * The modal commits on an Apply button; inline syncs to the field live.
 */
( function () {
	'use strict';

	// This file can legitimately arrive twice (WordPress enqueue on the signing page vs EM's
	// asset loader on booking forms, at different ?v= URLs). Two instances means two shared
	// modals and two click handlers, so one dialog is left open behind the other. First one wins.
	if ( window.emSignatureLoaded ) {
		return;
	}
	window.emSignatureLoaded = true;

	// Bundled OFL signature faces, declared in em-signature.css.
	var FONTS = {
		dancing: 'EM Signature Dancing',
		vibes: 'EM Signature Vibes',
		caveat: 'EM Signature Caveat'
	};

	var padSeq = 0; // namespaces each pad's radio groups so multiple pads never collide

	function L() {
		return ( window.EM && EM.signature ) || {};
	}

	/* ============================================================= capture core */

	// The shared capture surface markup: mode toggle, drawing pad, typed input, style picker.
	// `modes` is the field's setting (draw|type|both); radio groups are namespaced by `ns`.
	function captureMarkup( ns, modes ) {
		var typeOnly = modes === 'type';
		return '' +
			// data-nostyle opts every control out of pixelbones' aggressive `.input`-scoped !important rules
			// (labels, radios, buttons all match `:not([data-nostyle])`). The modal escapes those rules by
			// living outside the `.em.pixelbones.input` booking form; the inline pad sits inside it, so without
			// this the segmented control, clear button and typed field get clobbered.
			'<div class="em-signature-modes"' + ( modes === 'both' ? '' : ' hidden' ) + '>' +
				'<label><input type="radio" data-nostyle name="' + ns + '-m" value="draw"' + ( typeOnly ? '' : ' checked' ) + '> <span class="em-signature-mode-draw"></span></label>' +
				'<label><input type="radio" data-nostyle name="' + ns + '-m" value="type"' + ( typeOnly ? ' checked' : '' ) + '> <span class="em-signature-mode-type"></span></label>' +
			'</div>' +
			'<div class="em-signature-pad">' +
				'<canvas class="em-signature-canvas"></canvas>' +
				'<span class="em-signature-hint" aria-hidden="true"></span>' +
				'<button type="button" class="em-signature-pad-clear" data-nostyle><span class="em-icon em-icon-undo" aria-hidden="true"></span></button>' +
			'</div>' +
			'<input type="text" class="em-signature-typed" data-nostyle' + ( typeOnly ? '' : ' hidden' ) + '>' +
			'<div class="em-signature-styles"' + ( typeOnly ? '' : ' hidden' ) + '>' +
				'<label data-nostyle><input type="radio" data-nostyle name="' + ns + '-s" value="dancing" checked><span class="em-signature-style-preview" data-style="dancing"></span></label>' +
				'<label data-nostyle><input type="radio" data-nostyle name="' + ns + '-s" value="vibes"><span class="em-signature-style-preview" data-style="vibes"></span></label>' +
				'<label data-nostyle><input type="radio" data-nostyle name="' + ns + '-s" value="caveat"><span class="em-signature-style-preview" data-style="caveat"></span></label>' +
			'</div>';
	}

	// Wires the capture surface inside `root` and returns a controller. `opts.modes` is the
	// field's mode setting (used as the default when the mode bar is hidden); `opts.onChange`
	// fires whenever the mark changes so the host can update its gate (Apply / live sync).
	function createPad( root, opts ) {
		opts = opts || {};
		var l = L();
		var canvas = root.querySelector( '.em-signature-canvas' );
		var pad = root.querySelector( '.em-signature-pad' );
		var typed = root.querySelector( '.em-signature-typed' );
		var stylesEl = root.querySelector( '.em-signature-styles' );
		var modesEl = root.querySelector( '.em-signature-modes' );
		var clearBtn = root.querySelector( '.em-signature-pad-clear' );
		var ctx = canvas.getContext( '2d' );
		var drawing = false, ink = false, prev = null, lastMid = null, dpr = 1;
		canvas.style.touchAction = 'none'; // else touch scrolling swallows pointermove

		root.querySelector( '.em-signature-hint' ).textContent = l.hint || 'Sign here';
		root.querySelector( '.em-signature-mode-draw' ).textContent = l.draw || 'Draw';
		root.querySelector( '.em-signature-mode-type' ).textContent = l.type || 'Type';
		clearBtn.title = clearBtn.ariaLabel = l.clear || 'Clear'; // icon-only button, so the label is its only accessible name
		typed.placeholder = l.typeName || 'Type your full name';

		function emit() {
			if ( opts.onChange ) {
				opts.onChange();
			}
		}
		function setInk( on ) {
			ink = on;
			pad.classList.toggle( 'em-signature-has-ink', on );
			emit();
		}
		function applyCtx() {
			ctx.lineWidth = 2 * dpr;
			ctx.lineJoin = 'round';
			ctx.lineCap = 'round';
			ctx.strokeStyle = '#111';
			ctx.fillStyle = '#111';
		}
		// Backing store follows the CSS box at device-pixel resolution. Falls back to the design
		// size when the canvas has no layout yet (e.g. built while hidden), so a typed signature
		// still paints and exports rather than silently producing nothing.
		function sizeCanvas() {
			var rect = canvas.getBoundingClientRect();
			var cw = rect.width >= 10 ? rect.width : 600;
			var ch = rect.height >= 10 ? rect.height : 200;
			dpr = window.devicePixelRatio || 1;
			var w = Math.round( cw * dpr );
			var h = Math.round( ch * dpr );
			if ( canvas.width === w && canvas.height === h ) {
				return;
			}
			var snap = null;
			if ( ink ) {
				snap = document.createElement( 'canvas' );
				snap.width = canvas.width;
				snap.height = canvas.height;
				snap.getContext( '2d' ).drawImage( canvas, 0, 0 );
			}
			canvas.width = w;
			canvas.height = h;
			applyCtx();
			if ( snap ) {
				ctx.drawImage( snap, 0, 0, w, h );
			}
		}
		function mode() {
			var r = modesEl ? modesEl.querySelector( 'input:checked' ) : null;
			return r ? r.value : ( opts.modes === 'type' ? 'type' : 'draw' );
		}
		function styleKey() {
			var r = stylesEl.querySelector( 'input:checked' );
			return ( r && FONTS[ r.value ] ) ? r.value : 'dancing';
		}
		function updateStylePreviews() {
			var name = typed.value.trim() || ( l.yourName || 'Your name' );
			Array.prototype.forEach.call( stylesEl.querySelectorAll( '.em-signature-style-preview' ), function ( el ) {
				el.textContent = name;
			} );
		}
		function at( e ) {
			var r = canvas.getBoundingClientRect();
			return {
				x: ( e.clientX - r.left ) * ( canvas.width / r.width ),
				y: ( e.clientY - r.top ) * ( canvas.height / r.height )
			};
		}
		function paintTyped() {
			sizeCanvas();
			ctx.clearRect( 0, 0, canvas.width, canvas.height );
			var name = typed.value.trim();
			if ( name === '' ) {
				setInk( false );
				return;
			}
			var family = FONTS[ styleKey() ];
			var size = Math.round( canvas.height * 0.42 );
			var max = canvas.width - Math.round( 32 * dpr );
			ctx.font = size + 'px "' + family + '", cursive';
			while ( ctx.measureText( name ).width > max && size > 12 ) { // long names shrink to fit
				size -= 2;
				ctx.font = size + 'px "' + family + '", cursive';
			}
			ctx.textBaseline = 'middle';
			ctx.fillText( name, Math.round( 16 * dpr ), canvas.height / 2 );
			setInk( true );
		}
		// Canvas fillText silently falls back to a system face if the webfont isn't loaded yet, so
		// wait for it before painting, then repaint once it arrives.
		function renderTyped() {
			updateStylePreviews();
			var spec = '32px "' + FONTS[ styleKey() ] + '"';
			if ( document.fonts && document.fonts.load ) {
				document.fonts.load( spec ).then( paintTyped, paintTyped );
			} else {
				paintTyped();
			}
		}
		function clear() {
			ctx.clearRect( 0, 0, canvas.width, canvas.height );
			typed.value = '';
			updateStylePreviews();
			setInk( false );
		}
		// Draws an existing signature so editing shows what you're editing rather than a blank pad.
		function load( src ) {
			var img = new Image();
			img.onload = function () {
				sizeCanvas();
				ctx.clearRect( 0, 0, canvas.width, canvas.height );
				var s = Math.min( canvas.width / img.width, canvas.height / img.height );
				var w = img.width * s, h = img.height * s;
				ctx.drawImage( img, ( canvas.width - w ) / 2, ( canvas.height - h ) / 2, w, h );
				setInk( true );
			};
			img.src = src;
		}
		// The pad is visible in type mode too and doubles as a live preview of the rendered name.
		function showMode() {
			var m = mode();
			typed.hidden = m !== 'type';
			stylesEl.hidden = m !== 'type';
			pad.classList.toggle( 'em-signature-typing', m === 'type' );
			sizeCanvas();
		}

		canvas.addEventListener( 'pointerdown', function ( e ) {
			if ( mode() !== 'draw' ) {
				return;
			}
			sizeCanvas();
			drawing = true;
			prev = at( e );
			lastMid = prev;
			ctx.beginPath(); // a dot, so a tap still leaves a mark
			ctx.arc( prev.x, prev.y, ctx.lineWidth / 2, 0, Math.PI * 2 );
			ctx.fill();
			setInk( true );
			e.preventDefault();
		} );
		canvas.addEventListener( 'pointermove', function ( e ) {
			if ( ! drawing ) {
				return;
			}
			// quadratic curves through segment midpoints, so strokes read as ink not polylines
			var p = at( e );
			var mid = { x: ( prev.x + p.x ) / 2, y: ( prev.y + p.y ) / 2 };
			ctx.beginPath();
			ctx.moveTo( lastMid.x, lastMid.y );
			ctx.quadraticCurveTo( prev.x, prev.y, mid.x, mid.y );
			ctx.stroke();
			lastMid = mid;
			prev = p;
			e.preventDefault();
		} );
		window.addEventListener( 'pointerup', function () {
			drawing = false;
		} );
		clearBtn.addEventListener( 'click', clear );
		typed.addEventListener( 'input', renderTyped );
		stylesEl.addEventListener( 'change', renderTyped );
		if ( modesEl ) {
			modesEl.addEventListener( 'change', function () {
				clear();
				showMode();
				if ( mode() === 'type' ) {
					typed.focus();
				}
			} );
		}

		return {
			hasInk: function () { return ink; },
			mode: mode,
			typedName: function () { return typed.value.trim(); },
			toDataURL: function () { return canvas.toDataURL( 'image/png' ); },
			clear: clear,
			load: load,
			showMode: showMode,
			size: sizeCanvas,
			focusType: function () { typed.focus(); },
			// Resets to a chosen mode and (for type) name, leaving a blank pad. `render()` then
			// paints — the caller decides between a typed name, an existing image, or nothing.
			reset: function ( wanted, name ) {
				var r = modesEl && modesEl.querySelector( 'input[value="' + wanted + '"]' );
				if ( r ) {
					r.checked = true;
				}
				typed.value = wanted === 'type' ? ( name || '' ) : '';
				setInk( false );
				showMode();
			},
			render: renderTyped
		};
	}

	/* ==================================================================== modal */

	var modal = null;  // the shared em-modal element, built once
	var mUI = {};      // the modal's chrome elements
	var mPad = null;   // its capture-core controller
	var field = null;  // the field currently being signed via the modal
	var requireAck = true;

	function buildModal() {
		var l = L();
		var ns = 'em-sig-modal';
		// EM's shared modal (includes/js/src/parts/modal.js): the em pixelbones classes bring the
		// overlay, panel, close button, transitions and mobile handling; openModal/closeModal drive it.
		modal = document.createElement( 'div' );
		modal.className = 'em pixelbones em-modal em-signature-modal';
		modal.id = 'em-signature-modal';
		modal.innerHTML =
			'<div class="em-modal-popup">' +
				'<header>' +
					'<a class="em-close-modal" aria-label="Close"></a>' +
					'<div class="em-modal-title em-signature-modal-title"></div>' +
				'</header>' +
				'<div class="em-modal-content">' +
					'<div class="em-signature-modal-consent" hidden></div>' +
					'<div class="em-signature-capture">' + captureMarkup( ns, 'both' ) + '</div>' +
					'<div class="em-signature-actions"><span class="em-signature-version"></span></div>' +
					'<label class="em-signature-esign"><input type="checkbox" class="em-signature-esign-check"> <span class="em-signature-esign-text"></span></label>' +
					'<div class="em-signature-foot">' +
						'<button type="button" class="em-signature-cancel"></button>' +
						'<button type="button" class="em-signature-apply" disabled></button>' +
					'</div>' +
				'</div>' +
			'</div>';
		document.body.appendChild( modal );

		mUI = {
			title: modal.querySelector( '.em-signature-modal-title' ),
			consent: modal.querySelector( '.em-signature-modal-consent' ),
			modes: modal.querySelector( '.em-signature-modes' ),
			version: modal.querySelector( '.em-signature-version' ),
			esignRow: modal.querySelector( '.em-signature-esign' ),
			esign: modal.querySelector( '.em-signature-esign-check' ),
			esignText: modal.querySelector( '.em-signature-esign-text' ),
			apply: modal.querySelector( '.em-signature-apply' ),
			cancel: modal.querySelector( '.em-signature-cancel' )
		};
		mUI.cancel.textContent = l.cancel || 'Cancel';
		mUI.apply.textContent = l.apply || 'Apply signature';

		mPad = createPad( modal.querySelector( '.em-signature-capture' ), { modes: 'both', onChange: updateApply } );

		mUI.esign.addEventListener( 'change', updateApply );
		mUI.apply.addEventListener( 'click', commit );
		mUI.cancel.addEventListener( 'click', function () { closeModal( modal ); } );
		// The close icon and backdrop are handled by em-modal's own delegated click handlers.
		modal.addEventListener( 'em_modal_close', function () {
			// em-modal fires this ~500ms after closing; if another field was opened in that window
			// the modal is active again, so don't steal focus back or clear the newly-opened field.
			if ( modal.classList.contains( 'active' ) ) {
				return;
			}
			if ( field ) {
				var trigger = field.querySelector( '.em-signature-trigger' );
				if ( trigger ) {
					trigger.focus();
				}
			}
			field = null;
		} );
		return modal;
	}

	// Apply stays disabled until there's a mark and, where the field asks for it, the acknowledgement
	// is ticked — the button is the gate, so an unacknowledged signature can never reach the field.
	function updateApply() {
		mUI.apply.disabled = ! ( mPad.hasInk() && ( ! requireAck || mUI.esign.checked ) );
	}

	function openFor( f ) {
		if ( ! modal ) {
			buildModal();
		}
		field = f;
		var modes = f.dataset.modes || 'both';
		var dataEl = f.querySelector( '.em-signature-data' );
		var nameEl = f.querySelector( '.em-signature-name' );
		var previewEl = f.querySelector( '.em-signature-preview' );
		var typedName = nameEl ? nameEl.value : '';
		var existing = dataEl ? dataEl.value : '';
		if ( ! existing && previewEl && previewEl.getAttribute( 'src' ) ) {
			existing = previewEl.src; // an already-saved signature, served same-origin
		}

		mUI.title.textContent = f.dataset.label || 'Signature';
		// "Modal with consent text": bring the field's own (hidden) consent wording into the pop-up.
		var consentEl = f.querySelector( '.em-signature-consent' );
		if ( f.dataset.display === 'modal_consent' && consentEl ) {
			mUI.consent.innerHTML = consentEl.innerHTML;
			mUI.consent.hidden = false;
		} else {
			mUI.consent.innerHTML = '';
			mUI.consent.hidden = true;
		}
		requireAck = f.dataset.requireAck !== '0';
		mUI.esignText.textContent = f.dataset.esign || '';
		mUI.esignRow.hidden = ! requireAck;
		var version = f.dataset.version || '';
		mUI.version.textContent = version ? ( ( L().version || 'Document version' ) + ': ' + version ) : '';
		mUI.modes.hidden = modes !== 'both';
		mUI.esign.checked = false;
		// reopen in the mode the signature was made in, so editing shows what you signed
		var wanted = ( modes === 'type' || ( modes === 'both' && typedName ) ) ? 'type' : 'draw';
		mPad.reset( wanted, typedName );

		// openModal runs its callback after the panel has transitioned in, so the canvas finally has
		// layout to size and paint against.
		openModal( modal, function () {
			mPad.size();
			if ( wanted === 'type' && typedName ) {
				mPad.render();
			} else if ( existing ) {
				mPad.load( existing );
			}
			updateApply();
		} );
	}

	function commit() {
		if ( ! field || mUI.apply.disabled ) {
			return;
		}
		var url;
		try {
			url = mPad.toDataURL();
		} catch ( e ) {
			// Only reachable if a preloaded signature came from another origin (uploads on a CDN)
			// and tainted the canvas — recover by asking for a fresh mark rather than failing mutely.
			mPad.clear();
			return;
		}
		writeSignature( field, url, mPad.mode() === 'type' ? mPad.typedName() : '', mUI.esign.checked );
		closeModal( modal );
	}

	/* =================================================================== inline */

	// Inline display: the pad sits in the form instead of a pop-up. It reuses the same capture core;
	// the only difference from the modal is that there's no Apply — the value syncs to the field
	// whenever there's a mark and, where required, the acknowledgement is ticked.
	function initInline( f ) {
		var host = f.querySelector( '.em-signature-inline' );
		if ( ! host ) {
			return;
		}
		var modes = f.dataset.modes || 'both';
		var ack = f.dataset.requireAck !== '0';
		var ns = 'em-sig-i-' + ( ++padSeq );
		host.innerHTML = captureMarkup( ns, modes ) +
			( ack ? '<label class="em-signature-esign"><input type="checkbox" class="em-signature-esign-check"> <span class="em-signature-esign-text"></span></label>' : '' );

		var esign = host.querySelector( '.em-signature-esign-check' );
		if ( esign ) {
			host.querySelector( '.em-signature-esign-text' ).textContent = f.dataset.esign || '';
		}

		var pad = createPad( host, { modes: modes, onChange: sync } );

		function sync() {
			var data = f.querySelector( '.em-signature-data' );
			var nameInput = f.querySelector( '.em-signature-name' );
			var esignInput = f.querySelector( '.em-signature-esign-input' );
			var acked = ! ack || ( esign && esign.checked );
			if ( ! pad.hasInk() || ! acked ) {
				if ( data ) { data.value = ''; }
				if ( esignInput ) { esignInput.value = ''; }
				return;
			}
			if ( data ) { data.value = pad.toDataURL(); }
			if ( nameInput ) { nameInput.value = pad.mode() === 'type' ? pad.typedName() : ''; }
			if ( esignInput ) { esignInput.value = ( esign && esign.checked ) ? '1' : ''; }
		}

		if ( esign ) {
			esign.addEventListener( 'change', sync );
		}
		pad.showMode();
		if ( f.dataset.preview ) {
			// Show an already-saved signature so editing is visible; the value stays empty until
			// re-drawn, so an untouched re-save preserves the sealed record.
			pad.load( f.dataset.preview );
		}
	}

	/* ==================================================== field commit + preview */

	// Writes the captured signature into the field's hidden inputs and flips the trigger to its
	// signed preview. Shared by the modal (on Apply) and — via the inline sync — kept consistent.
	function writeSignature( f, url, name, acked ) {
		var data = f.querySelector( '.em-signature-data' );
		if ( ! data ) {
			return;
		}
		var nameInput = f.querySelector( '.em-signature-name' );
		var esignInput = f.querySelector( '.em-signature-esign-input' );
		var trigger = f.querySelector( '.em-signature-trigger' );
		var empty = f.querySelector( '.em-signature-trigger-empty' );
		var signed = f.querySelector( '.em-signature-trigger-signed' );
		var preview = f.querySelector( '.em-signature-preview' );
		var caption = f.querySelector( '.em-signature-caption small' );

		data.value = url;
		if ( nameInput ) {
			nameInput.value = name || '';
		}
		if ( esignInput ) {
			esignInput.value = acked ? '1' : '';
		}
		if ( preview ) {
			preview.src = url;
		}
		if ( empty ) {
			empty.hidden = true;
		}
		if ( signed ) {
			signed.hidden = false;
		}
		if ( trigger ) {
			trigger.classList.add( 'em-signature-is-signed' );
		}
		if ( caption ) {
			caption.textContent = ''; // the stored caption describes the saved record, not this pending one
		}
	}

	/* ==================================================================== fields */

	function initField( f ) {
		if ( f.dataset.emSignatureReady ) {
			return;
		}
		f.dataset.emSignatureReady = '1';
		if ( f.dataset.display === 'inline' ) {
			initInline( f );
			return;
		}
		var trigger = f.querySelector( '.em-signature-trigger' );
		if ( trigger ) {
			trigger.addEventListener( 'click', function () {
				openFor( f );
			} );
		}
	}

	function initAll( root ) {
		var scope = root && root.querySelectorAll ? root : document;
		Array.prototype.forEach.call( scope.querySelectorAll( '.em-signature-field' ), initField );
	}

	// Undoes initField's dataset guard so a field can be initialised again. Needed before a container
	// is cloned: cloneNode() copies data-* attributes (unlike listeners), so a signature field that was
	// ever initialised before being cloned would carry the "ready" flag onto every clone and never
	// actually bind — which is exactly what made new attendee rows' signature fields inert.
	function unsetField( root ) {
		var scope = root && root.querySelectorAll ? root : document;
		Array.prototype.forEach.call( scope.querySelectorAll( '.em-signature-field' ), function ( f ) {
			delete f.dataset.emSignatureReady;
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			initAll( document );
		} );
	} else {
		// EM's asset loader injects this after the DOM (and possibly the field) already exists
		initAll( document );
	}

	document.addEventListener( 'em_booking_form_js_loaded', function () {
		initAll( document );
	} );

	// The attendee-form lifecycle (add/remove attendee rows) works by cloning a stored template and
	// running em_unsetup_ui_elements()/em_setup_ui_elements() on it — the same hook selectize, tippy
	// and the date/time pickers use to survive being cloned. Follow it instead of relying solely on
	// the MutationObserver below, which only catches insertion, not the clone-carries-stale-state issue.
	document.addEventListener( 'em_unsetup_ui_elements', function ( e ) {
		unsetField( e.detail && e.detail.container );
	} );
	document.addEventListener( 'em_setup_ui_elements', function ( e ) {
		initAll( e.detail && e.detail.container );
	} );

	// Booking forms are (re)injected by AJAX — recurrence slot picks, ticket changes. EM core
	// watches for this with a MutationObserver (there is no per-form init event), so we do the
	// same as a catch-all for insertions outside the setup/unsetup lifecycle above; initField's
	// dataset guard makes repeat scans free.
	var observer = new MutationObserver( function ( mutations ) {
		for ( var i = 0; i < mutations.length; i++ ) {
			var added = mutations[ i ].addedNodes;
			for ( var j = 0; j < added.length; j++ ) {
				var node = added[ j ];
				if ( node.nodeType !== 1 ) {
					continue;
				}
				if ( node.matches && node.matches( '.em-signature-field' ) ) {
					initField( node );
				} else if ( node.querySelector && node.querySelector( '.em-signature-field' ) ) {
					initAll( node );
				}
			}
		}
	} );
	observer.observe( document.body || document.documentElement, { childList: true, subtree: true } );
} )();

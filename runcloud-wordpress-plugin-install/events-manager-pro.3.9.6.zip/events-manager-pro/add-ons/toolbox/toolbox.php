<?php

/**
 * This add-on adds powerful features to EM, such as extending cancellation options.
 */
require 'cancellation.php';

// Event Submission Limits
if ( get_option( 'dbem_event_submission_limits_enabled' ) ) {
	include 'limits.php';
}
// Past Events
if ( in_array( get_option( 'dbem_past_events', 'published' ), array( 'past', 'trash', 'delete' ), true ) ) {
	include 'past-events/past-events.php';
} elseif ( wp_next_scheduled( 'emp_cron_process_past_events' ) ) {
	wp_clear_scheduled_hook( 'emp_cron_process_past_events' );
}

if ( get_option( 'dbem_minimum_capacity' ) ) {
	include 'minimum-capacity/minimum-capacity.php';
}

// Admin Settings
if ( is_admin() ) {
	include 'limits-admin.php';
	include 'past-events/past-events-admin.php';
	include 'minimum-capacity/minimum-capacity-admin.php';
}

require 'move-booking.php';

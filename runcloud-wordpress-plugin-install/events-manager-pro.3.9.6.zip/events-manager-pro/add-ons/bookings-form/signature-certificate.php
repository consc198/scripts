<?php
namespace EM\Bookings;

use EM\Forms\Uploads;
use EM\Uploads\Uploader;

/**
 * Renders a signed-consent "certificate of completion" PDF from a stored signature bundle and files it alongside the signature image, so the permission-gated serve endpoint, booking-delete cleanup and retention sweep all cover it unchanged.
 *
 * Invariants (SPEC § Increment 1.5): the certificate is always built from the sealed bundle, never a fresh render (the event may have changed since); the sealed `signature` array is never mutated (that would break verify()) — certificate metadata lives in a sibling `certificate` key; and generation failure degrades quietly, never blocking booking promotion or the signer email.
 */
class Certificate {

	/** dompdf is vendored in the printables add-on; only attempt generation when it is actually loadable there, to dodge the well-known dompdf-collision hazard of vendoring our own. */
	protected static function available() {
		return class_exists( '\EM_Pro\Printables\PDFs' ) && method_exists( '\EM_Pro\Printables\PDFs', 'get_pdf_content' );
	}

	/**
	 * Whether a certificate should be produced for a field: the per-field option (default on) and dompdf being available.
	 * @param array $field
	 * @return bool
	 */
	public static function enabled( $field ) {
		$opt = ! isset( $field['options_signature_pdf'] ) || ! empty( $field['options_signature_pdf'] );
		return $opt && static::available();
	}

	/**
	 * Generates and files the certificate PDF for a signed signature value, returning the updated value: the PDF added to `files`, `image_uuid`/`certificate_uuid` pointers set, and a `certificate` metadata sibling written. Idempotent (returns unchanged if a certificate already exists) and failure-safe (returns the value unchanged on any error).
	 *
	 * @param \EM_Booking $EM_Booking
	 * @param array       $field
	 * @param array       $field_value  a signed signature value (carries files + signature + endpoint + subfolder)
	 * @return array
	 */
	public static function generate( $EM_Booking, $field, $field_value ) {
		if ( ! is_array( $field_value ) || empty( $field_value['files'] ) || empty( $field_value['signature'] ) ) {
			return $field_value;
		}
		if ( ! empty( $field_value['certificate']['uuid'] ) ) {
			return $field_value; // already generated
		}
		if ( ! static::enabled( $field ) ) {
			return $field_value;
		}
		// The signature image is the first file at generation time; pre-existing records carry no image_uuid.
		$image_uuid = ! empty( $field_value['image_uuid'] ) ? $field_value['image_uuid'] : key( $field_value['files'] );

		try {
			$args = static::view_args( $EM_Booking, $field, $field_value, $image_uuid );
			$pdf  = \EM_Pro\Printables\PDFs::get_pdf_content( 'form-fields/signatures/certificate.php', $args );
		} catch ( \Throwable $e ) {
			static::note_failure( $EM_Booking, $e->getMessage() );
			return $field_value;
		}
		if ( empty( $pdf ) ) {
			static::note_failure( $EM_Booking, 'empty PDF output' );
			return $field_value;
		}

		// File the PDF in the same endpoint dir the signature PNG lives in, so the serve endpoint, cleanup and retention sweep all cover it with no changes.
		$subfolder = is_string( $field_value['subfolder'] ?? '' ) ? trim( $field_value['subfolder'], '/\\' ) : '';
		$endpoint  = $field_value['endpoint'] ?? '';
		$field_id  = $field['fieldid'];
		$dir       = Uploads::get_endpoint_dir( $subfolder ); // also writes the deny-all .htaccess
		wp_mkdir_p( $dir );
		$uuid     = md5( uniqid( (string) $field_id . '-cert', true ) );
		$prefix   = $endpoint !== '' ? $endpoint . '-' : '';
		$filename = $prefix . $field_id . '-' . $uuid . '.pdf';
		$filepath = trailingslashit( $dir ) . $filename;
		if ( file_put_contents( $filepath, $pdf ) === false ) {
			static::note_failure( $EM_Booking, 'could not write PDF' );
			return $field_value;
		}
		$uploads_dir = Uploader::upload_dir( false, Uploads::$uploads_folder );
		$file_url    = trailingslashit( $uploads_dir['url'] ) . ( $subfolder !== '' ? trailingslashit( $subfolder ) : '' ) . $filename;

		$field_value['files'][ $uuid ] = array(
			'name' => 'certificate.pdf',
			'url'  => $file_url,
			'file' => $filepath,
		);
		$field_value['image_uuid']       = $image_uuid;
		$field_value['certificate_uuid'] = $uuid;
		$field_value['certificate']      = array(
			'uuid'          => $uuid,
			'sha256'        => hash( 'sha256', $pdf ),
			'generated_utc' => gmdate( 'Y-m-d\TH:i:s\Z' ),
		);
		return $field_value;
	}

	/**
	 * The signature image file within a value, honouring the image_uuid pointer with a first-file fallback for records written before certificates existed.
	 * @param array $field_value
	 * @return array|null
	 */
	public static function image_file( $field_value ) {
		if ( empty( $field_value['files'] ) ) {
			return null;
		}
		$uuid = ! empty( $field_value['image_uuid'] ) ? $field_value['image_uuid'] : key( $field_value['files'] );
		return $field_value['files'][ $uuid ] ?? null;
	}

	/**
	 * The certificate PDF file within a value, or null when none has been generated.
	 * @param array $field_value
	 * @return array|null
	 */
	public static function pdf_file( $field_value ) {
		if ( empty( $field_value['certificate_uuid'] ) || empty( $field_value['files'][ $field_value['certificate_uuid'] ] ) ) {
			return null;
		}
		return $field_value['files'][ $field_value['certificate_uuid'] ];
	}

	/**
	 * Builds the certificate template variables from the sealed bundle. Never re-renders the consent — the document shown is exactly what was signed.
	 * @return array
	 */
	protected static function view_args( $EM_Booking, $field, $field_value, $image_uuid ) {
		$sig      = $field_value['signature'];
		$event    = method_exists( $EM_Booking, 'get_event' ) ? $EM_Booking->get_event() : null;
		$img_data = '';
		$img_file = $field_value['files'][ $image_uuid ]['file'] ?? '';
		if ( $img_file !== '' && file_exists( $img_file ) ) {
			$img_data = 'data:image/png;base64,' . base64_encode( file_get_contents( $img_file ) );
		}
		return array(
			'site_name'     => get_bloginfo( 'name' ),
			'title'         => ! empty( $field['label'] ) ? $field['label'] : __( 'Signature', 'em-pro' ),
			'event_name'    => $event ? $event->event_name : '',
			'consent_text'  => ! empty( $sig['consent_text'] ) ? $sig['consent_text'] : '',
			'signature_img' => $img_data,
			'envelope'      => Signatures::envelope( $field_value ),
			'seal'          => ! empty( $sig['record_hmac'] ) ? $sig['record_hmac'] : '',
			'booking_uuid'  => $EM_Booking->uuid ?? '',
			'generated_utc' => gmdate( 'Y-m-d\TH:i:s\Z' ),
		);
	}

	/**
	 * @param \EM_Booking $EM_Booking
	 * @param string      $msg
	 */
	protected static function note_failure( $EM_Booking, $msg ) {
		error_log( 'EM Pro signature certificate generation failed for booking ' . ( $EM_Booking->booking_id ?? '?' ) . ': ' . $msg );
	}
}

<?php
namespace EM\Bookings;

use EM\Forms\Uploads;
use EM\Uploads\Uploader;
use EM\Utils;
use EM_Exception;

/**
 * The `signature` booking/attendee form field type: captures a legally defensible Simple Electronic Signature (eIDAS SES / ESIGN / UETA) at booking time.
 *
 * The signed PNG is written through the same form-uploads infrastructure as the `upload` field, so it is served only via the permission-checked endpoint. Alongside the file we store an audit bundle (consent text hash + version, signer, timestamp, IP, user agent, e-sign consent) sealed with an HMAC keyed on the site's auth salt, so tampering through the admin UI or booking-edit path is detectable.
 */
class Signatures {

	/** Reject decoded PNGs larger than this. A drawn signature is a few KB; a large blob means abuse or a mistake. */
	const MAX_BYTES = 300000;

	/** PNG file magic — the only image type we accept, since the client always exports canvas.toDataURL('image/png'). */
	const PNG_MAGIC = "\x89PNG\r\n\x1a\n";

	/** Bookings whose signatures were captured this request, keyed by object id, so a single finalize is scheduled per booking at shutdown. */
	protected static $pending = array();

	public static function init() {
		// Booking forms load the pad via EM's selector-based lazy asset system — the group covers `.em-booking-recurring` too, so recurring events whose form arrives by AJAX still get the script (a footer enqueue never fires there). enqueue() remains for the standalone signing page only.
		add_filter( 'em_booking_form_assets', array( static::class, 'booking_form_assets' ) );
		add_filter( 'em_wp_localize_script', array( static::class, 'localize' ) );
		// Awaiting-signature gate: maintain the flag after the form (priority 1) has saved its files, hold new bookings pending, and tell admins why.
		add_filter( 'em_booking_save', array( static::class, 'maintain_flag' ), 20, 2 );
		add_action( 'em_booking_added', array( static::class, 'hold_pending' ), 20 );
		add_filter( 'em_booking_get_status', array( static::class, 'status_label' ), 10, 2 );
		add_filter( 'em_booking_is_approved', array( static::class, 'block_approval' ), 10, 2 );
		add_filter( 'em_booking_delete', array( static::class, 'cleanup_files' ), 10, 2 );
		// Certificate + signer-copy email. Any capture (inline at checkout or via the signing page) schedules a finalize pass that generates the PDF certificate and emails the signer their copy, gated or not — closing the inline signer-copy gap. em_booking_signature_completed keeps its precise meaning (the gate released) and no longer carries the email.
		add_action( 'shutdown', array( static::class, 'flush_pending_finalize' ) );
		add_action( 'em_pro_signature_finalize', array( static::class, 'finalize' ) );
		// Email + on-screen booking placeholders: the tokened signing link plus a conditional pair to gate the "please sign" block. One flat URL placeholder can't carry which of several signatures is outstanding, so the conditional does the branching and the link collects every outstanding booking-form signature at once.
		add_filter( 'em_booking_output_placeholder', array( static::class, 'output_placeholder' ), 1, 4 );
		add_filter( 'em_booking_output_show_condition', array( static::class, 'output_show_condition' ), 10, 3 );
		// A "sign later" field renders nothing on the initial booking/attendee form (it's only completed afterwards via the signing page), so it can never be required there.
		add_filter( 'emp_forms_output_field_input', array( static::class, 'suppress_sign_later_field' ), 10, 4 );
		// Retention sweep: delete signature images once past their per-field retention window. Beta — off by default; define EM_SIG_RETENTION as an integer day count > 0 to enable.
		add_action( 'em_pro_signature_retention', array( static::class, 'run_retention' ) );
		if ( function_exists( 'wp_next_scheduled' ) ) {
			if ( static::retention_enabled() && ! wp_next_scheduled( 'em_pro_signature_retention' ) ) {
				wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'em_pro_signature_retention' );
			} elseif ( ! static::retention_enabled() && wp_next_scheduled( 'em_pro_signature_retention' ) ) {
				wp_clear_scheduled_hook( 'em_pro_signature_retention' ); // in case a prior version scheduled it before this flag existed
			}
		}
	}

	/**
	 * Returns the ids of gated (hold-pending) signature fields that have not yet been signed, across the booking form and each attendee.
	 * @param \EM_Booking $EM_Booking
	 * @return array  e.g. array( 'booking' => array( 'waiver_sig' ), 'attendees' => array( 42 => array( 'waiver_sig' ) ) ), empty when nothing is outstanding.
	 */
	public static function gated_unsigned( $EM_Booking ) {
		$unsigned = array();
		if ( empty( $EM_Booking->event_id ) ) {
			return $unsigned;
		}
		// Booking-form signature fields.
		if ( class_exists( 'EM_Booking_Form' ) ) {
			$EM_Form = \EM_Booking_Form::get_form( $EM_Booking->event_id, $EM_Booking );
			if ( $EM_Form && ! empty( $EM_Form->form_fields ) ) {
				foreach ( $EM_Form->form_fields as $fid => $field ) {
					if ( static::is_gated( $field ) && empty( $EM_Booking->booking_meta['booking'][ $fid ]['files'] ) ) {
						$unsigned['booking'][] = $fid;
					}
				}
			}
		}
		// Attendee-form signature fields, checked per attendee (one ticket-booking row each).
		if ( class_exists( 'EM_Attendees_Form' ) ) {
			$EM_Attendee_Form = \EM_Attendees_Form::get_form( $EM_Booking->get_event() );
			if ( $EM_Attendee_Form && ! empty( $EM_Attendee_Form->form_fields ) ) {
				$gated_fields = array();
				foreach ( $EM_Attendee_Form->form_fields as $fid => $field ) {
					if ( static::is_gated( $field ) ) {
						$gated_fields[] = $fid;
					}
				}
				if ( ! empty( $gated_fields ) ) {
					foreach ( $EM_Booking->get_tickets_bookings()->tickets_bookings as $EM_Ticket_Bookings ) {
						foreach ( $EM_Ticket_Bookings as $EM_Ticket_Booking ) {
							foreach ( $gated_fields as $fid ) {
								if ( empty( $EM_Ticket_Booking->meta[ $fid ]['files'] ) ) {
									$unsigned['attendees'][ $EM_Ticket_Booking->ticket_booking_id ][] = $fid;
								}
							}
						}
					}
				}
			}
		}
		return $unsigned;
	}

	/**
	 * The full breakdown of unsigned signature fields for a booking — every booking-form field and every attendee's fields, gated or not — so the one-link signing page can present them as a single checklist (DocuSign-style) and a booker completes every outstanding signature for the whole booking in one place.
	 *
	 * @param \EM_Booking $EM_Booking
	 * @return array {
	 *     @type array $booking    fieldid => field, for outstanding booking-form signatures.
	 *     @type array $attendees  ticket_booking_id => array( 'ticket_booking' => \EM_Ticket_Booking, 'label' => string, 'fields' => array( fieldid => field ) ).
	 * }
	 */
	public static function outstanding( $EM_Booking ) {
		$out = array( 'booking' => array(), 'attendees' => array() );
		if ( empty( $EM_Booking->event_id ) ) {
			return $out;
		}
		if ( class_exists( 'EM_Booking_Form' ) ) {
			$EM_Form = \EM_Booking_Form::get_form( $EM_Booking->event_id, $EM_Booking );
			if ( $EM_Form && ! empty( $EM_Form->form_fields ) ) {
				foreach ( $EM_Form->form_fields as $fid => $field ) {
					if ( ( $field['type'] ?? '' ) === 'signature' && empty( $EM_Booking->booking_meta['booking'][ $fid ]['files'] ) ) {
						$out['booking'][ $fid ] = $field;
					}
				}
			}
		}
		if ( class_exists( 'EM_Attendees_Form' ) ) {
			$EM_Attendee_Form = \EM_Attendees_Form::get_form( $EM_Booking->get_event() );
			if ( $EM_Attendee_Form && ! empty( $EM_Attendee_Form->form_fields ) ) {
				$sig_fields = array();
				foreach ( $EM_Attendee_Form->form_fields as $fid => $field ) {
					if ( ( $field['type'] ?? '' ) === 'signature' ) {
						$sig_fields[ $fid ] = $field;
					}
				}
				if ( ! empty( $sig_fields ) ) {
					$n = 0;
					foreach ( $EM_Booking->get_tickets_bookings()->tickets_bookings as $EM_Ticket_Bookings ) {
						foreach ( $EM_Ticket_Bookings as $EM_Ticket_Booking ) {
							$n++;
							foreach ( $sig_fields as $fid => $field ) {
								if ( empty( $EM_Ticket_Booking->meta[ $fid ]['files'] ) ) {
									$tbid = $EM_Ticket_Booking->ticket_booking_id;
									if ( ! isset( $out['attendees'][ $tbid ] ) ) {
										$out['attendees'][ $tbid ] = array(
											'ticket_booking' => $EM_Ticket_Booking,
											'label'          => static::attendee_label( $EM_Ticket_Booking, $n ),
											'fields'         => array(),
										);
									}
									$out['attendees'][ $tbid ]['fields'][ $fid ] = $field;
								}
							}
						}
					}
				}
			}
		}
		return $out;
	}

	/**
	 * Whether a booking has any outstanding signature at all — booking-form or attendee. Drives the one-link signing page, the #_BOOKINGSIGNATUREURL placeholder and the {booking_has_unsigned_signatures} conditional.
	 * @param \EM_Booking $EM_Booking
	 * @return bool
	 */
	public static function has_outstanding( $EM_Booking ) {
		$out = static::outstanding( $EM_Booking );
		return ! empty( $out['booking'] ) || ! empty( $out['attendees'] );
	}

	/**
	 * A human label for an attendee row in the signing checklist: the ticket name where known, numbered within the booking.
	 * @param \EM_Ticket_Booking $EM_Ticket_Booking
	 * @param int                $n
	 * @return string
	 */
	protected static function attendee_label( $EM_Ticket_Booking, $n ) {
		$ticket_name = '';
		if ( method_exists( $EM_Ticket_Booking, 'get_ticket' ) ) {
			$EM_Ticket = $EM_Ticket_Booking->get_ticket();
			if ( $EM_Ticket && ! empty( $EM_Ticket->ticket_name ) ) {
				$ticket_name = $EM_Ticket->ticket_name;
			}
		}
		return $ticket_name !== ''
			? sprintf( __( 'Attendee %1$d: %2$s', 'em-pro' ), $n, $ticket_name )
			: sprintf( __( 'Attendee %d', 'em-pro' ), $n );
	}

	/**
	 * Whether the booking has any unsigned booking-form signature field, gated or not. Drives the admin sign-now link, unlike has_outstanding() which also spans attendee signatures.
	 * @param \EM_Booking $EM_Booking
	 * @return bool
	 */
	public static function has_unsigned( $EM_Booking ) {
		if ( ! class_exists( 'EM_Booking_Form' ) || empty( $EM_Booking->event_id ) ) {
			return false;
		}
		$EM_Form = \EM_Booking_Form::get_form( $EM_Booking->event_id, $EM_Booking );
		if ( ! $EM_Form || empty( $EM_Form->form_fields ) ) {
			return false;
		}
		foreach ( $EM_Form->form_fields as $fid => $field ) {
			if ( ( $field['type'] ?? '' ) === 'signature' && empty( $EM_Booking->booking_meta['booking'][ $fid ]['files'] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Booking-level signature value placeholder for emails and on-screen booking output.
	 *
	 * `#_BOOKINGSIGNATUREURL` resolves to the tokened signing link, which presents every outstanding signature for the booking — booking-form fields and each attendee's fields — as one checklist to complete in a single visit. It is empty once nothing is outstanding, so a stray token in a confirmed-booking email disappears rather than linking to an already-signed booking.
	 *
	 * @param string      $replace      current value; still the raw token when no earlier filter has claimed it
	 * @param \EM_Booking $EM_Booking
	 * @param string      $full_result  the full matched placeholder
	 * @param string      $target       'html' | 'email' | 'raw'
	 * @return string
	 */
	public static function output_placeholder( $replace, $EM_Booking, $full_result, $target = 'html' ) {
		if ( empty( $replace ) || $replace === $full_result ) {
			if ( $full_result === '#_BOOKINGSIGNATUREURL' ) {
				$replace = static::has_outstanding( $EM_Booking ) ? Signing::url( $EM_Booking ) : '';
			}
		}
		return $replace;
	}

	/**
	 * Booking-level signature conditional placeholders, so a template can show the "please sign" block only when something is actually outstanding:
	 *
	 *   {booking_has_unsigned_signatures} … #_BOOKINGSIGNATUREURL … {/booking_has_unsigned_signatures}
	 *   {booking_no_unsigned_signatures} … {/booking_no_unsigned_signatures}
	 *
	 * @param bool        $show_condition
	 * @param array       $args  keys: format, target, condition, conditionals, key
	 * @param \EM_Booking $EM_Booking
	 * @return bool
	 */
	public static function output_show_condition( $show_condition, $args, $EM_Booking ) {
		if ( $args['condition'] === 'booking_has_unsigned_signatures' ) {
			$show_condition = static::has_outstanding( $EM_Booking );
		} elseif ( $args['condition'] === 'booking_no_unsigned_signatures' ) {
			$show_condition = ! static::has_outstanding( $EM_Booking );
		}
		return $show_condition;
	}

	/**
	 * Whether an unsigned instance of this field should hold the booking pending ("awaiting signature").
	 *
	 * Only a *required* signature does. A required signature shown on the form is enforced there (it can't be left unsigned), so in practice this holds a booking when a required signature is deferred to the signing page via `sign_later` (hidden on the form, still mandatory). A non-required signature — missing or skipped — is always signable via the link but never impedes the booking.
	 * @param array $field
	 * @return bool
	 */
	protected static function is_gated( $field ) {
		return ( ( $field['type'] ?? '' ) === 'signature' ) && ! empty( $field['required'] );
	}

	/**
	 * Whether a signature field is configured to be signed only after booking, via the signing page — never on the initial booking/attendee form.
	 * @param array $field
	 * @return bool
	 */
	protected static function is_sign_later( $field ) {
		return ( $field['options_signature_display'] ?? '' ) === 'sign_later';
	}

	/**
	 * Suppresses the entire per-field markup (label included) for a "sign later" signature field on the initial booking/attendee form, so it is fully hidden rather than showing an empty control. It remains fully visible and signable on the standalone signing page, which forces its own display mode regardless of this option. Hooked on `emp_forms_output_field_input`, which wraps every field's rendered output.
	 * @param string          $html
	 * @param \EM_Form        $EM_Form
	 * @param array           $field
	 * @param mixed           $post
	 * @return string
	 */
	public static function suppress_sign_later_field( $html, $EM_Form, $field, $post ) {
		if ( ( $field['type'] ?? '' ) === 'signature' && static::is_sign_later( $field ) ) {
			return '';
		}
		return $html;
	}

	/**
	 * Whether the retention sweep is active. A beta feature, off by default: define EM_SIG_RETENTION as an integer day count greater than 0 to enable it (and to show the per-field Retention option in the form editor).
	 * @return bool
	 */
	public static function retention_enabled() {
		return defined( 'EM_SIG_RETENTION' ) && (int) EM_SIG_RETENTION > 0;
	}

	/**
	 * Prevents a booking from counting as approved while a gated signature is still outstanding, regardless of the event's booking-approval setting. This is what actually holds the booking pending; hold_pending() sets the stored status, this filter keeps it non-approved for spaces, emails and gateways.
	 * @param bool        $result
	 * @param \EM_Booking $EM_Booking
	 * @return bool
	 */
	public static function block_approval( $result, $EM_Booking ) {
		if ( $result && static::is_awaiting( $EM_Booking ) ) {
			return false;
		}
		return $result;
	}

	/**
	 * Whether a booking is currently held pending an outstanding signature.
	 * @param \EM_Booking $EM_Booking
	 * @return bool
	 */
	public static function is_awaiting( $EM_Booking ) {
		return ! empty( $EM_Booking->booking_meta['awaiting_signature'] );
	}

	/**
	 * Decodes the awaiting_signature flag (stored as a JSON scalar) into its array form.
	 * @param \EM_Booking $EM_Booking
	 * @return array  array( 'since' => ..., 'fields' => array( 'booking' => [...], 'attendees' => [...] ) ), empty when not awaiting.
	 */
	public static function read_flag( $EM_Booking ) {
		$v = $EM_Booking->booking_meta['awaiting_signature'] ?? null;
		if ( is_string( $v ) ) {
			$v = json_decode( $v, true );
		}
		return is_array( $v ) ? $v : array();
	}

	/**
	 * Recomputes and persists the top-level awaiting_signature flag whenever a booking is saved. The key records why a booking is pending (which fields, and since when) and is deleted entirely once nothing is outstanding, so code that doesn't know about it sees no trace.
	 * @param bool        $result
	 * @param \EM_Booking $EM_Booking
	 * @return bool  Passed through unchanged.
	 */
	public static function maintain_flag( $result, $EM_Booking ) {
		if ( empty( $EM_Booking->booking_id ) ) {
			return $result;
		}
		$was_awaiting = static::is_awaiting( $EM_Booking );
		$unsigned     = static::gated_unsigned( $EM_Booking );
		if ( ! empty( $unsigned ) ) {
			$existing = static::read_flag( $EM_Booking );
			$since    = ! empty( $existing['since'] ) ? $existing['since'] : gmdate( 'Y-m-d\TH:i:s\Z' );
			// Stored as a JSON scalar, not a nested array: EM_Booking::update_meta() clears a scalar meta key cleanly (a single row), but a nested array is written as `_awaiting_signature|*` rows that update_meta($key, null) can't delete — which would leave a signed booking stuck awaiting (and unapproved) forever.
			$EM_Booking->update_meta( 'awaiting_signature', wp_json_encode( array( 'since' => $since, 'fields' => $unsigned ) ) );
		} elseif ( $was_awaiting ) {
			$EM_Booking->update_meta( 'awaiting_signature', null );
			/**
			 * Fires when the last outstanding gated signature on a booking has been signed and the hold is released.
			 * @param \EM_Booking $EM_Booking
			 */
			do_action( 'em_booking_signature_completed', $EM_Booking );
		}
		return $result;
	}

	/**
	 * Keeps a newly added booking pending while a gated signature is still outstanding, so it is not auto-approved before the waiver is signed.
	 * @param \EM_Booking $EM_Booking
	 */
	public static function hold_pending( $EM_Booking ) {
		if ( static::is_awaiting( $EM_Booking ) && (int) $EM_Booking->booking_status !== 0 ) {
			$EM_Booking->set_status( 0, false );
		}
	}

	/**
	 * Appends the pending reason to the booking status shown to admins.
	 * @param string      $status_text
	 * @param \EM_Booking $EM_Booking
	 * @return string
	 */
	public static function status_label( $status_text, $EM_Booking ) {
		if ( static::is_awaiting( $EM_Booking ) ) {
			$status_text .= ' – ' . __( 'awaiting signature', 'em-pro' );
		}
		return $status_text;
	}

	/**
	 * Strings for the signing modal. The modal is built in JS (one shared instance rather than a pad per field), so its chrome can't be translated in the template like the field itself.
	 * @param array $vars
	 * @return array
	 */
	public static function localize( $vars ) {
		$vars['signature'] = array(
			'hint'     => __( 'Sign here', 'em-pro' ),
			'typeName' => __( 'Type your full name', 'em-pro' ),
			'yourName' => __( 'Your name', 'em-pro' ),
			'clear'    => __( 'Clear', 'em-pro' ),
			'cancel'   => __( 'Cancel', 'em-pro' ),
			'apply'    => __( 'Apply signature', 'em-pro' ),
			'version'  => __( 'Document version', 'em-pro' ),
			'draw'     => __( 'Draw', 'em-pro' ),
			'type'     => __( 'Type', 'em-pro' ),
			'redraw'   => __( 'Please sign again', 'em-pro' ),
		);
		return $vars;
	}

	/**
	 * Registers the signature pad script in EM's booking-form asset group, loaded lazily wherever a booking form (or recurrence picker) exists and executed after injection.
	 * @param array $assets
	 * @return array
	 */
	public static function booking_form_assets( $assets ) {
		$js_min  = \EM_Scripts_and_Styles::get_minified_extension_js();
		$css_min = \EM_Scripts_and_Styles::get_minified_extension_css();
		// filemtime versioning in dev, so iteration isn't fighting a ?v=EMP_VERSION browser cache; EM serving non-minified files is its own dev-mode signal, whatever toggles it
		$dev  = $js_min === '' || ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG );
		$js_v  = $dev ? (int) @filemtime( EMP_DIR . '/includes/js/em-signature' . $js_min . '.js' ) : EMP_VERSION;
		$css_v = $dev ? (int) @filemtime( EMP_DIR . '/includes/css/em-signature' . $css_min . '.css' ) : EMP_VERSION;
		$assets['js']['em-signature'] = array(
			'url'      => EMP_DIR_URI . 'includes/js/em-signature' . $js_min . '.js?v=' . $js_v,
			'requires' => 'em-bookings',
		);
		$assets['css']['em-signature'] = EMP_DIR_URI . 'includes/css/em-signature' . $css_min . '.css?v=' . $css_v;
		ksort( $assets['js'] );
		return $assets;
	}

	/**
	 * Enqueues the dependency-free signature pad script, preferring the minified build unless SCRIPT_DEBUG is on or it is absent. Used by the standalone signing page; booking forms load via booking_form_assets(). Safe to call more than once — WordPress dedupes by handle.
	 */
	public static function enqueue() {
		$min = ( ! defined( 'SCRIPT_DEBUG' ) || ! SCRIPT_DEBUG ) && file_exists( EMP_DIR . '/includes/js/em-signature.min.js' );
		if ( ! wp_script_is( 'em-pro-signature', 'registered' ) ) {
			$file = 'includes/js/em-signature' . ( $min ? '.min' : '' ) . '.js';
			wp_register_script( 'em-pro-signature', plugins_url( $file, EMP_DIR . '/events-manager-pro.php' ), array(), EMP_VERSION, true );
		}
		if ( ! wp_style_is( 'em-pro-signature', 'registered' ) ) {
			$css = 'includes/css/em-signature' . ( $min ? '.min' : '' ) . '.css';
			wp_register_style( 'em-pro-signature', plugins_url( $css, EMP_DIR . '/events-manager-pro.php' ), array(), EMP_VERSION );
		}
		wp_enqueue_script( 'em-pro-signature' );
		wp_enqueue_style( 'em-pro-signature' );
	}

	/**
	 * Deletes a booking's signature image files (booking form and every attendee) when the booking is deleted, so no signature artefact is left on disk after erasure.
	 * @param bool        $result
	 * @param \EM_Booking $EM_Booking
	 * @return bool
	 */
	public static function cleanup_files( $result, $EM_Booking ) {
		if ( ! empty( $EM_Booking->booking_meta['booking'] ) && is_array( $EM_Booking->booking_meta['booking'] ) ) {
			static::unlink_signature_files( $EM_Booking->booking_meta['booking'] );
		}
		if ( method_exists( $EM_Booking, 'get_tickets_bookings' ) ) {
			foreach ( $EM_Booking->get_tickets_bookings()->tickets_bookings as $EM_Ticket_Bookings ) {
				foreach ( $EM_Ticket_Bookings as $EM_Ticket_Booking ) {
					if ( ! empty( $EM_Ticket_Booking->meta ) && is_array( $EM_Ticket_Booking->meta ) ) {
						static::unlink_signature_files( $EM_Ticket_Booking->meta );
					}
				}
			}
		}
		return $result;
	}

	/**
	 * Unlinks the on-disk PNG for every signature field found in a meta array.
	 * @param array $meta
	 */
	protected static function unlink_signature_files( $meta ) {
		foreach ( $meta as $value ) {
			if ( ! empty( $value['signature'] ) && ! empty( $value['files'] ) && is_array( $value['files'] ) ) {
				foreach ( $value['files'] as $file ) {
					if ( ! empty( $file['file'] ) && file_exists( $file['file'] ) ) {
						@unlink( $file['file'] );
					}
				}
			}
		}
	}

	/**
	 * Schedules a single finalize pass for each booking whose signatures were captured this request. Runs at shutdown so it covers both the inline checkout save and the standalone signing page (which never triggers em_booking_save), and defers dompdf's latency/memory to a cron request rather than the user-facing POST.
	 */
	public static function flush_pending_finalize() {
		if ( empty( static::$pending ) || ! function_exists( 'wp_schedule_single_event' ) ) {
			static::$pending = array();
			return;
		}
		foreach ( static::$pending as $EM_Booking ) {
			if ( $EM_Booking instanceof \EM_Booking && ! empty( $EM_Booking->booking_id ) ) {
				// Identical (hook, args) within a short window are de-duplicated by WP, so multiple captures on one booking schedule one pass.
				wp_schedule_single_event( time(), 'em_pro_signature_finalize', array( (int) $EM_Booking->booking_id ) );
			}
		}
		static::$pending = array();
	}

	/**
	 * Finalize pass (cron): generate the certificate PDF for every signed-but-uncertified signature on the booking — booking-form and attendee — and email the signer one copy of everything newly signed since the last pass. Idempotent: certificate generation skips already-certified values, and the signer copy is gated by a per-booking `signature_emailed` marker so a re-run or a later edit never re-sends the same document.
	 * @param int $booking_id
	 */
	public static function finalize( $booking_id ) {
		$EM_Booking = function_exists( 'em_get_booking' ) ? em_get_booking( (int) $booking_id ) : false;
		if ( empty( $EM_Booking->booking_id ) ) {
			return;
		}
		$emailed = (array) ( $EM_Booking->booking_meta['signature_emailed'] ?? array() );
		$items   = array();
		$newly   = array();

		// Booking-form signatures.
		if ( class_exists( 'EM_Booking_Form' ) ) {
			$EM_Form = \EM_Booking_Form::get_form( $EM_Booking->event_id, $EM_Booking );
			if ( $EM_Form && ! empty( $EM_Form->form_fields ) ) {
				$changed = false;
				foreach ( $EM_Form->form_fields as $fid => $field ) {
					$fv = $EM_Booking->booking_meta['booking'][ $fid ] ?? null;
					if ( ( $field['type'] ?? '' ) !== 'signature' || ! is_array( $fv ) || empty( $fv['files'] ) || empty( $fv['signature'] ) ) {
						continue;
					}
					if ( empty( $fv['certificate']['uuid'] ) ) {
						$fv = Certificate::generate( $EM_Booking, $field, $fv );
						if ( ! empty( $fv['certificate']['uuid'] ) ) {
							$EM_Booking->booking_meta['booking'][ $fid ] = $fv;
							$changed                                     = true;
						}
					}
					$key = 'booking:' . $fid;
					if ( ! in_array( $key, $emailed, true ) ) {
						$items[] = static::email_item( $field, $fv );
						$newly[] = $key;
					}
				}
				if ( $changed ) {
					$EM_Booking->update_meta( 'booking', $EM_Booking->booking_meta['booking'] );
				}
			}
		}

		// Attendee-form signatures, per ticket booking.
		if ( class_exists( 'EM_Attendees_Form' ) ) {
			$EM_Attendee_Form = \EM_Attendees_Form::get_form( $EM_Booking->get_event() );
			if ( $EM_Attendee_Form && ! empty( $EM_Attendee_Form->form_fields ) ) {
				$sig_fields = array();
				foreach ( $EM_Attendee_Form->form_fields as $fid => $field ) {
					if ( ( $field['type'] ?? '' ) === 'signature' ) {
						$sig_fields[ $fid ] = $field;
					}
				}
				if ( ! empty( $sig_fields ) ) {
					foreach ( $EM_Booking->get_tickets_bookings()->tickets_bookings as $EM_Ticket_Bookings ) {
						foreach ( $EM_Ticket_Bookings as $EM_Ticket_Booking ) {
							$tb_changed = false;
							foreach ( $sig_fields as $fid => $field ) {
								$fv = $EM_Ticket_Booking->meta[ $fid ] ?? null;
								if ( ! is_array( $fv ) || empty( $fv['files'] ) || empty( $fv['signature'] ) ) {
									continue;
								}
								if ( empty( $fv['certificate']['uuid'] ) ) {
									$fv = Certificate::generate( $EM_Booking, $field, $fv );
									if ( ! empty( $fv['certificate']['uuid'] ) ) {
										$EM_Ticket_Booking->meta[ $fid ] = $fv;
										$tb_changed                      = true;
									}
								}
								$key = 'att:' . $EM_Ticket_Booking->ticket_booking_id . ':' . $fid;
								if ( ! in_array( $key, $emailed, true ) ) {
									$items[] = static::email_item( $field, $fv );
									$newly[] = $key;
								}
							}
							if ( $tb_changed ) {
								$EM_Ticket_Booking->save_meta(); // full rewrite, so the grown files map + certificate siblings persist cleanly
							}
						}
					}
				}
			}
		}

		// The completion emails mark a "fully signed" milestone, so they wait until nothing is left outstanding on
		// the whole booking. Certificates above are still generated per signature as they come in.
		if ( ! empty( $items ) && ! static::has_outstanding( $EM_Booking ) && Signature_Emails::send_completion( $EM_Booking, $items ) ) {
			$EM_Booking->update_meta( 'signature_emailed', array_values( array_unique( array_merge( $emailed, $newly ) ) ) );
		}
	}

	/**
	 * One signature's contribution to the signer-copy email: a summary plus the best available attachment (the certificate PDF, or the signature PNG when no certificate could be produced).
	 * @param array $field
	 * @param array $field_value
	 * @return array
	 */
	protected static function email_item( $field, $field_value ) {
		$sig  = $field_value['signature'] ?? array();
		$pdf  = Certificate::pdf_file( $field_value );
		$img  = Certificate::image_file( $field_value );
		$file = $pdf['file'] ?? ( $img['file'] ?? '' );
		return array(
			'label'   => ! empty( $field['label'] ) ? $field['label'] : __( 'Signature', 'em-pro' ),
			'consent' => $sig['consent_text'] ?? '',
			'version' => $sig['consent_version'] ?? '',
			'signed'  => $sig['signed_utc'] ?? '',
			'signer'  => $sig['signer']['name'] ?? '',
			'file'    => ( $file !== '' && file_exists( $file ) ) ? $file : '',
		);
	}

	/**
	 * Daily retention sweep. Deletes signature PNGs whose per-field retention window (options_signature_retention_days, captured into each signature at signing time) has elapsed, and marks the audit record erased so the booking history shows a signature existed without keeping the image. Bounded per run and idempotent.
	 *
	 * Note: this scans bookings that carry signature data via a targeted meta query; validate the query cost against a live dataset before enabling aggressive schedules.
	 */
	public static function run_retention() {
		if ( ! static::retention_enabled() ) {
			return;
		}
		global $wpdb;
		if ( ! defined( 'EM_BOOKINGS_META_TABLE' ) ) {
			return;
		}
		$now         = time();
		$key_like    = $wpdb->esc_like( '_booking|' ) . '%'; // escape the literal leading underscore so it isn't a LIKE wildcard
		$val_like    = '%' . $wpdb->esc_like( '"signature"' ) . '%';
		$booking_ids = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT booking_id FROM ' . EM_BOOKINGS_META_TABLE . ' WHERE meta_key LIKE %s AND meta_value LIKE %s LIMIT 200', $key_like, $val_like ) );
		foreach ( (array) $booking_ids as $booking_id ) {
			$EM_Booking = em_get_booking( $booking_id );
			if ( empty( $EM_Booking->booking_id ) || empty( $EM_Booking->booking_meta['booking'] ) ) {
				continue;
			}
			$changed = false;
			foreach ( $EM_Booking->booking_meta['booking'] as $fid => $value ) {
				if ( empty( $value['signature']['retention_days'] ) || empty( $value['signature']['signed_utc'] ) || empty( $value['files'] ) ) {
					continue;
				}
				$expires = strtotime( $value['signature']['signed_utc'] ) + ( (int) $value['signature']['retention_days'] * DAY_IN_SECONDS );
				if ( $expires > $now ) {
					continue;
				}
				foreach ( $value['files'] as $file ) {
					if ( ! empty( $file['file'] ) && file_exists( $file['file'] ) ) {
						@unlink( $file['file'] );
					}
				}
				$EM_Booking->booking_meta['booking'][ $fid ]['files']               = array();
				$EM_Booking->booking_meta['booking'][ $fid ]['signature']['erased'] = gmdate( 'Y-m-d\TH:i:s\Z' );
				$changed                                                            = true;
			}
			if ( $changed ) {
				$EM_Booking->update_meta( 'booking', $EM_Booking->booking_meta['booking'] );
			}
		}
	}

	/**
	 * The consent document a signer actually sees and signs, with its EM placeholders resolved. Personalised against the booking only when one is already persisted (signing page, booking edit) — otherwise event details only — so the display-time and save-time renders match. Returns the canonical form: rendered then wp_kses_post'd, pre-wpautop (which stays presentation-only).
	 * @param array            $field
	 * @param \EM_Booking|null $EM_Booking
	 * @return string
	 */
	public static function displayed_consent( $field, $EM_Booking = null ) {
		$persisted = ( $EM_Booking instanceof \EM_Booking ) && ! empty( $EM_Booking->booking_id );
		return static::render_consent( $field, $EM_Booking, $persisted ? 'booking' : 'event' );
	}

	/**
	 * Every consent rendering the save side will accept: event-only, plus booking-personalised when a booking is available. save() stores whichever one reproduces the hash the signer was shown, so a signature captured inline (event context) or on the signing page (booking context) both stay honest without the save side having to know which surface it came from.
	 * @param array            $field
	 * @param \EM_Booking|null $EM_Booking
	 * @return string[]  canonical strings, event first
	 */
	protected static function consent_candidates( $field, $EM_Booking = null ) {
		$out = array( static::render_consent( $field, $EM_Booking, 'event' ) );
		if ( ( $EM_Booking instanceof \EM_Booking ) && ! empty( $EM_Booking->booking_id ) ) {
			try {
				$booking = static::render_consent( $field, $EM_Booking, 'booking' );
				if ( ! in_array( $booking, $out, true ) ) {
					$out[] = $booking;
				}
			} catch ( \Throwable $e ) { // a half-built booking mid-save must never fatal the capture
				unset( $e );
			}
		}
		return $out;
	}

	/**
	 * Renders the field's consent template in one context: 'booking' resolves booking + event placeholders, 'event' resolves event placeholders only (booking-person placeholders are left literal — the documented limitation of inline capture). Returns the canonical form (rendered + wp_kses_post, pre-wpautop). kses runs after rendering because booking placeholders inject signer-supplied data.
	 * @param array            $field
	 * @param \EM_Booking|null $EM_Booking
	 * @param string           $mode  'booking' | 'event'
	 * @return string
	 */
	public static function render_consent( $field, $EM_Booking, $mode ) {
		$text = ! empty( $field['options_signature_consent'] ) ? $field['options_signature_consent'] : '';
		if ( $text === '' ) {
			return '';
		}
		$rendered = $text;
		if ( $mode === 'booking' && $EM_Booking instanceof \EM_Booking ) {
			$rendered = $EM_Booking->output( $text, 'raw' );
		} else {
			$EM_Event = static::consent_event( $EM_Booking );
			if ( $EM_Event ) {
				$rendered = $EM_Event->output( $text, 'raw' );
			}
		}
		return wp_kses_post( $rendered );
	}

	/**
	 * The event a consent renders against when there is no persisted booking: the booking's event where known, else the event currently in scope on the booking form.
	 * @param \EM_Booking|null $EM_Booking
	 * @return \EM_Event|null
	 */
	protected static function consent_event( $EM_Booking ) {
		if ( $EM_Booking instanceof \EM_Booking && method_exists( $EM_Booking, 'get_event' ) ) {
			$event = $EM_Booking->get_event();
			if ( $event ) {
				return $event;
			}
		}
		return ( ! empty( $GLOBALS['EM_Event'] ) && $GLOBALS['EM_Event'] instanceof \EM_Event ) ? $GLOBALS['EM_Event'] : null;
	}

	/**
	 * Renders the field: the consent document (versioned) and a click-to-sign area that opens the signing modal, which becomes a preview of the signature once signed. The capture surface itself lives in a single shared modal built by the JS — an inline pad is a poor affordance and eats form space. The signed image is submitted as a base64 PNG data URI in a hidden input named after the field, so it flows through EM_Form's existing $_REQUEST → field_values path with no multipart handling.
	 *
	 * @param \EM_Form $EM_Form
	 * @param array    $field
	 * @param mixed    $field_value  Existing saved value (audit bundle + files) when re-displaying, or the raw posted data URI on re-render after an error.
	 */
	public static function output_field_input( $EM_Form, $field, $field_value = null ) {
		// No enqueue here: booking forms load the assets via EM's asset group, and enqueueing again would fetch the same file under a second URL — two script instances, two shared modals, one left open behind the other. The signing page enqueues explicitly before wp_head().
		$field_name = ! empty( $field['name'] ) ? $field['name'] : $field['fieldid'];
		$field_id   = $field['fieldid'];
		$modes      = ! empty( $field['options_signature_modes'] ) ? $field['options_signature_modes'] : 'both';
		$display    = ! empty( $field['options_signature_display'] ) ? $field['options_signature_display'] : 'modal';
		$version    = ! empty( $field['options_signature_version'] ) ? $field['options_signature_version'] : '';
		// Consent placeholders resolve against the booking on the signing page/edit, event-only inline. The signer is shown this exact string; its hash rides along in --doc so save() can prove it hasn't changed underneath them.
		global $EM_Booking;
		$consent    = static::displayed_consent( $field, $EM_Booking instanceof \EM_Booking ? $EM_Booking : null );
		$doc_hash   = $consent !== '' ? hash( 'sha256', $consent ) : '';
		$esign_text = ! empty( $field['options_signature_esign_text'] ) ? $field['options_signature_esign_text'] : __( 'I agree to sign this document electronically, and understand my electronic signature is legally binding.', 'em-pro' );
		$require_ack = static::requires_ack( $field );
		$label      = ! empty( $field['label'] ) ? $field['label'] : __( 'Signature', 'em-pro' );
		// An already-saved signature previews from its stored file and leaves the hidden input empty, so an untouched re-save preserves it rather than re-writing the sealed record.
		$already     = is_array( $field_value ) && ! empty( $field_value['files'] );
		$preview_url = '';
		if ( $already ) {
			$uuid        = $field_value['image_uuid'] ?? key( $field_value['files'] ); // the image, not a certificate that later joined the map
			$preview_url = Uploads::get_file_url( $uuid, $field, $field_value );
		}
		// The typed-name and acknowledgement sub-inputs must nest exactly like the field itself, so on an attendee form (name `em_tickets[T][ticket_bookings][%n][attendee][field]`) they post under the same request path the read side looks in — otherwise both are lost there. On a flat booking form field_name === field_id and this is just the suffixed id.
		$name_field  = static::sub_input_name( $field_name, $field_id, '--name' );
		$esign_field = static::sub_input_name( $field_name, $field_id, '--esign' );
		$doc_field   = static::sub_input_name( $field_name, $field_id, '--doc' );
		emp_locate_template( 'form-fields/signatures/field.php', true, compact( 'field_id', 'field_name', 'name_field', 'esign_field', 'doc_field', 'doc_hash', 'modes', 'display', 'version', 'consent', 'esign_text', 'require_ack', 'label', 'already', 'preview_url', 'field_value' ) );
	}

	/**
	 * Builds a sibling input name that nests like the field's own `name`, so companion sub-inputs (typed name, acknowledgement) travel under the same request path as the data URI. Flat field → `field--suffix`; nested field ending `[field]` → the trailing segment becomes `[field--suffix]`, preserving any `%n` clone placeholder for attendee-forms.js.
	 * @param string $field_name
	 * @param string $field_id
	 * @param string $suffix  e.g. '--name'
	 * @return string
	 */
	protected static function sub_input_name( $field_name, $field_id, $suffix ) {
		if ( $field_name === $field_id ) {
			return $field_id . $suffix;
		}
		return preg_replace( '/\[' . preg_quote( $field_id, '/' ) . '\]$/', '[' . $field_id . $suffix . ']', $field_name );
	}

	/**
	 * Whether a field asks the signer to tick an e-sign acknowledgement before signing. On by default, so fields saved before the option existed keep showing it.
	 * @param array $field
	 * @return bool
	 */
	public static function requires_ack( $field ) {
		return ! isset( $field['options_signature_require_ack'] ) || ! empty( $field['options_signature_require_ack'] );
	}

	/**
	 * Short human summary of a stored signature for admin/email display.
	 * @param array $field_value
	 * @return string
	 */
	public static function caption( $field_value ) {
		$sig = ! empty( $field_value['signature'] ) ? $field_value['signature'] : array();
		if ( empty( $sig ) ) {
			return '';
		}
		$parts = array();
		if ( ! empty( $sig['signed_utc'] ) ) {
			$parts[] = sprintf( __( 'Signed %s UTC', 'em-pro' ), $sig['signed_utc'] );
		}
		if ( ! empty( $sig['consent_version'] ) ) {
			$parts[] = sprintf( __( 'version %s', 'em-pro' ), $sig['consent_version'] );
		}
		$parts[] = static::verify( $field_value ) ? __( 'integrity verified', 'em-pro' ) : __( 'INTEGRITY CHECK FAILED', 'em-pro' );
		return implode( ' · ', $parts );
	}

	/**
	 * The full, verifiable audit envelope of a stored signature — the equivalent of a certificate of completion — rendered as label/value rows for admin booking screens so the signature's provenance can be checked, not just its image.
	 * @param array $field_value
	 * @return array  Ordered label => value pairs.
	 */
	public static function envelope( $field_value ) {
		$sig = ! empty( $field_value['signature'] ) ? $field_value['signature'] : array();
		if ( empty( $sig ) ) {
			return array();
		}
		$signer = ! empty( $sig['signer'] ) ? $sig['signer'] : array();
		$who    = trim( ( $signer['name'] ?? '' ) . ( ! empty( $signer['email'] ) ? ' <' . $signer['email'] . '>' : '' ) );
		if ( $who === '' ) {
			$who = ! empty( $signer['user_id'] ) ? sprintf( __( 'user #%d', 'em-pro' ), $signer['user_id'] ) : __( 'unknown', 'em-pro' );
		}
		return array(
			__( 'Signatory', 'em-pro' )       => $who,
			__( 'Signed (UTC)', 'em-pro' )     => $sig['signed_utc'] ?? '',
			__( 'Method', 'em-pro' )           => ( ( $sig['mode'] ?? '' ) === 'typed' ) ? __( 'Typed name', 'em-pro' ) : __( 'Drawn', 'em-pro' ),
			__( 'Document version', 'em-pro' ) => $sig['consent_version'] ?? '',
			__( 'E-sign consent', 'em-pro' )   => ! empty( $sig['esign_consent'] ) ? __( 'Yes', 'em-pro' ) : __( 'No', 'em-pro' ),
			__( 'IP address', 'em-pro' )       => $sig['ip'] ?? '',
			__( 'User agent', 'em-pro' )       => $sig['user_agent'] ?? '',
			__( 'Integrity', 'em-pro' )        => static::verify( $field_value ) ? __( 'Verified — seal intact', 'em-pro' ) : __( 'FAILED — record altered', 'em-pro' ),
		);
	}

	/**
	 * Validates a posted signature value. Throws EM_Exception on failure so callers add it as a booking error.
	 * @param array  $field
	 * @param string $value  The posted data URI.
	 * @param bool   $has_existing  Whether a signature was already saved (so a blank re-submit on edit is allowed).
	 * @throws EM_Exception
	 */
	public static function validate( $field, $value, $has_existing = false, $esign = null ) {
		// A "sign later" field is never rendered on the initial form, so it can never be required there — it's completed afterwards via the signing page.
		$required = ! empty( $field['required'] ) && ! static::is_sign_later( $field );
		if ( empty( $value ) ) {
			if ( $required && ! $has_existing ) {
				$err = ! empty( $field['options_signature_error'] ) ? $field['options_signature_error'] : sprintf( __( '%s is required.', 'em-pro' ), $field['label'] );
				throw new EM_Exception( $err, 'signature_required' );
			}
			return; // optional and empty, or already signed on a re-save
		}
		static::decode( $value ); // throws if not a valid, sane PNG data URI
		// A sealed record attests "E-sign consent: Yes", so it must never be minted for a signature the signer didn't acknowledge; the modal gates on this client-side, this refuses it server-side.
		if ( $esign !== null && static::requires_ack( $field ) && empty( $esign ) ) {
			throw new EM_Exception( __( 'Please tick the box to confirm you agree to sign electronically.', 'em-pro' ), 'signature_esign_required' );
		}
	}

	/**
	 * Decodes and sanity-checks a base64 PNG data URI, returning the raw binary.
	 * @param string $value
	 * @return string
	 * @throws EM_Exception
	 */
	protected static function decode( $value ) {
		$prefix = 'data:image/png;base64,';
		if ( strpos( $value, $prefix ) !== 0 ) {
			throw new EM_Exception( __( 'The signature could not be read. Please sign again.', 'em-pro' ), 'signature_invalid' );
		}
		$binary = base64_decode( substr( $value, strlen( $prefix ) ), true );
		if ( $binary === false || strncmp( $binary, self::PNG_MAGIC, 8 ) !== 0 ) {
			throw new EM_Exception( __( 'The signature could not be read. Please sign again.', 'em-pro' ), 'signature_invalid' );
		}
		if ( strlen( $binary ) > self::MAX_BYTES ) {
			throw new EM_Exception( __( 'The signature image is too large.', 'em-pro' ), 'signature_too_large' );
		}
		return $binary;
	}

	/**
	 * Persists a posted signature: writes the PNG through the form-uploads infrastructure and builds the sealed audit bundle. Returns the field value to store in booking/attendee meta, or null when nothing was signed.
	 *
	 * @param \EM_Form         $EM_Form
	 * @param array            $field
	 * @param string           $value  The posted data URI.
	 * @param \EM_Booking|null  $EM_Booking  The booking being signed, used to attribute the signer from its own person/registration (falls back to the global booking, then to submitted request data).
	 * @return array|null
	 */
	public static function save( $EM_Form, $field, $value, $EM_Booking = null ) {
		if ( empty( $value ) ) {
			return null;
		}
		if ( ! ( $EM_Booking instanceof \EM_Booking ) ) {
			$EM_Booking = ( isset( $GLOBALS['EM_Booking'] ) && $GLOBALS['EM_Booking'] instanceof \EM_Booking ) ? $GLOBALS['EM_Booking'] : null;
		}
		try {
			$binary = static::decode( $value );
		} catch ( EM_Exception $ex ) {
			$EM_Form->add_error( $ex );
			return null;
		}
		$field_id  = $field['fieldid'];
		$subfolder = is_string( $EM_Form->uploads_subfolder ) ? trim( $EM_Form->uploads_subfolder, '/\\' ) : '';
		$dir       = Uploads::get_endpoint_dir( $subfolder ); // also writes the deny-all .htaccess
		wp_mkdir_p( $dir );
		$uuid        = md5( uniqid( (string) $field_id, true ) );
		$prefix      = ! empty( $EM_Form->uploads_endpoint_uuid ) ? $EM_Form->uploads_endpoint_uuid . '-' : '';
		$filename    = $prefix . $field_id . '-' . $uuid . '.png';
		$filepath    = trailingslashit( $dir ) . $filename;
		if ( file_put_contents( $filepath, $binary ) === false ) {
			$EM_Form->add_error( __( 'The signature could not be saved.', 'em-pro' ) );
			return null;
		}
		$uploads_dir = Uploader::upload_dir( false, Uploads::$uploads_folder );
		$file_url    = trailingslashit( $uploads_dir['url'] ) . ( $subfolder !== '' ? trailingslashit( $subfolder ) : '' ) . $filename;

		$request    = Utils::_request( $EM_Form->_request_path );
		$typed_name = ! empty( $request[ $field_id . '--name' ] ) ? sanitize_text_field( $request[ $field_id . '--name' ] ) : '';
		// Seal the consent exactly as the signer saw it: store whichever rendering reproduces the --doc hash they were shown. If none does, the terms changed between display and submit (an admin edit, or tampering) — refuse to seal a document they never read.
		$posted_doc = isset( $request[ $field_id . '--doc' ] ) ? (string) $request[ $field_id . '--doc' ] : '';
		$candidates = static::consent_candidates( $field, $EM_Booking );
		$consent    = $candidates[0] ?? '';
		if ( $posted_doc !== '' ) {
			$consent = null;
			foreach ( $candidates as $candidate ) {
				if ( hash_equals( hash( 'sha256', $candidate ), $posted_doc ) ) {
					$consent = $candidate;
					break;
				}
			}
			if ( $consent === null ) {
				$EM_Form->add_error( __( 'The consent terms have been updated. Please review and sign again.', 'em-pro' ) );
				return null;
			}
		}
		$signer     = static::resolve_signer( $EM_Booking, $EM_Form, $request, $typed_name );
		// The signer's real acknowledgement, posted from the modal's tick-box; sealed as given so the audit record can't claim consent that wasn't ticked. A field that doesn't ask for it records none.
		$esign_consent = static::requires_ack( $field ) && ! empty( $request[ $field_id . '--esign' ] );

		$bundle = array(
			'mode'              => $typed_name !== '' ? 'typed' : 'draw',
			'typed_name'        => $typed_name,
			'consent_text'      => $consent,
			'consent_text_hash' => $consent !== '' ? hash( 'sha256', $consent ) : '',
			'consent_version'   => ! empty( $field['options_signature_version'] ) ? $field['options_signature_version'] : '',
			'signer'            => $signer,
			'signed_utc'        => gmdate( 'Y-m-d\TH:i:s\Z' ),
			'ip'                => static::client_ip(),
			'user_agent'        => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			'esign_consent'     => $esign_consent,
			'retention_days'    => ! empty( $field['options_signature_retention_days'] ) ? absint( $field['options_signature_retention_days'] ) : 0,
		);
		$bundle['record_hmac'] = static::hmac( $bundle );

		if ( $EM_Booking instanceof \EM_Booking ) {
			static::$pending[ spl_object_id( $EM_Booking ) ] = $EM_Booking; // finalize (certificate + signer-copy email) is scheduled once at request shutdown
		}
		return array(
			'files'     => array(
				$uuid => array(
					'name' => 'signature.png',
					'url'  => $file_url,
					'file' => $filepath,
				),
			),
			'endpoint'  => $EM_Form->uploads_endpoint_uuid,
			'subfolder' => $EM_Form->uploads_subfolder,
			'signature' => $bundle,
		);
	}

	/**
	 * Computes the HMAC seal over the audit bundle. Keyed on wp_salt('auth'), so a value edited through the admin UI or booking-edit path no longer verifies. This does not defend against an attacker who also holds the salts (a hostile DB admin) — that residual risk is what an external provider's certificate addresses in phase 2.
	 * @param array $bundle
	 * @return string
	 */
	protected static function hmac( $bundle ) {
		unset( $bundle['record_hmac'] );
		ksort( $bundle );
		return hash_hmac( 'sha256', wp_json_encode( $bundle ), wp_salt( 'auth' ) );
	}

	/**
	 * Re-derives the HMAC and compares it to the stored seal.
	 * @param array $field_value
	 * @return bool
	 */
	public static function verify( $field_value ) {
		if ( empty( $field_value['signature']['record_hmac'] ) ) {
			return false;
		}
		$stored = $field_value['signature']['record_hmac'];
		return hash_equals( $stored, static::hmac( $field_value['signature'] ) );
	}

	/**
	 * Best-effort client IP for the audit trail. Uses REMOTE_ADDR only; proxy headers are spoofable and deployments that terminate behind a trusted proxy should map the real IP into REMOTE_ADDR upstream.
	 * @return string
	 */
	protected static function client_ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}

	/**
	 * Resolves the signer's identity for the sealed audit record. Prefers the booking's own person, which EM populates from the registration fields for a guest (no account) and from the user account when logged in — so the signature is attributed from the same place the booking stores its user meta, and it works for both inline and second-step (signing-page) flows. Falls back to a user id the form knows about, then to the values submitted with the request.
	 * @param \EM_Booking|null $EM_Booking
	 * @param \EM_Form         $EM_Form
	 * @param array            $request
	 * @param string           $typed_name
	 * @return array  array( 'user_id' => int, 'email' => string, 'name' => string )
	 */
	protected static function resolve_signer( $EM_Booking, $EM_Form, $request, $typed_name ) {
		$user_id = 0;
		$email   = '';
		$name    = '';
		if ( $EM_Booking instanceof \EM_Booking ) {
			$person = $EM_Booking->get_person();
			if ( $person ) {
				$user_id = (int) $person->ID;
				$email   = $person->user_email;
				$name    = method_exists( $person, 'get_name' ) ? $person->get_name() : $person->display_name;
			}
		}
		if ( $email === '' && ! empty( $EM_Form->uploads_user_id ) ) {
			$user = get_userdata( absint( $EM_Form->uploads_user_id ) );
			if ( $user ) {
				$user_id = $user_id ?: (int) $user->ID;
				$email   = $user->user_email;
				$name    = $name !== '' ? $name : $user->display_name;
			}
		}
		if ( $email === '' && ! empty( $request['user_email'] ) && is_email( $request['user_email'] ) ) {
			$email = sanitize_email( $request['user_email'] );
		}
		if ( $name === '' ) {
			$name = $typed_name !== '' ? $typed_name : ( ! empty( $request['user_name'] ) ? sanitize_text_field( $request['user_name'] ) : '' );
		}
		return array(
			'user_id' => $user_id,
			'email'   => $email,
			'name'    => $name,
		);
	}

	/**
	 * Formats a stored signature for display in admin booking screens, emails and exports.
	 * @param \EM_Booking_Form|\EM_Form $EM_Form
	 * @param array  $field
	 * @param array  $field_value
	 * @param string $format  html|email|text|table
	 * @return string
	 */
	public static function get_formatted_value( $EM_Form, $field, $field_value, $format = 'html' ) {
		$signed = is_array( $field_value ) && ! empty( $field_value['files'] );
		// Concise formats — emails, text exports, list-table cells — get a one-liner, never the panel.
		if ( $format === 'email' || $format === 'text' || $format === 'table' ) {
			if ( ! $signed ) {
				return __( 'Not signed', 'em-pro' );
			}
			$image_uuid = $field_value['image_uuid'] ?? key( $field_value['files'] );
			return Uploads::get_file_url( $image_uuid, $field, $field_value ) . ' (' . static::caption( $field_value ) . ')';
		}
		// Rich HTML (admin booking screen): signed → image + certificate link + collapsible audit envelope;
		// unsigned → "Not signed" with a sign-now link to this booking's signing page when in scope.
		$url      = '';
		$cert_url = '';
		$envelope = array();
		if ( $signed ) {
			$image_uuid = $field_value['image_uuid'] ?? key( $field_value['files'] ); // the pointer, not the first file, once a certificate has joined the map
			$url        = Uploads::get_file_url( $image_uuid, $field, $field_value );
			$envelope   = static::envelope( $field_value );
			if ( ! empty( $field_value['certificate_uuid'] ) ) {
				$cert_url = Uploads::get_file_url( $field_value['certificate_uuid'], $field, $field_value );
			}
		}
		$sign_url = '';
		if ( ! $signed ) {
			global $EM_Booking;
			if ( $EM_Booking instanceof \EM_Booking && ! empty( $EM_Booking->booking_id ) ) {
				$sign_url = Signing::url( $EM_Booking );
			}
		}
		ob_start();
		emp_locate_template( 'form-fields/signatures/value.php', true, compact( 'signed', 'url', 'cert_url', 'envelope', 'sign_url' ) );
		return ob_get_clean();
	}
}
Signatures::init();

<?php
namespace EM\Bookings;

/**
 * Signature emailing: the settings-page section and the two delivery paths.
 *
 *  1. Attach signed documents (the certificate PDF where generated, else the signature image) to the standard
 *     booking status emails — separately toggleable for the registrant and the admin copies. This is the path
 *     for signatures captured inline on the booking form, which already exist when the booking email is sent.
 *  2. Send a dedicated completion email to the registrant and/or the admin once every required signature is in,
 *     each from an editable subject/body template (blank subject disables that email, per EM convention).
 *
 * All templates run through EM_Booking::output(), so they support the usual booking/event placeholders.
 */
class Signature_Emails {

	public static function init() {
		static::seed_defaults();
		add_action( 'em_options_page_footer_emails', array( static::class, 'settings' ) );
		add_filter( 'em_booking_email_messages', array( static::class, 'attach_to_booking_emails' ), 1000, 2 );
	}

	/**
	 * The default subject/body templates. Seeded once so the settings page shows editable defaults on an
	 * existing install (options that don't exist yet render as blank textareas otherwise).
	 * @return array
	 */
	protected static function defaults() {
		return array(
			'dbem_signature_email_user_subject'  => __( 'Your signed documents for #_EVENTNAME', 'em-pro' ),
			'dbem_signature_email_user_body'     => __( "Dear #_BOOKINGNAME,\n\nThank you. Every document for your booking has now been signed, and a copy of each is attached for your records.\n\n#_EVENTNAME\n#_EVENTDATES\n\nPlease keep this email for your records.", 'em-pro' ),
			'dbem_signature_email_admin_subject' => __( 'Signatures completed for booking #_BOOKINGID', 'em-pro' ),
			'dbem_signature_email_admin_body'    => __( "All required signatures have been completed for the booking below.\n\n#_EVENTNAME\nBooking ##_BOOKINGID by #_BOOKINGNAME (#_BOOKINGEMAIL)\n\nThe signed document(s) are attached.", 'em-pro' ),
		);
	}

	protected static function seed_defaults() {
		if ( ! function_exists( 'get_option' ) || get_option( 'dbem_signature_emails_seeded' ) === '1' ) {
			return;
		}
		foreach ( static::defaults() as $key => $value ) {
			add_option( $key, $value );
		}
		add_option( 'dbem_signature_attach_user', 0 );
		add_option( 'dbem_signature_attach_admin', 0 );
		update_option( 'dbem_signature_emails_seeded', '1' );
	}

	/**
	 * The "Signature Emails" section on the settings-page Emails tab.
	 */
	public static function settings() {
		global $save_button, $bookings_placeholder_tip;
		?>
		<div class="postbox" id="em-opt-signature-emails">
			<div class="handlediv" title="<?php esc_attr_e( 'Click to toggle', 'em-pro' ); ?>"><br /></div>
			<h3><?php esc_html_e( 'Signature Emails', 'em-pro' ); ?></h3>
			<div class="inside">
				<table class="form-table">
					<tr class="em-boxheader">
						<td colspan="2">
							<p><?php esc_html_e( 'Control how signed documents (and their certificate PDFs) are emailed. Attach them to your normal booking emails, and/or send a dedicated confirmation once every signature is complete.', 'em-pro' ); ?></p>
						</td>
					</tr>
					<?php
					em_options_radio_binary( __( 'Attach signatures to the booking email?', 'em-pro' ), 'dbem_signature_attach_user', __( 'Attach each signed document — the certificate PDF where available, otherwise the signature image — to the standard booking email sent to the person who booked.', 'em-pro' ) );
					em_options_radio_binary( __( 'Attach signatures to the admin booking email?', 'em-pro' ), 'dbem_signature_attach_admin', __( 'Attach each signed document to the booking notification sent to administrators.', 'em-pro' ) );
					?>
					<tr class="em-header">
						<td colspan="2">
							<h4><?php esc_html_e( 'Completion email — registrant', 'em-pro' ); ?></h4>
							<p><?php esc_html_e( 'Sent to the person who booked once every required signature is complete, with a copy of each signed document attached. Leave the subject blank to disable.', 'em-pro' ); echo ' ' . $bookings_placeholder_tip; ?></p>
						</td>
					</tr>
					<?php
					em_options_input_text( __( 'Subject', 'em-pro' ), 'dbem_signature_email_user_subject' );
					em_options_textarea( __( 'Message', 'em-pro' ), 'dbem_signature_email_user_body' );
					?>
					<tr class="em-header">
						<td colspan="2">
							<h4><?php esc_html_e( 'Completion email — administrators', 'em-pro' ); ?></h4>
							<p><?php esc_html_e( 'Sent to your booking admin address once every required signature is complete. Leave the subject blank to disable.', 'em-pro' ); echo ' ' . $bookings_placeholder_tip; ?></p>
						</td>
					</tr>
					<?php
					em_options_input_text( __( 'Subject', 'em-pro' ), 'dbem_signature_email_admin_subject' );
					em_options_textarea( __( 'Message', 'em-pro' ), 'dbem_signature_email_admin_body' );
					echo $save_button;
					?>
				</table>
			</div>
		</div>
		<?php
	}

	/**
	 * Attaches signed documents to the standard booking status emails, per the attach toggles. Fired by the
	 * `em_booking_email_messages` filter (as the printables PDFs do). For inline-signed bookings the certificate
	 * may not exist yet when this runs, so the signature image is attached as a fallback.
	 *
	 * @param array       $msg   array( 'user' => array( ... 'attachments' ), 'admin' => array( ... 'attachments' ) )
	 * @param \EM_Booking $EM_Booking
	 * @return array
	 */
	public static function attach_to_booking_emails( $msg, $EM_Booking ) {
		$user  = get_option( 'dbem_signature_attach_user' );
		$admin = get_option( 'dbem_signature_attach_admin' );
		if ( empty( $user ) && empty( $admin ) ) {
			return $msg;
		}
		$files = static::collect_files( $EM_Booking );
		if ( empty( $files ) ) {
			return $msg;
		}
		if ( ! empty( $user ) && ! empty( $msg['user'] ) ) {
			foreach ( $files as $f ) {
				$msg['user']['attachments'][] = $f;
			}
		}
		if ( ! empty( $admin ) && ! empty( $msg['admin'] ) ) {
			foreach ( $files as $f ) {
				$msg['admin']['attachments'][] = $f;
			}
		}
		return $msg;
	}

	/**
	 * Attachment descriptors for every signed signature on the booking (booking-form and attendee): the
	 * certificate PDF where generated, else the signature image.
	 * @param \EM_Booking $EM_Booking
	 * @return array  each array( 'name', 'type', 'path', 'delete' => false )
	 */
	public static function collect_files( $EM_Booking ) {
		$files = array();
		$add   = function ( $fv ) use ( &$files ) {
			if ( ! is_array( $fv ) || empty( $fv['signature'] ) ) {
				return;
			}
			$pdf  = Certificate::pdf_file( $fv );
			$file = ! empty( $pdf['file'] ) ? $pdf : Certificate::image_file( $fv );
			if ( ! empty( $file['file'] ) && file_exists( $file['file'] ) ) {
				$files[] = array(
					'name'   => ! empty( $file['name'] ) ? $file['name'] : basename( $file['file'] ),
					'type'   => ! empty( $pdf['file'] ) ? 'application/pdf' : 'image/png',
					'path'   => $file['file'],
					'delete' => false,
				);
			}
		};
		foreach ( (array) ( $EM_Booking->booking_meta['booking'] ?? array() ) as $fv ) {
			$add( $fv );
		}
		if ( method_exists( $EM_Booking, 'get_tickets_bookings' ) ) {
			foreach ( $EM_Booking->get_tickets_bookings()->tickets_bookings as $tbs ) {
				foreach ( $tbs as $tb ) {
					foreach ( (array) $tb->meta as $fv ) {
						$add( $fv );
					}
				}
			}
		}
		return $files;
	}

	/**
	 * The dedicated completion emails (registrant + admin), templated from settings and rendered through
	 * EM_Booking::output(). Called by Signatures::finalize() when a booking's newly signed documents are
	 * finalized. Returns true once it has done its job (so the caller records the send and never repeats it),
	 * including when both emails are disabled.
	 *
	 * @param \EM_Booking $EM_Booking
	 * @param array       $items  from Signatures::email_item(): each carries a 'file' path to attach
	 * @return bool
	 */
	public static function send_completion( $EM_Booking, $items ) {
		$attachments = static::attachment_paths( $items );
		$u_subject   = (string) get_option( 'dbem_signature_email_user_subject' );
		$a_subject   = (string) get_option( 'dbem_signature_email_admin_subject' );
		$attempted   = false;

		if ( '' !== $u_subject ) {
			$person = $EM_Booking->get_person();
			$to     = $person ? $person->user_email : '';
			if ( is_email( $to ) ) {
				$subject = $EM_Booking->output( $u_subject, 'raw' );
				$body    = $EM_Booking->output( (string) get_option( 'dbem_signature_email_user_body' ), 'email' );
				wp_mail( $to, $subject, $body, array(), $attachments );
				$attempted = true;
			}
		}

		if ( '' !== $a_subject ) {
			$to = get_option( 'dbem_bookings_notify_email' );
			if ( ! is_email( $to ) ) {
				$to = get_option( 'admin_email' );
			}
			if ( is_email( $to ) ) {
				$subject = $EM_Booking->output( $a_subject, 'raw' );
				$body    = $EM_Booking->output( (string) get_option( 'dbem_signature_email_admin_body' ), 'email' );
				wp_mail( $to, $subject, $body, array(), $attachments );
				$attempted = true;
			}
		}

		return $attempted || ( '' === $u_subject && '' === $a_subject );
	}

	/**
	 * Existing file paths for wp_mail attachments, from the finalize items (certificate PDF or image per document).
	 * @param array $items
	 * @return array
	 */
	protected static function attachment_paths( $items ) {
		$paths = array();
		foreach ( (array) $items as $it ) {
			if ( ! empty( $it['file'] ) && file_exists( $it['file'] ) ) {
				$paths[] = $it['file'];
			}
		}
		return array_values( array_unique( $paths ) );
	}
}
Signature_Emails::init();

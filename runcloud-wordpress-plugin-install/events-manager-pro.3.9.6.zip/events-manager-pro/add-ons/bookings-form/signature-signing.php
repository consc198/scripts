<?php
namespace EM\Bookings;

/**
 * Second-step signing page for bookings held pending an outstanding signature. A tokened link (the `em-sign` endpoint) lets the booking owner — logged in or guest — sign the outstanding booking-form signature fields after checkout, without exposing the rest of the booking. This is the friction-reducing alternative to signing inline at checkout.
 *
 * Scope: booking-form signature fields. Per-attendee signing links are a documented follow-up.
 */
class Signing {

	public static $endpoint = 'em-sign';

	public static function init() {
		add_action( 'init', array( static::class, 'add_endpoint' ) );
		add_action( 'template_redirect', array( static::class, 'handle' ) );
	}

	public static function add_endpoint() {
		add_rewrite_endpoint( static::$endpoint, EP_ROOT );
		// Flush when the stored rules don't actually contain our endpoint — a version-marker guard alone goes stale if rules are flushed while a build without this plugin code is active (e.g. a gitree runtime switch), silently 404ing the signing page.
		$rules = get_option( 'rewrite_rules' );
		if ( ! is_array( $rules ) || ! preg_grep( '/' . preg_quote( static::$endpoint, '/' ) . '/', array_keys( $rules ) ) ) {
			flush_rewrite_rules( false );
		}
	}

	/**
	 * The signed signing-page URL for a booking. The token binds the booking uuid to the owner's email, so a link cannot be guessed or replayed against another booking.
	 * @param \EM_Booking $EM_Booking
	 * @return string
	 */
	public static function url( $EM_Booking ) {
		$base = trailingslashit( get_home_url( null, static::$endpoint . '/' . $EM_Booking->uuid ) );
		return add_query_arg( array( 't' => static::token( $EM_Booking ) ), $base );
	}

	/**
	 * @param \EM_Booking $EM_Booking
	 * @return string
	 */
	public static function token( $EM_Booking ) {
		$person = $EM_Booking->get_person();
		$email  = $person ? $person->user_email : '';
		return hash_hmac( 'sha256', $EM_Booking->uuid . '|' . $email, wp_salt( 'nonce' ) );
	}

	public static function handle() {
		global $wp_query;
		if ( ! isset( $wp_query->query_vars[ static::$endpoint ] ) ) {
			return;
		}
		$uuid       = sanitize_text_field( $wp_query->query_vars[ static::$endpoint ] );
		$token      = isset( $_GET['t'] ) ? sanitize_text_field( wp_unslash( $_GET['t'] ) ) : '';
		$EM_Booking = function_exists( 'em_get_booking' ) ? em_get_booking( $uuid ) : false;
		if ( empty( $EM_Booking ) || empty( $EM_Booking->booking_id ) || ! hash_equals( static::token( $EM_Booking ), $token ) ) {
			static::render_error( __( 'This signing link is invalid or has expired.', 'em-pro' ) );
		}
		$done = false;
		if ( ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) === 'POST' ) {
			check_admin_referer( 'em_sign_' . $EM_Booking->booking_id );
			static::save_submission( $EM_Booking );
			$done = ! Signatures::has_outstanding( $EM_Booking ); // done once nothing is left to sign anywhere on the booking, gated or not
		}
		static::render_page( $EM_Booking, $done );
	}

	/**
	 * Saves every posted signature still outstanding on the booking — booking-form fields under flat names, each attendee's fields under `att[ticket_booking_id][field]` — then recomputes the awaiting flag (which fires the completion hook and releases the hold once nothing remains).
	 * @param \EM_Booking $EM_Booking
	 */
	protected static function save_submission( $EM_Booking ) {
		$outstanding = Signatures::outstanding( $EM_Booking );
		if ( empty( $outstanding['booking'] ) && empty( $outstanding['attendees'] ) ) {
			return;
		}
		$changed = false;

		// Booking-form signatures: flat field names on this standalone page.
		if ( ! empty( $outstanding['booking'] ) && class_exists( 'EM_Booking_Form' ) ) {
			$EM_Form = \EM_Booking_Form::get_form( $EM_Booking->event_id, $EM_Booking );
			if ( ! empty( $EM_Form->form_fields ) ) {
				static::prime_uploads( $EM_Form, $EM_Booking );
				$EM_Form->_request_path = array(); // flat field names (EM_Form's default; null would warn in Utils::_request)
				foreach ( $outstanding['booking'] as $fid => $field ) {
					$posted = isset( $_POST[ $fid ] ) ? stripslashes( $_POST[ $fid ] ) : '';
					if ( $posted === '' ) {
						continue;
					}
					$saved = Signatures::save( $EM_Form, $field, $posted, $EM_Booking );
					if ( ! empty( $saved ) ) {
						$EM_Booking->booking_meta['booking'][ $fid ] = $saved;
						$changed                                     = true;
					}
				}
				if ( $changed ) {
					$EM_Booking->update_meta( 'booking', $EM_Booking->booking_meta['booking'] );
				}
			}
		}

		// Attendee-form signatures: one request path per attendee, persisted to that ticket booking's meta.
		if ( ! empty( $outstanding['attendees'] ) && class_exists( 'EM_Attendees_Form' ) ) {
			$EM_Attendee_Form = \EM_Attendees_Form::get_form( $EM_Booking->get_event() );
			if ( ! empty( $EM_Attendee_Form->form_fields ) ) {
				foreach ( $outstanding['attendees'] as $tbid => $info ) {
					$EM_Ticket_Booking = $info['ticket_booking'];
					// Attendee files serve through the `bookings/attendees` endpoint keyed by the ticket-booking uuid — match the inline attendee-form storage exactly (attendee-forms.php) or the image 404s under the wrong endpoint.
					$EM_Attendee_Form->uploads_subfolder     = 'bookings/attendees';
					$EM_Attendee_Form->uploads_endpoint_uuid = $EM_Ticket_Booking->ticket_uuid;
					$EM_Attendee_Form->uploads_filename      = $EM_Ticket_Booking->booking_id . '-' . $EM_Ticket_Booking->ticket_booking_id . '-{field_id}-{uuid}';
					$EM_Attendee_Form->uploads_user_id       = $EM_Booking->person_id;
					$EM_Attendee_Form->_request_path         = array( 'att', $tbid );
					foreach ( $info['fields'] as $fid => $field ) {
						$posted = isset( $_POST['att'][ $tbid ][ $fid ] ) ? stripslashes( $_POST['att'][ $tbid ][ $fid ] ) : '';
						if ( $posted === '' ) {
							continue;
						}
						$saved = Signatures::save( $EM_Attendee_Form, $field, $posted, $EM_Booking );
						if ( ! empty( $saved ) ) {
							$EM_Ticket_Booking->meta[ $fid ] = $saved;
							$EM_Ticket_Booking->update_meta( $fid, $saved );
							$changed                         = true;
						}
					}
				}
			}
		}

		if ( $changed ) {
			Signatures::maintain_flag( true, $EM_Booking ); // clears the flag + fires em_booking_signature_completed once nothing remains
		}
	}

	/**
	 * Points a form's upload writer at this booking's endpoint so a signature saved on the standalone page lands where the booking's permission-checked file endpoint serves it from.
	 * @param \EM_Form    $EM_Form
	 * @param \EM_Booking $EM_Booking
	 */
	protected static function prime_uploads( $EM_Form, $EM_Booking ) {
		$EM_Form->uploads_subfolder     = 'bookings';
		$EM_Form->uploads_endpoint_uuid = $EM_Booking->uuid;
		$EM_Form->uploads_filename      = $EM_Booking->booking_id . '-{field_id}-{uuid}';
		$EM_Form->uploads_user_id       = $EM_Booking->person_id;
	}

	/**
	 * @param \EM_Booking $EM_Booking
	 * @param bool        $done
	 */
	protected static function render_page( $EM_Booking, $done ) {
		nocache_headers();
		static::enqueue_theme(); // the em/pixelbones front-end stylesheet, so the bare document renders as a native EM page
		Signatures::enqueue(); // standalone page: no EM booking-form asset group here, and this must land before wp_head()
		$GLOBALS['EM_Booking'] = $EM_Booking; // so a signature field's consent personalises against this (persisted) booking, like the admin booking view
		$EM_Form          = class_exists( 'EM_Booking_Form' ) ? \EM_Booking_Form::get_form( $EM_Booking->event_id, $EM_Booking ) : false;
		$EM_Attendee_Form = class_exists( 'EM_Attendees_Form' ) ? \EM_Attendees_Form::get_form( $EM_Booking->get_event() ) : false;
		$outstanding      = Signatures::outstanding( $EM_Booking );
		static::header();
		emp_locate_template( 'form-fields/signatures/signing-page.php', true, compact( 'EM_Booking', 'done', 'EM_Form', 'EM_Attendee_Form', 'outstanding' ) );
		static::footer();
		exit;
	}

	protected static function render_error( $message ) {
		status_header( 403 );
		nocache_headers();
		static::enqueue_theme();
		static::header();
		emp_locate_template( 'form-fields/signatures/signing-error.php', true, compact( 'message' ) );
		static::footer();
		exit;
	}

	/**
	 * Enqueues EM's front-end stylesheet (core `events-manager`, plus Pro's via the `em_enqueue_styles` action) so the standalone signing document inherits the `em`/`pixelbones` theme. Must run before wp_head().
	 */
	protected static function enqueue_theme() {
		if ( class_exists( 'EM_Scripts_and_Styles' ) ) {
			\EM_Scripts_and_Styles::enqueue_public_styles();
		}
	}

	protected static function header() {
		emp_locate_template( 'form-fields/signatures/signing-header.php', true );
	}

	protected static function footer() {
		emp_locate_template( 'form-fields/signatures/signing-footer.php', true );
	}
}
Signing::init();

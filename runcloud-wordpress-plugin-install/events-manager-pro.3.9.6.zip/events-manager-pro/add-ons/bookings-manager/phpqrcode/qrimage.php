<?php
/*
 * PHP QR Code encoder
 *
 * Image output of code using GD2
 *
 * PHP QR Code is distributed under LGPL 3
 * Copyright (C) 2010 Dominik Dzienia <deltalab at poczta dot fm>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
 */
if ( extension_loaded( 'gd' ) ) {
	define( 'QR_IMAGE', true );

	class QRimage {

		//----------------------------------------------------------------------
		public static function png( $frame, $filename = false, $pixelPerPoint = 4, $outerFrame = 4, $saveandprint = false ) {
			$image = self::image( $frame, $pixelPerPoint, $outerFrame );

			if ( $filename === false ) {
				Header( 'Content-type: image/png' );
				ImagePng( $image );
			} else {
				if ( $saveandprint === true ) {
					ImagePng( $image, $filename );
					header( 'Content-type: image/png' );
					ImagePng( $image );
				} else {
					ImagePng( $image, $filename );
				}
			}

			ImageDestroy( $image );
		}

		//----------------------------------------------------------------------
		public static function jpg( $frame, $filename = false, $pixelPerPoint = 8, $outerFrame = 4, $q = 85 ) {
			$image = self::image( $frame, $pixelPerPoint, $outerFrame );

			if ( $filename === false ) {
				Header( 'Content-type: image/jpeg' );
				ImageJpeg( $image, null, $q );
			} else {
				ImageJpeg( $image, $filename, $q );
			}

			ImageDestroy( $image );
		}

		//----------------------------------------------------------------------
		private static function image( $frame, $pixelPerPoint = 4, $outerFrame = 4 ) {
			$h = count( $frame );
			$w = strlen( $frame[0] );

			$imgW = $w + 2 * $outerFrame;
			$imgH = $h + 2 * $outerFrame;

			$base_image = ImageCreate( $imgW, $imgH );

			$col[0] = ImageColorAllocate( $base_image, 255, 255, 255 );
			$col[1] = ImageColorAllocate( $base_image, 0, 0, 0 );

			imagefill( $base_image, 0, 0, $col[0] );

			for ( $y = 0; $y < $h; $y++ ) {
				for ( $x = 0; $x < $w; $x++ ) {
					if ( $frame[ $y ][ $x ] == '1' ) {
						ImageSetPixel( $base_image, $x + $outerFrame, $y + $outerFrame, $col[1] );
					}
				}
			}

			$target_image = ImageCreate( $imgW * $pixelPerPoint, $imgH * $pixelPerPoint );
			ImageCopyResized( $target_image, $base_image, 0, 0, 0, 0, $imgW * $pixelPerPoint, $imgH * $pixelPerPoint, $imgW, $imgH );
			ImageDestroy( $base_image );

			return $target_image;
		}
	}
} elseif ( class_exists( 'Imagick' ) ) {

	define( 'QR_IMAGE', true );

	class QRimage {

		//----------------------------------------------------------------------
		public static function png( $frame, $filename = false, $pixelPerPoint = 4, $outerFrame = 4, $saveandprint = false ) {
			$image = self::image( $frame, $pixelPerPoint, $outerFrame, 'png', 85, $filename, $saveandprint );
		}

		//----------------------------------------------------------------------
		public static function jpg( $frame, $filename = false, $pixelPerPoint = 8, $outerFrame = 4, $q = 85 ) {
			$image = self::image( $frame, $pixelPerPoint, $outerFrame, 'jpeg', $q, $filename, $saveandprint );
		}

		//----------------------------------------------------------------------
		private static function image( $frame, $pixelPerPoint = 4, $outerFrame = 4, $format = 'png', $quality = 85, $filename = false, $saveandprint = false ) {
			$imgH = count( $frame );
			$imgW = strlen( $frame[0] );

			$col[0] = new ImagickPixel( 'white' );
			$col[1] = new ImagickPixel( 'black' );

			$image = new Imagick();
			$image->newImage( $imgW, $imgH, $col[0] );

			$image->setCompressionQuality( $quality );
			$image->setImageFormat( $format );

			$draw = new ImagickDraw();
			$draw->setFillColor( $col[1] );

			for ( $y = 0; $y < $imgH; $y++ ) {
				for ( $x = 0; $x < $imgW; $x++ ) {
					if ( $frame[ $y ][ $x ] == '1' ) {
						$draw->point( $x, $y );
					}
				}
			}

			$image->drawImage( $draw );
			$image->borderImage( $col[0], $outerFrame, $outerFrame );
			$image->scaleImage( $imgW * $pixelPerPoint, 0 );

			if ( $filename === false ) {
				Header( 'Content-type: image/jpeg' );
				echo $image;
			} else {
				if ( $saveandprint === true ) {
					$image->writeImages( $filename, true );
					Header( 'Content-type: image/' . $format );
					echo $image;
				} else {
					echo $image;
				}
			}
		}
	}
}

<?php
/**
 * The coupon admin UI is identical for the current and legacy gateway bundles. This directory used to ship its own standalone copy of the admin screen, which drifted out of sync with the canonical add-ons/coupons/coupons-admin.php — it kept the old date-range markup after the canonical screen moved to the shared em-datepicker, so the coupon start/end date fields stopped working for Legacy PayPal users (EM Pro #614, reported since Nov 2025). Load the single canonical copy instead so the two can never diverge again. require_once on the shared absolute path also avoids a "Cannot redeclare class EM_Coupons_Admin" fatal if both bundles are ever active in the same request.
 */
require_once dirname( __DIR__, 2 ) . '/coupons/coupons-admin.php';

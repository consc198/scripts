<?php
/**
 * The AuthorizeNet PHP SDK. Include this file in your project.
 *
 * @package AuthorizeNet
 */
require __DIR__ . '/lib/shared/AuthorizeNetRequest.php';
require __DIR__ . '/lib/shared/AuthorizeNetTypes.php';
require __DIR__ . '/lib/shared/AuthorizeNetXMLResponse.php';
require __DIR__ . '/lib/shared/AuthorizeNetResponse.php';
require __DIR__ . '/lib/AuthorizeNetAIM.php';
/*
require dirname(__FILE__) . '/lib/AuthorizeNetARB.php';
require dirname(__FILE__) . '/lib/AuthorizeNetCIM.php';
require dirname(__FILE__) . '/lib/AuthorizeNetSIM.php';
require dirname(__FILE__) . '/lib/AuthorizeNetDPM.php';
require dirname(__FILE__) . '/lib/AuthorizeNetTD.php';
require dirname(__FILE__) . '/lib/AuthorizeNetCP.php';
*/

if ( class_exists( 'SoapClient' ) ) {
	require __DIR__ . '/lib/AuthorizeNetSOAP.php';
}
/**
 * Exception class for AuthorizeNet PHP SDK.
 *
 * @package AuthorizeNet
 */
class AuthorizeNetException extends Exception {

}

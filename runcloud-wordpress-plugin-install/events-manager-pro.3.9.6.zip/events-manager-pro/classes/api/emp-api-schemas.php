<?php
namespace EM_Pro\API;

class Schemas {

	public static function collection_input() {
		return array(
			'type' => 'object',
			'properties' => array(
				'page' => array( 'type' => 'integer', 'minimum' => 1 ),
				'per_page' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100 ),
				'search' => array( 'type' => 'string' ),
			),
		);
	}

	public static function id_input( $description = '' ) {
		return array(
			'type' => 'object',
			'properties' => array(
				'id' => array(
					'type' => 'string',
					'description' => $description,
				),
			),
			'required' => array( 'id' ),
		);
	}

	public static function coupon_input( $require_id = false ) {
		$schema = array(
			'type' => 'object',
			'properties' => array(
				'id' => array( 'type' => 'integer' ),
				'code' => array( 'type' => 'string' ),
				'name' => array( 'type' => 'string' ),
				'description' => array( 'type' => 'string' ),
				'start' => array( 'type' => 'string' ),
				'end' => array( 'type' => 'string' ),
				'max' => array( 'type' => 'integer' ),
				'type' => array( 'type' => 'string', 'enum' => array( '%', '#' ) ),
				'tax' => array( 'type' => 'string', 'enum' => array( 'pre', 'post' ) ),
				'discount' => array( 'type' => 'number' ),
				'eventwide' => array( 'type' => 'boolean' ),
				'sitewide' => array( 'type' => 'boolean' ),
				'private' => array( 'type' => 'boolean' ),
			),
		);
		if ( $require_id ) {
			$schema['required'] = array( 'id' );
		}
		return $schema;
	}

	public static function coupon_validate_input() {
		return array(
			'type' => 'object',
			'properties' => array(
				'id' => array( 'type' => 'integer' ),
				'event_id' => array( 'type' => 'string' ),
				'total' => array( 'type' => 'number' ),
			),
			'required' => array( 'id' ),
		);
	}

	public static function event_coupon_input( $require_coupon = true ) {
		$schema = array(
			'type' => 'object',
			'properties' => array(
				'id' => array( 'type' => 'string' ),
				'event_id' => array( 'type' => 'string' ),
				'coupon_id' => array( 'type' => 'integer' ),
			),
			'required' => array( 'event_id' ),
		);
		if ( $require_coupon ) {
			$schema['required'][] = 'coupon_id';
		}
		return $schema;
	}

	public static function booking_transactions_input() {
		return array(
			'type' => 'object',
			'properties' => array(
				'id' => array( 'type' => 'integer' ),
				'booking_id' => array( 'type' => 'integer' ),
				'page' => array( 'type' => 'integer', 'minimum' => 1 ),
				'per_page' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100 ),
				'gateway' => array( 'type' => 'string' ),
				'status' => array( 'type' => 'string' ),
				'orderby' => array( 'type' => 'string' ),
				'order' => array( 'type' => 'string', 'enum' => array( 'ASC', 'DESC' ) ),
			),
			'required' => array( 'booking_id' ),
		);
	}

	public static function attendance_input() {
		return array(
			'type' => 'object',
			'properties' => array(
				'id' => array( 'type' => 'string' ),
				'action' => array( 'type' => 'string', 'enum' => array( 'checkin', 'checkout' ) ),
			),
			'required' => array( 'id', 'action' ),
		);
	}

	public static function rsvp_input() {
		return array(
			'type' => 'object',
			'properties' => array(
				'id' => array( 'type' => 'string' ),
				'status' => array( 'type' => array( 'integer', 'null' ), 'enum' => array( 0, 1, 2, null ) ),
			),
			'required' => array( 'id', 'status' ),
		);
	}

	public static function object_output() {
		return array( 'type' => 'object' );
	}

	public static function collection_output() {
		return array(
			'type' => 'object',
			'properties' => array(
				'items' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ),
				'pagination' => array( 'type' => 'object' ),
			),
		);
	}
}

<?php
/**
 * Plugin Name:       Conversal Admin
 * Plugin URI:        https://www.conversal.be/
 * Description:       Conversal-branded WordPress admin experience for Conversal clients.
 * Version:           3.0.4
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Author:            Conversal
 * Author URI:        https://www.conversal.be/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       conversal-admin
 * Domain Path:       /languages
 * Update URI:        https://packages.conversal.be/@conversal/conversal-admin
 *
 * @package Conversal\Admin
 */

defined( 'ABSPATH' ) || exit;

define( 'CONVERSAL_ADMIN_VERSION', '3.0.4' );
define( 'CONVERSAL_ADMIN_FILE', __FILE__ );
define( 'CONVERSAL_ADMIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CONVERSAL_ADMIN_URL', plugin_dir_url( __FILE__ ) );

if ( is_readable( CONVERSAL_ADMIN_DIR . 'vendor/autoload.php' ) ) {
	require_once CONVERSAL_ADMIN_DIR . 'vendor/autoload.php';
} else {
	// Fallback PSR-4 autoloader so the plugin also runs without `composer install`.
	spl_autoload_register(
		static function ( string $class_name ): void {
			$prefix = 'Conversal\\Admin\\';
			if ( 0 !== strpos( $class_name, $prefix ) ) {
				return;
			}
			$file = CONVERSAL_ADMIN_DIR . 'src/' . str_replace( '\\', '/', substr( $class_name, strlen( $prefix ) ) ) . '.php';
			if ( is_readable( $file ) ) {
				require_once $file;
			}
		}
	);
}

register_activation_hook( __FILE__, array( Conversal\Admin\Compat\LegacyBackend::class, 'on_activation' ) );
register_deactivation_hook( __FILE__, array( Conversal\Admin\Updater\CriticalUpdates::class, 'unschedule' ) );

add_action( 'plugins_loaded', array( Conversal\Admin\Plugin::class, 'boot' ) );

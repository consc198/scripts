<?php
/**
 * Conversal admin bar styling on the front end.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Frontend;

use Conversal\Admin\Assets;
use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Conversal admin bar styling on the front end.
 */
final class AdminBarStyle implements Service {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Enqueue the admin bar styles when the admin bar is visible.
	 */
	public function enqueue(): void {
		if ( ! is_admin_bar_showing() ) {
			return;
		}
		Assets::enqueue_style( 'conversal-admin-bar', 'admin-bar', array( 'admin-bar' ) );
	}
}

<?php
/**
 * Command palette (Cmd/Ctrl+K) in the front-end admin bar.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Frontend;

use Conversal\Admin\Contracts\Service;
use WP_Admin_Bar;

defined( 'ABSPATH' ) || exit;

/**
 * Command palette (Cmd/Ctrl+K) in the front-end admin bar.
 *
 * Core only loads the palette in wp-admin (wp_enqueue_command_palette_assets() on
 * admin_enqueue_scripts, and wp_admin_bar_command_palette_menu() bails outside is_admin()).
 */
final class CommandPalette implements Service {

	public const CAPABILITY = 'edit_posts';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_bar_menu', array( $this, 'add_trigger' ), 55 );
	}

	/**
	 * Whether the palette should be available on this front-end request.
	 */
	private function enabled(): bool {
		return ! is_admin()
			&& is_admin_bar_showing()
			&& current_user_can( self::CAPABILITY )
			&& function_exists( 'wp_enqueue_command_palette_assets' );
	}

	/**
	 * Load core's command palette assets on the front end.
	 */
	public function enqueue(): void {
		if ( $this->enabled() ) {
			wp_enqueue_command_palette_assets();
		}
	}

	/**
	 * Add the same trigger button core shows in wp-admin.
	 *
	 * @param WP_Admin_Bar $admin_bar Admin bar instance.
	 */
	public function add_trigger( WP_Admin_Bar $admin_bar ): void {
		if ( ! $this->enabled() || ! wp_script_is( 'wp-core-commands', 'enqueued' ) ) {
			return;
		}

		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		$is_apple   = (bool) preg_match( '/Macintosh|Mac OS X|Mac_PowerPC/i', $user_agent );

		$admin_bar->add_node(
			array(
				'id'    => 'command-palette',
				'title' => sprintf(
					'<span class="ab-icon" aria-hidden="true"></span><span class="ab-label"><kbd>%1$s</kbd><span class="screen-reader-text"> %2$s</span></span>',
					// Core strings, translated by WordPress itself.
					// phpcs:disable WordPress.WP.I18n.MissingArgDomain
					$is_apple ? esc_html_x( '⌘K', 'keyboard shortcut to open the command palette' ) : esc_html_x( 'Ctrl+K', 'keyboard shortcut to open the command palette' ),
					esc_html__( 'Open command palette' )
					// phpcs:enable WordPress.WP.I18n.MissingArgDomain
				),
				'href'  => '#',
				'meta'  => array(
					'class'   => 'hide-if-no-js',
					'onclick' => 'wp.data.dispatch( "core/commands" ).open(); return false;',
				),
			)
		);
	}
}

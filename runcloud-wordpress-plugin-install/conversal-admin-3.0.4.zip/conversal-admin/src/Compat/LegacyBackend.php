<?php
/**
 * Deactivate older Conversal backend plugins that conflict with this one.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Compat;

use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Deactivate older Conversal backend plugins that conflict with this one.
 */
final class LegacyBackend implements Service {

	private const NOTICE_TRANSIENT = 'conversal_admin_deactivated_legacy';

	/**
	 * Plugin basenames that conflict with this plugin.
	 */
	public const LEGACY_PLUGINS = array(
		'conversal-backend/conversal-backend.php',
		'conversal-backend-old/conversal-backend.php',
		'conversal-admin-styling/conversal-admin-styling.php',
		'conversal-backend-plugin-new/conversal-backend-plugin.php',
	);

	/**
	 * Legacy releases (2.5.9 – 2.6.0.4, "stable") ship conversal-backend.php, but
	 * GitHub archives unpack into versioned folders such as
	 * conversal-backend-2.6.0.2/ or conversal-backend-v2.6.0.4/.
	 */
	private const LEGACY_PATTERN = '#^conversal-backend[^/]*/conversal-backend\.php$#';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_init', array( self::class, 'deactivate_legacy' ) );
		add_action( 'admin_notices', array( $this, 'notice' ) );
	}

	/**
	 * Runs on activation of this plugin.
	 */
	public static function on_activation(): void {
		self::deactivate_legacy();
	}

	/**
	 * Deactivate any active legacy plugin and remember which ones for the notice.
	 */
	public static function deactivate_legacy(): void {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$active = array_values( array_filter( self::active_plugins(), array( self::class, 'is_legacy' ) ) );
		if ( ! $active ) {
			return;
		}

		deactivate_plugins( $active, true );
		set_transient( self::NOTICE_TRANSIENT, $active, MINUTE_IN_SECONDS * 10 );
	}

	/**
	 * Basenames of all active plugins, including network-activated ones.
	 *
	 * @return string[]
	 */
	private static function active_plugins(): array {
		$plugins = (array) get_option( 'active_plugins', array() );
		if ( is_multisite() ) {
			$plugins = array_merge( $plugins, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}
		return array_unique( array_filter( $plugins, 'is_string' ) );
	}

	/**
	 * Whether a plugin basename belongs to a legacy Conversal backend plugin.
	 *
	 * @param string $plugin Plugin basename.
	 */
	private static function is_legacy( string $plugin ): bool {
		return in_array( $plugin, self::LEGACY_PLUGINS, true )
			|| 1 === preg_match( self::LEGACY_PATTERN, $plugin );
	}

	/**
	 * Tell administrators which plugins were deactivated.
	 */
	public function notice(): void {
		$deactivated = get_transient( self::NOTICE_TRANSIENT );
		if ( ! $deactivated || ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		delete_transient( self::NOTICE_TRANSIENT );

		printf(
			'<div class="notice notice-info is-dismissible"><p>%1$s <code>%2$s</code></p></div>',
			esc_html__( 'Conversal Admin replaces the previous Conversal backend plugin. These plugins were deactivated:', 'conversal-admin' ),
			esc_html( implode( ', ', (array) $deactivated ) )
		);
	}
}

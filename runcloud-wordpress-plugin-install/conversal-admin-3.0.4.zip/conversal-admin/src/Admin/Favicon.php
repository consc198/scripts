<?php
/**
 * Conversal favicon in the admin and on the login screen.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Admin;

use Conversal\Admin\Assets;
use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Conversal favicon in the admin and on the login screen.
 */
final class Favicon implements Service {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_head', array( $this, 'render' ) );
		add_action( 'login_head', array( $this, 'render' ) );
	}

	/**
	 * Print the favicon link tag, unless the site has its own site icon.
	 */
	public function render(): void {
		if ( has_site_icon() ) {
			return;
		}
		printf( '<link rel="icon" type="image/svg+xml" href="%s" />' . "\n", esc_url( Assets::image_url( 'favicon.svg' ) ) );
	}
}

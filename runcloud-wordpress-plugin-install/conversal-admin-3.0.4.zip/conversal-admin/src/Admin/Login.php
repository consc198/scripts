<?php
/**
 * Branded login screen.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Admin;

use Conversal\Admin\Assets;
use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Branded login screen, in a light and a dark theme.
 */
final class Login implements Service {

	/**
	 * Local storage key for the visitor's theme choice. Keep in sync with assets/src/js/login.js.
	 */
	private const THEME_STORAGE_KEY = 'conversal-login-theme';

	/**
	 * Form actions in wp-login.php that get a heading in the card.
	 */
	private const FORM_ACTIONS = array( 'login_form', 'lostpassword_form', 'register_form', 'resetpass_form' );

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'login_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'login_head', array( $this, 'print_theme_script' ), 1 );
		add_action( 'login_header', array( $this, 'render_theme_toggle' ) );
		foreach ( self::FORM_ACTIONS as $action ) {
			add_action( $action, array( $this, 'render_heading' ), 1, 0 );
		}
		add_filter( 'login_headerurl', array( $this, 'header_url' ) );
		add_filter( 'login_headertext', array( $this, 'header_text' ) );
	}

	/**
	 * Enqueue login styles and the theme toggle.
	 */
	public function enqueue(): void {
		Assets::enqueue_style( 'conversal-admin-login', 'login' );
		Assets::enqueue_script( 'conversal-admin-login', 'login' );
	}

	/**
	 * Apply the stored theme choice before the first paint, so the page does not flash.
	 */
	public function print_theme_script(): void {
		wp_print_inline_script_tag(
			sprintf(
				'try{var t=localStorage.getItem(%s);if(t==="light"||t==="dark"){document.documentElement.setAttribute("data-cv-theme",t);}}catch(e){}',
				wp_json_encode( self::THEME_STORAGE_KEY )
			)
		);
	}

	/**
	 * Light/dark toggle, top right. Hidden without JavaScript and in the interim (re-auth) login.
	 */
	public function render_theme_toggle(): void {
		$label_dark  = __( 'Switch to dark mode', 'conversal-admin' );
		$label_light = __( 'Switch to light mode', 'conversal-admin' );

		printf(
			'<button type="button" class="cv-login-theme-toggle" data-label-dark="%1$s" data-label-light="%2$s" aria-label="%1$s" title="%1$s">%3$s%4$s</button>' . "\n",
			esc_attr( $label_dark ),
			esc_attr( $label_light ),
			'<svg class="cv-icon-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>',
			'<svg class="cv-icon-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>'
		);
	}

	/**
	 * Heading at the top of the card, and the notices moved in below it.
	 *
	 * The form actions fire after the fields, so CSS moves the heading to the top (order: -1).
	 * The inline script moves the notices (errors, messages) from above the card into it, right
	 * away while the page is parsed. Without JavaScript they stay above the card.
	 */
	public function render_heading(): void {
		$site_name = get_bloginfo( 'name', 'display' );
		$subtitle  = '';

		switch ( current_action() ) {
			case 'lostpassword_form':
				$title = __( 'Reset your password', 'conversal-admin' );
				break;
			case 'register_form':
				/* translators: %s: Site title. */
				$title = sprintf( __( 'Register for %s', 'conversal-admin' ), $site_name );
				break;
			case 'resetpass_form':
				$title = __( 'Set a new password', 'conversal-admin' );
				break;
			default:
				/* translators: %s: Site title. */
				$title    = sprintf( __( 'Log in to %s', 'conversal-admin' ), $site_name );
				$subtitle = __( 'The admin area of your website.', 'conversal-admin' );
		}

		echo '<div class="cv-login-heading">';
		echo '<h2 class="cv-login-title">' . esc_html( $title ) . '</h2>';
		if ( '' !== $subtitle ) {
			echo '<p class="cv-login-subtitle">' . esc_html( $subtitle ) . '</p>';
		}
		echo "</div>\n";

		wp_print_inline_script_tag(
			'(function(h){if(!h){return;}document.querySelectorAll("#login > .notice, #login > .message").forEach(function(n){h.after(n);h=n;});})(document.currentScript&&document.currentScript.previousElementSibling);'
		);
	}

	/**
	 * Logo links to the site's home page.
	 */
	public function header_url(): string {
		return home_url( '/' );
	}

	/**
	 * Logo text is the site name.
	 */
	public function header_text(): string {
		return get_bloginfo( 'name', 'display' );
	}
}

<?php
/**
 * Admin bar: replace the WordPress logo with the Conversal mark.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Admin;

use Conversal\Admin\Contracts\Service;
use WP_Admin_Bar;

defined( 'ABSPATH' ) || exit;

/**
 * Admin bar: replace the WordPress logo with the Conversal mark.
 */
final class AdminBar implements Service {

	public const NODE_ID = 'conversal-logo';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_bar_menu', array( $this, 'add_logo' ), 0 );
		add_action( 'admin_bar_menu', array( $this, 'remove_core_nodes' ), 999 );
	}

	/**
	 * Add the Conversal logo as the first node.
	 *
	 * @param WP_Admin_Bar $admin_bar Admin bar instance.
	 */
	public function add_logo( WP_Admin_Bar $admin_bar ): void {
		$admin_bar->add_node(
			array(
				'id'    => self::NODE_ID,
				'title' => '<span class="conversal-logo-mark" aria-hidden="true"></span><span class="screen-reader-text">' . esc_html__( 'Conversal', 'conversal-admin' ) . '</span>',
				'href'  => 'https://www.conversal.be',
				'meta'  => array(
					'class'  => 'conversal-dashboard-icon',
					'target' => '_blank',
					'rel'    => 'noopener',
				),
			)
		);
	}

	/**
	 * Remove the WordPress logo node.
	 *
	 * @param WP_Admin_Bar $admin_bar Admin bar instance.
	 */
	public function remove_core_nodes( WP_Admin_Bar $admin_bar ): void {
		$admin_bar->remove_node( 'wp-logo' );
	}
}

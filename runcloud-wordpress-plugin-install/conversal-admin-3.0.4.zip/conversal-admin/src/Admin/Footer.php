<?php
/**
 * Admin footer: Conversal support link.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Admin;

use Conversal\Admin\Assets;
use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Admin footer: Conversal support link.
 */
final class Footer implements Service {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_filter( 'admin_footer_text', array( $this, 'footer_text' ) );
	}

	/**
	 * Replace the "Thank you for creating with WordPress" text.
	 */
	public function footer_text(): string {
		return sprintf(
			'<span id="footer-thankyou"><a class="conversal-footer" href="%1$s" target="_blank" rel="noopener"><img src="%2$s" alt="" width="18" height="16" /><span>%3$s</span></a></span>',
			esc_url( 'https://support.conversal.be/' ),
			esc_url( Assets::image_url( 'icon-positive.svg' ) ),
			esc_html__( 'support.conversal.be', 'conversal-admin' )
		);
	}
}

<?php
/**
 * Top-level menu links to Conversal support, manuals and status pages.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Admin;

use Conversal\Admin\Assets;
use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Top-level menu links to Conversal support, manuals and status pages.
 */
final class Menu implements Service {

	public const CAPABILITY = 'publish_pages';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'admin_menu', array( $this, 'add_menu_items' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Menu items, keyed by slug.
	 *
	 * @return array<string, array{title: string, url: string, icon: string, position: int}>
	 */
	public static function items(): array {
		$items = array(
			'conversal-support'       => array(
				'title'    => __( 'Support', 'conversal-admin' ),
				'url'      => 'https://support.conversal.be/',
				'icon'     => 'dashicons-testimonial',
				'position' => 101,
			),
			'conversal-handleidingen' => array(
				'title'    => __( 'Manuals', 'conversal-admin' ),
				'url'      => 'https://handleidingen.conversal.be/',
				'icon'     => 'dashicons-book-alt',
				'position' => 102,
			),
			'conversal-status'        => array(
				'title'    => __( 'Status', 'conversal-admin' ),
				'url'      => 'https://status.conversal.be/',
				'icon'     => 'dashicons-clock',
				'position' => 103,
			),
		);

		/**
		 * Filters the Conversal admin menu links.
		 *
		 * @param array<string, array{title: string, url: string, icon: string, position: int}> $items Menu items keyed by slug.
		 */
		return (array) apply_filters( 'conversal_admin/menu_items', $items );
	}

	/**
	 * Add the external links as top-level menu items.
	 */
	public function add_menu_items(): void {
		global $menu;

		foreach ( self::items() as $item ) {
			add_menu_page( $item['title'], $item['title'], self::CAPABILITY, $item['url'], '', $item['icon'], $item['position'] );
		}

		// Give the external items a class so admin.js can open them in a new tab.
		$urls = wp_list_pluck( self::items(), 'url' );
		foreach ( (array) $menu as $index => $menu_item ) {
			if ( isset( $menu_item[2] ) && in_array( $menu_item[2], $urls, true ) ) {
				// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- adding a class to our own menu item.
				$menu[ $index ][4] = trim( ( $menu_item[4] ?? '' ) . ' conversal-external' );
			}
		}
	}

	/**
	 * Enqueue the admin script that opens external menu items in a new tab.
	 */
	public function enqueue(): void {
		if ( current_user_can( self::CAPABILITY ) ) {
			Assets::enqueue_script( 'conversal-admin', 'admin' );
		}
	}
}

<?php
/**
 * Yoast SEO tweaks.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Integrations;

use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Yoast SEO tweaks.
 */
final class Yoast implements Service {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_filter( 'wpseo_metabox_prio', array( $this, 'metabox_priority' ) );
	}

	/**
	 * Move the Yoast metabox below other metaboxes.
	 */
	public function metabox_priority(): string {
		return 'low';
	}
}

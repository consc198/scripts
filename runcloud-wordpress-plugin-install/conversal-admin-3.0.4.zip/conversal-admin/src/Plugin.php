<?php
/**
 * Plugin bootstrap.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin;

use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Plugin bootstrap.
 */
final class Plugin {

	/**
	 * Services registered on boot, in order.
	 *
	 * @var array<class-string<Service>>
	 */
	private const SERVICES = array(
		Compat\LegacyBackend::class,
		Admin\ColorScheme::class,
		Admin\AdminBar::class,
		Admin\Menu::class,
		Admin\Footer::class,
		Admin\Login::class,
		Admin\Favicon::class,
		Dashboard\CleanDashboard::class,
		Dashboard\Widgets::class,
		Frontend\AdminBarStyle::class,
		Frontend\CommandPalette::class,
		Integrations\Yoast::class,
		Updater\UpdateProvider::class,
		Updater\PackageDownloader::class,
		Updater\CriticalUpdates::class,
	);

	/**
	 * Whether boot() already ran.
	 *
	 * @var bool
	 */
	private static bool $booted = false;

	/**
	 * Register all services once.
	 */
	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		add_action( 'init', array( self::class, 'load_textdomain' ) );

		/**
		 * Filters the list of services the plugin registers.
		 *
		 * @param array<class-string<Service>> $services Service class names.
		 */
		$services = (array) apply_filters( 'conversal_admin/services', self::SERVICES );

		foreach ( $services as $service_class ) {
			$service = new $service_class();
			if ( $service instanceof Service ) {
				$service->register();
			}
		}
	}

	/**
	 * Load bundled translations from languages/.
	 */
	public static function load_textdomain(): void {
		load_plugin_textdomain( 'conversal-admin', false, dirname( plugin_basename( CONVERSAL_ADMIN_FILE ) ) . '/languages' );
	}
}

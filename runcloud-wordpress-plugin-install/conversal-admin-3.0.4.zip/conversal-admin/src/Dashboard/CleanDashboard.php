<?php
/**
 * Remove the core welcome panel and default dashboard widgets.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Dashboard;

use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Remove the core welcome panel and default dashboard widgets.
 */
final class CleanDashboard implements Service {

	/**
	 * Core dashboard widgets to remove, widget id => context.
	 */
	private const CORE_WIDGETS = array(
		'dashboard_quick_press'     => 'side',
		'dashboard_incoming_links'  => 'normal',
		'dashboard_activity'        => 'normal',
		'dashboard_right_now'       => 'normal',
		'dashboard_plugins'         => 'normal',
		'dashboard_recent_drafts'   => 'normal',
		'dashboard_recent_comments' => 'normal',
		'dashboard_primary'         => 'side',
		'dashboard_secondary'       => 'side',
	);

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		// The welcome_panel action is only added in wp-admin/includes/admin-filters.php, so remove it on admin_init.
		add_action( 'admin_init', array( $this, 'remove_welcome_panel' ) );
		add_action( 'wp_dashboard_setup', array( $this, 'remove_core_widgets' ), 11 );
	}

	/**
	 * Remove the core welcome panel.
	 */
	public function remove_welcome_panel(): void {
		remove_action( 'welcome_panel', 'wp_welcome_panel' );
	}

	/**
	 * Remove the default core dashboard widgets.
	 */
	public function remove_core_widgets(): void {
		foreach ( self::CORE_WIDGETS as $id => $context ) {
			remove_meta_box( $id, 'dashboard', $context );
		}
	}
}

<?php
/**
 * Conversal dashboard widgets. Their content is managed remotely on tools.conversal.be.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Dashboard;

use Conversal\Admin\Assets;
use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Conversal dashboard widgets. Their content is managed remotely on tools.conversal.be.
 */
final class Widgets implements Service {

	public const CAPABILITY = 'publish_pages';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_action( 'wp_dashboard_setup', array( $this, 'add_widgets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Remote URLs used by the widgets.
	 *
	 * @return array{welcome: string, spotlight: string, facebook_page: string, facebook_sdk: string}
	 */
	public static function urls(): array {
		$urls = array(
			'welcome'       => 'https://tools.conversal.be/widget/text',
			'spotlight'     => 'https://tools.conversal.be/widgets/conversal-image.png',
			'facebook_page' => 'https://www.facebook.com/conversal',
			'facebook_sdk'  => 'https://connect.facebook.net/nl_NL/sdk.js#xfbml=1&version=v3.2',
		);

		/**
		 * Filters the remote URLs used by the Conversal dashboard widgets.
		 *
		 * @param array{welcome: string, spotlight: string, facebook_page: string, facebook_sdk: string} $urls Widget URLs.
		 */
		return apply_filters( 'conversal_admin/widget_urls', $urls );
	}

	/**
	 * Register the widgets and move Welcome and Facebook to the top.
	 */
	public function add_widgets(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		wp_add_dashboard_widget( 'conversal_welkom_widget', __( 'Welcome!', 'conversal-admin' ), array( $this, 'render_welcome' ) );
		wp_add_dashboard_widget( 'conversal_in_de_kijker_widget', __( 'In the spotlight', 'conversal-admin' ), array( $this, 'render_spotlight' ) );
		wp_add_dashboard_widget( 'conversal_facebook_widget', __( 'Conversal Facebook', 'conversal-admin' ), array( $this, 'render_facebook' ) );

		global $wp_meta_boxes;
		$normal = $wp_meta_boxes['dashboard']['normal']['core'] ?? array();
		$top    = array();
		foreach ( array( 'conversal_welkom_widget', 'conversal_facebook_widget' ) as $id ) {
			if ( isset( $normal[ $id ] ) ) {
				$top[ $id ] = $normal[ $id ];
				unset( $normal[ $id ] );
			}
		}
		// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- reordering dashboard widgets.
		$wp_meta_boxes['dashboard']['normal']['core'] = array_merge( $top, $normal );
	}

	/**
	 * Enqueue widget styles on the dashboard only.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public function enqueue( string $hook_suffix ): void {
		if ( 'index.php' === $hook_suffix ) {
			Assets::enqueue_style( 'conversal-admin-dashboard', 'dashboard' );
		}
	}

	/**
	 * Welcome widget: remote text page in an iframe.
	 */
	public function render_welcome(): void {
		printf(
			'<div class="conversal-widget" id="conversal-widget-support"><iframe src="%1$s" title="%2$s" loading="lazy"></iframe></div>',
			esc_url( self::urls()['welcome'] ),
			esc_attr__( 'Welcome message from Conversal', 'conversal-admin' )
		);
	}

	/**
	 * Spotlight widget: remote image, cache-busted on every load.
	 */
	public function render_spotlight(): void {
		printf(
			'<div class="conversal-widget" id="conversal-widget-in-de-kijker"><img src="%1$s" alt="%2$s" /></div>',
			esc_url( add_query_arg( 't', time(), self::urls()['spotlight'] ) ),
			esc_attr__( 'In the spotlight at Conversal', 'conversal-admin' )
		);
	}

	/**
	 * Facebook widget: page timeline via the Facebook SDK.
	 */
	public function render_facebook(): void {
		$urls = self::urls();
		?>
		<div class="conversal-widget" id="conversal-widget-facebook">
			<div id="fb-root"></div>
			<?php // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- Facebook SDK must load inside the widget. ?>
			<script async defer crossorigin="anonymous" src="<?php echo esc_url( $urls['facebook_sdk'] ); ?>"></script>
			<div class="fb-page" data-href="<?php echo esc_url( $urls['facebook_page'] ); ?>" data-tabs="timeline" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-width="500" data-height="600">
				<blockquote cite="<?php echo esc_url( $urls['facebook_page'] ); ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo esc_url( $urls['facebook_page'] ); ?>">Conversal</a></blockquote>
			</div>
		</div>
		<?php
	}
}

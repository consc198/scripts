<?php
/**
 * Contract for every hookable plugin service.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * Contract for every hookable plugin service.
 */
interface Service {

	/**
	 * Register the service's WordPress hooks.
	 */
	public function register(): void;
}

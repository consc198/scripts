<?php
/**
 * Download npm tarballs from the registry and hand WordPress a ZIP.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Updater;

use Conversal\Admin\Contracts\Service;
use PharData;
use Throwable;
use WP_Error;
use ZipArchive;

defined( 'ABSPATH' ) || exit;

/**
 * Download npm tarballs from the registry and hand WordPress a ZIP.
 *
 * The WordPress upgrader only unpacks ZIP files and cannot send an auth header, so the
 * tarball is downloaded here with the registry token, verified against its sha512
 * integrity hash and repacked as conversal-admin/... in a ZIP.
 */
final class PackageDownloader implements Service {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_filter( 'upgrader_pre_download', array( $this, 'download' ), 10, 2 );
	}

	/**
	 * Short-circuit the download for our registry tarballs.
	 *
	 * @param false|string|WP_Error $reply   Short-circuit value.
	 * @param string                $package Package URL.
	 * @return false|string|WP_Error
	 */
	public function download( $reply, $package ) {
		if ( false !== $reply || ! is_string( $package ) || 0 !== strpos( $package, Config::registry() . '/' ) ) {
			return $reply;
		}

		$release = Registry::find_by_tarball( $package );
		if ( null === $release ) {
			Registry::flush();
			$release = Registry::find_by_tarball( $package );
		}
		if ( null === $release || empty( $release['dist']['integrity'] ) ) {
			return new WP_Error( 'conversal_admin_unknown_package', __( 'The update package is not listed in the Conversal registry.', 'conversal-admin' ) );
		}

		$tarball  = wp_tempnam( 'conversal-admin.tgz' );
		$response = wp_remote_get(
			$package,
			array(
				'timeout'  => 300,
				'stream'   => true,
				'filename' => $tarball,
				'headers'  => Registry::headers(),
			)
		);
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			wp_delete_file( $tarball );
			return new WP_Error( 'conversal_admin_download_failed', __( 'Downloading the update from the Conversal registry failed.', 'conversal-admin' ) );
		}

		$verified = self::verify_integrity( $tarball, (string) $release['dist']['integrity'] );
		if ( is_wp_error( $verified ) ) {
			wp_delete_file( $tarball );
			return $verified;
		}

		$zip = self::repack( $tarball );
		wp_delete_file( $tarball );
		return $zip;
	}

	/**
	 * Check a file against an npm Subresource Integrity string ("sha512-<base64>").
	 *
	 * @param string $file      File path.
	 * @param string $integrity Integrity string.
	 * @return true|WP_Error
	 */
	private static function verify_integrity( string $file, string $integrity ) {
		if ( ! preg_match( '/^sha512-(.+)$/', $integrity, $m ) ) {
			return new WP_Error( 'conversal_admin_integrity', __( 'The update package has no sha512 checksum.', 'conversal-admin' ) );
		}
		$actual = base64_encode( (string) hash_file( 'sha512', $file, true ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- SRI hashes are base64.
		if ( ! hash_equals( $m[1], $actual ) ) {
			return new WP_Error( 'conversal_admin_integrity', __( 'The update package failed its checksum verification.', 'conversal-admin' ) );
		}
		return true;
	}

	/**
	 * Repack an npm tarball (package/...) as a plugin ZIP (conversal-admin/...).
	 *
	 * @param string $tarball Path to the .tgz file.
	 * @return string|WP_Error Path to the ZIP.
	 */
	private static function repack( string $tarball ) {
		if ( ! class_exists( PharData::class ) || ! class_exists( ZipArchive::class ) ) {
			return new WP_Error( 'conversal_admin_repack', __( 'The PHP Phar and Zip extensions are required to install Conversal updates.', 'conversal-admin' ) );
		}

		$work = trailingslashit( get_temp_dir() ) . 'conversal-admin-' . wp_generate_password( 12, false );
		$zip  = $work . '.zip';
		$tgz  = $work . '.tgz'; // PharData needs a recognizable extension.

		wp_mkdir_p( $work );
		copy( $tarball, $tgz );

		try {
			( new PharData( $tgz ) )->extractTo( $work, null, true );
		} catch ( Throwable $e ) {
			wp_delete_file( $tgz );
			self::remove_dir( $work );
			return new WP_Error( 'conversal_admin_repack', $e->getMessage() );
		}
		wp_delete_file( $tgz );

		$source  = $work . '/package';
		$archive = new ZipArchive();
		if ( ! is_dir( $source ) || true !== $archive->open( $zip, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			self::remove_dir( $work );
			return new WP_Error( 'conversal_admin_repack', __( 'The update package could not be converted to a ZIP file.', 'conversal-admin' ) );
		}

		$files = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $source, \FilesystemIterator::SKIP_DOTS ) );
		foreach ( $files as $file ) {
			$relative = substr( $file->getPathname(), strlen( $source ) + 1 );
			$archive->addFile( $file->getPathname(), Config::slug() . '/' . str_replace( '\\', '/', $relative ) );
		}
		$archive->close();

		self::remove_dir( $work );
		return $zip;
	}

	/**
	 * Delete a temporary directory.
	 *
	 * @param string $dir Directory path.
	 */
	private static function remove_dir( string $dir ): void {
		global $wp_filesystem;
		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		if ( $wp_filesystem ) {
			$wp_filesystem->delete( $dir, true );
		}
	}
}

<?php
/**
 * Read package metadata from the Verdaccio (npm) registry.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Updater;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Read package metadata from the Verdaccio (npm) registry.
 */
final class Registry {

	private const CACHE_KEY = 'conversal_admin_registry';

	private const STATUS_OPTION = 'conversal_admin_update_status';

	/**
	 * Cache lifetime; matches the critical update check interval.
	 */
	public const CACHE_TTL = 15 * MINUTE_IN_SECONDS;

	/**
	 * Package document (packument), cached.
	 *
	 * @param bool $fresh Bypass the cache.
	 * @return array<string, mixed>|WP_Error
	 */
	public static function packument( bool $fresh = false ) {
		if ( ! $fresh ) {
			$cached = get_site_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$response = wp_remote_get(
			Config::registry() . '/' . str_replace( '/', '%2f', Config::PACKAGE ),
			array(
				'timeout' => 10,
				'headers' => self::headers( array( 'Accept' => 'application/json' ) ),
			)
		);

		$error = null;
		if ( is_wp_error( $response ) ) {
			$error = $response;
		} elseif ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			$error = new WP_Error(
				'conversal_admin_registry_http',
				sprintf( 'Registry responded with HTTP %d.', wp_remote_retrieve_response_code( $response ) )
			);
		}

		$data = $error ? null : json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! $error && ( ! is_array( $data ) || empty( $data['versions'] ) || ! is_array( $data['versions'] ) ) ) {
			$error = new WP_Error( 'conversal_admin_registry_body', 'Registry returned no package versions.' );
		}

		if ( $error ) {
			self::record_status( $error->get_error_message() );
			return $error;
		}

		// Keep only what we use, the full readme can be large.
		$slim = array(
			'dist-tags' => (array) ( $data['dist-tags'] ?? array() ),
			'versions'  => array(),
			'time'      => (array) ( $data['time'] ?? array() ),
			'readme'    => (string) ( $data['readme'] ?? '' ),
		);
		foreach ( $data['versions'] as $version => $manifest ) {
			$slim['versions'][ $version ] = array(
				'dist'      => (array) ( $manifest['dist'] ?? array() ),
				'wordpress' => (array) ( $manifest['wordpress'] ?? array() ),
				'changelog' => (string) ( $manifest['changelog'] ?? '' ),
			);
		}

		set_site_transient( self::CACHE_KEY, $slim, self::CACHE_TTL );
		self::record_status( '' );
		return $slim;
	}

	/**
	 * Version for a dist-tag, or null.
	 *
	 * @param string $tag Dist-tag.
	 * @param bool   $fresh Bypass the cache.
	 */
	public static function version_for_tag( string $tag, bool $fresh = false ): ?string {
		$doc = self::packument( $fresh );
		if ( is_wp_error( $doc ) ) {
			return null;
		}
		$version = $doc['dist-tags'][ $tag ] ?? null;
		return is_string( $version ) && isset( $doc['versions'][ $version ] ) ? $version : null;
	}

	/**
	 * Find the version manifest whose tarball URL matches.
	 *
	 * @param string $tarball Tarball URL.
	 * @return array{version: string, dist: array<string, mixed>}|null
	 */
	public static function find_by_tarball( string $tarball ): ?array {
		$doc = self::packument();
		if ( is_wp_error( $doc ) ) {
			return null;
		}
		foreach ( $doc['versions'] as $version => $manifest ) {
			if ( ( $manifest['dist']['tarball'] ?? '' ) === $tarball ) {
				return array(
					'version' => (string) $version,
					'dist'    => $manifest['dist'],
				);
			}
		}
		return null;
	}

	/**
	 * HTTP headers including the registry token.
	 *
	 * @param array<string, string> $headers Extra headers.
	 * @return array<string, string>
	 */
	public static function headers( array $headers = array() ): array {
		$token = Config::token();
		if ( '' !== $token ) {
			$headers['Authorization'] = 'Bearer ' . $token;
		}
		return $headers;
	}

	/**
	 * Drop the cached package document.
	 */
	public static function flush(): void {
		delete_site_transient( self::CACHE_KEY );
	}

	/**
	 * Remember the last check result for the plugins screen.
	 *
	 * @param string $error Error message, empty on success.
	 */
	private static function record_status( string $error ): void {
		update_site_option(
			self::STATUS_OPTION,
			array(
				'checked' => time(),
				'error'   => $error,
			)
		);
	}

	/**
	 * Last check result.
	 *
	 * @return array{checked: int, error: string}
	 */
	public static function status(): array {
		$status = get_site_option( self::STATUS_OPTION, array() );
		return array(
			'checked' => (int) ( $status['checked'] ?? 0 ),
			'error'   => (string) ( $status['error'] ?? '' ),
		);
	}
}

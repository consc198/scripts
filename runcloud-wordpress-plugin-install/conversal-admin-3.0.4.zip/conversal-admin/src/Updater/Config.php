<?php
/**
 * Update channel configuration.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Updater;

defined( 'ABSPATH' ) || exit;

/**
 * Update channel configuration.
 *
 * Every value can be overridden per site with a constant in wp-config.php:
 * - CONVERSAL_ADMIN_REGISTRY       Registry base URL (default: set at build time)
 * - CONVERSAL_ADMIN_REGISTRY_TOKEN Read-only registry token
 * - CONVERSAL_ADMIN_CHANNEL        dist-tag to follow for regular updates (default "latest")
 * - CONVERSAL_ADMIN_AUTO_UPDATE    false to only show updates instead of installing them
 */
final class Config {

	public const PACKAGE = '@conversal/conversal-admin';

	/**
	 * Fallback when the build did not set a registry (development). Keep in sync with package.json config.registry.
	 */
	public const DEFAULT_REGISTRY = 'http://188.245.42.126:4873';

	public const CRITICAL_TAG = 'critical';

	/**
	 * Registry base URL without trailing slash: wp-config.php, then build-time value, then default.
	 */
	public static function registry(): string {
		if ( defined( 'CONVERSAL_ADMIN_REGISTRY' ) ) {
			$url = (string) CONVERSAL_ADMIN_REGISTRY;
		} else {
			$url = self::build_value( 'registry' );
			$url = '' !== $url ? $url : self::DEFAULT_REGISTRY;
		}
		return untrailingslashit( $url );
	}

	/**
	 * Read-only registry token: wp-config.php, then build-time value.
	 */
	public static function token(): string {
		return defined( 'CONVERSAL_ADMIN_REGISTRY_TOKEN' ) ? (string) CONVERSAL_ADMIN_REGISTRY_TOKEN : self::build_value( 'token' );
	}

	/**
	 * Value from src/Updater/credentials.php, written by bin/write-credentials.sh at build time.
	 *
	 * @param string $key Key.
	 */
	private static function build_value( string $key ): string {
		static $credentials = null;
		if ( null === $credentials ) {
			$file        = __DIR__ . '/credentials.php';
			$credentials = is_readable( $file ) ? require $file : array();
			$credentials = is_array( $credentials ) ? $credentials : array();
		}
		return isset( $credentials[ $key ] ) ? (string) $credentials[ $key ] : '';
	}

	/**
	 * Dist-tag followed for regular updates.
	 */
	public static function channel(): string {
		return defined( 'CONVERSAL_ADMIN_CHANNEL' ) ? (string) CONVERSAL_ADMIN_CHANNEL : 'latest';
	}

	/**
	 * Whether regular updates are installed automatically.
	 */
	public static function auto_update(): bool {
		return defined( 'CONVERSAL_ADMIN_AUTO_UPDATE' ) ? (bool) CONVERSAL_ADMIN_AUTO_UPDATE : true;
	}

	/**
	 * Whether this copy is a development checkout. Updates would replace the folder, .git included.
	 */
	public static function is_dev_checkout(): bool {
		return file_exists( CONVERSAL_ADMIN_DIR . '.git' );
	}

	/**
	 * Plugin basename, e.g. conversal-admin/conversal-admin.php.
	 */
	public static function basename(): string {
		return plugin_basename( CONVERSAL_ADMIN_FILE );
	}

	/**
	 * Plugin directory name, e.g. conversal-admin.
	 */
	public static function slug(): string {
		return dirname( self::basename() );
	}

	/**
	 * Host name from the plugin's Update URI header, used for the update_plugins_{$hostname} filter.
	 *
	 * It is only an identifier for this plugin's update source; it does not have to resolve.
	 */
	public static function update_uri_host(): string {
		$data = get_file_data( CONVERSAL_ADMIN_FILE, array( 'UpdateURI' => 'Update URI' ) );
		return (string) wp_parse_url( $data['UpdateURI'], PHP_URL_HOST );
	}
}

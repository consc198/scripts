<?php
/**
 * Feed registry versions into the WordPress plugin update system.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Updater;

use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Feed registry versions into the WordPress plugin update system.
 *
 * Uses the update_plugins_{$hostname} filter (WP 5.8+) tied to the plugin's Update URI header,
 * so the update shows up on the Plugins screen and is installed by core's auto-updater.
 */
final class UpdateProvider implements Service {

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		$host = Config::update_uri_host();
		if ( '' !== $host ) {
			add_filter( 'update_plugins_' . $host, array( $this, 'check' ), 10, 3 );
		}
		add_filter( 'plugins_api', array( $this, 'details' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( $this, 'auto_update' ), 10, 2 );
		add_filter( 'plugin_row_meta', array( $this, 'row_meta' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( Registry::class, 'flush' ) );
		add_action( 'load-update-core.php', array( $this, 'flush_on_force_check' ) );
	}

	/**
	 * Report the latest version of the followed channel.
	 *
	 * @param array<string, mixed>|false $update      Update data, false if none yet.
	 * @param array<string, string>      $plugin_data Plugin headers.
	 * @param string                     $plugin_file Plugin basename.
	 * @return array<string, mixed>|false
	 */
	public function check( $update, array $plugin_data, string $plugin_file ) {
		if ( Config::basename() !== $plugin_file ) {
			return $update;
		}

		$version = Registry::version_for_tag( Config::channel() );
		$doc     = Registry::packument();
		if ( null === $version || is_wp_error( $doc ) || Config::is_dev_checkout() ) {
			return $update;
		}

		$manifest = $doc['versions'][ $version ];

		// WordPress compares versions itself and only shows an update when this one is newer.
		return array(
			'id'           => Config::registry() . '/' . Config::PACKAGE,
			'slug'         => Config::slug(),
			'version'      => $version,
			'url'          => 'https://www.conversal.be/',
			'package'      => (string) ( $manifest['dist']['tarball'] ?? '' ),
			'tested'       => self::tested_up_to( $manifest ),
			'requires'     => (string) ( $manifest['wordpress']['requires'] ?? '' ),
			'requires_php' => (string) ( $manifest['wordpress']['requires_php'] ?? '' ),
			'autoupdate'   => Config::auto_update(),
			'icons'        => array( 'svg' => CONVERSAL_ADMIN_URL . 'assets/images/favicon.svg' ),
		);
	}

	/**
	 * Data for the "View details" modal.
	 *
	 * @param false|object|array<string, mixed> $result Default result.
	 * @param string                            $action API action.
	 * @param object                            $args   Request arguments.
	 * @return false|object|array<string, mixed>
	 */
	public function details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! isset( $args->slug ) || Config::slug() !== $args->slug ) {
			return $result;
		}

		$doc     = Registry::packument();
		$version = Registry::version_for_tag( Config::channel() );
		if ( is_wp_error( $doc ) || null === $version ) {
			return $result;
		}
		$manifest = $doc['versions'][ $version ];

		return (object) array(
			'name'          => 'Conversal Admin',
			'slug'          => Config::slug(),
			'version'       => $version,
			'author'        => '<a href="https://www.conversal.be/">Conversal</a>',
			'homepage'      => 'https://www.conversal.be/',
			'requires'      => (string) ( $manifest['wordpress']['requires'] ?? '' ),
			'tested'        => self::tested_up_to( $manifest ),
			'requires_php'  => (string) ( $manifest['wordpress']['requires_php'] ?? '' ),
			'last_updated'  => (string) ( $doc['time'][ $version ] ?? '' ),
			'download_link' => (string) ( $manifest['dist']['tarball'] ?? '' ),
			'sections'      => array(
				// Releases before 3.0.1 only carried the changelog as their readme.
				'changelog' => wp_kses_post( self::markdown_to_html( '' !== ( $manifest['changelog'] ?? '' ) ? $manifest['changelog'] : $doc['readme'] ) ),
			),
		);
	}

	/**
	 * Install regular updates automatically unless disabled per site.
	 *
	 * @param bool|null $update Whether to update.
	 * @param object    $item   Update offer.
	 * @return bool|null
	 */
	public function auto_update( $update, $item ) {
		if ( isset( $item->plugin ) && Config::basename() === $item->plugin ) {
			return Config::auto_update() && ! Config::is_dev_checkout();
		}
		return $update;
	}

	/**
	 * Show the update channel status on the Plugins screen.
	 *
	 * @param string[] $meta        Row meta links.
	 * @param string   $plugin_file Plugin basename.
	 * @return string[]
	 */
	public function row_meta( array $meta, string $plugin_file ): array {
		if ( Config::basename() !== $plugin_file || ! current_user_can( 'update_plugins' ) ) {
			return $meta;
		}

		if ( Config::is_dev_checkout() ) {
			$meta[] = esc_html__( 'Development checkout (.git): updates are not installed', 'conversal-admin' );
		}

		$status = Registry::status();
		if ( '' !== $status['error'] ) {
			$meta[] = '<span style="color:#cc2900">' . esc_html(
				/* translators: %s: error message. */
				sprintf( __( 'Update check failed: %s', 'conversal-admin' ), $status['error'] )
			) . '</span>';
		} elseif ( $status['checked'] ) {
			$meta[] = esc_html(
				sprintf(
					/* translators: %s: time since the last check, e.g. "5 minutes". */
					__( 'Updates via Conversal, last checked %s ago', 'conversal-admin' ),
					human_time_diff( $status['checked'] )
				)
			);
		}
		return $meta;
	}

	/**
	 * "Check again" on Dashboard > Updates also refreshes the registry cache.
	 */
	public function flush_on_force_check(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag, core verifies the action.
		if ( isset( $_GET['force-check'] ) ) {
			Registry::flush();
		}
	}

	/**
	 * "Tested up to" as major.minor covers every patch release of that branch, like on WordPress.org.
	 *
	 * @param array<string, mixed> $manifest Version manifest.
	 */
	private static function tested_up_to( array $manifest ): string {
		$tested     = (string) ( $manifest['wordpress']['tested'] ?? '' );
		$wp_version = (string) get_bloginfo( 'version' );
		if ( preg_match( '/^\d+\.\d+$/', $tested ) && 0 === strpos( $wp_version, $tested . '.' ) ) {
			return $wp_version;
		}
		return $tested;
	}

	/**
	 * Minimal Markdown (headings, lists, paragraphs) for the changelog section.
	 *
	 * @param string $markdown Markdown text.
	 */
	private static function markdown_to_html( string $markdown ): string {
		$html  = '';
		$list  = false;
		$lines = preg_split( '/\R/', $markdown );
		foreach ( false === $lines ? array() : $lines as $line ) {
			$line = rtrim( $line );
			if ( preg_match( '/^(#{1,4})\s+(.*)$/', $line, $m ) ) {
				$html .= $list ? '</ul>' : '';
				$list  = false;
				$level = min( 4, strlen( $m[1] ) + 1 );
				$html .= sprintf( '<h%1$d>%2$s</h%1$d>', $level, esc_html( $m[2] ) );
			} elseif ( preg_match( '/^\s*[-*]\s+(.*)$/', $line, $m ) ) {
				$html .= $list ? '' : '<ul>';
				$list  = true;
				$html .= '<li>' . esc_html( $m[1] ) . '</li>';
			} elseif ( '' !== $line ) {
				$html .= $list ? '</ul>' : '';
				$list  = false;
				$html .= '<p>' . esc_html( $line ) . '</p>';
			}
		}
		return $html . ( $list ? '</ul>' : '' );
	}
}

<?php
/**
 * Install releases tagged "critical" in the registry within minutes.
 *
 * @package Conversal\Admin
 */

namespace Conversal\Admin\Updater;

use Conversal\Admin\Contracts\Service;

defined( 'ABSPATH' ) || exit;

/**
 * Install releases tagged "critical" in the registry within minutes.
 *
 * Every 15 minutes each site checks the "critical" dist-tag. When it points to a newer
 * version than the installed one, the site refreshes its update data and runs core's
 * background updater right away (maintenance mode, locking and rollback included).
 *
 * Push a critical update: npm dist-tag add @conversal/conversal-admin@x.y.z critical
 */
final class CriticalUpdates implements Service {

	public const HOOK = 'conversal_admin_critical_check';

	private const SCHEDULE = 'conversal_admin_15min';

	/**
	 * {@inheritDoc}
	 */
	public function register(): void {
		add_filter( 'cron_schedules', array( self::class, 'add_schedule' ) );
		add_action( self::HOOK, array( $this, 'run' ) );
		add_action( 'init', array( self::class, 'schedule' ) );
	}

	/**
	 * Add a 15 minute cron schedule.
	 *
	 * @param array<string, array{interval: int, display: string}> $schedules Schedules.
	 * @return array<string, array{interval: int, display: string}>
	 */
	public static function add_schedule( array $schedules ): array {
		$schedules[ self::SCHEDULE ] = array(
			'interval' => 900,
			'display'  => 'Every 15 minutes (Conversal Admin)',
		);
		return $schedules;
	}

	/**
	 * Make sure the check is scheduled.
	 */
	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::SCHEDULE, self::HOOK );
		}
	}

	/**
	 * Remove the scheduled check (plugin deactivation).
	 */
	public static function unschedule(): void {
		wp_clear_scheduled_hook( self::HOOK );
	}

	/**
	 * Install a critical release when one is waiting.
	 */
	public function run(): void {
		if ( Config::is_dev_checkout() ) {
			return;
		}

		$critical = Registry::version_for_tag( Config::CRITICAL_TAG, true );
		if ( null === $critical || ! version_compare( $critical, CONVERSAL_ADMIN_VERSION, '>' ) ) {
			return;
		}

		// Refresh core's update data so it offers the newest version of the channel.
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();

		// Critical releases are always installed, even when regular auto-updates are off.
		add_filter( 'auto_update_plugin', array( $this, 'force' ), 20, 2 );
		wp_maybe_auto_update();
		remove_filter( 'auto_update_plugin', array( $this, 'force' ), 20 );
	}

	/**
	 * Force the auto-update for this plugin.
	 *
	 * @param bool|null $update Whether to update.
	 * @param object    $item   Update offer.
	 * @return bool|null
	 */
	public function force( $update, $item ) {
		return isset( $item->plugin ) && Config::basename() === $item->plugin ? true : $update;
	}
}

<?php
// Generated at build time. Do not commit.
defined( 'ABSPATH' ) || exit;
return array (
  'registry' => 'http://188.245.42.126:4873',
  'token' => 'MWQ1OThlYzU2YWI3YWNmNWNhYzU0YTdlMDRlOWU5YWM6NjhmY2EyNzk1OGMwMjlmNWZiYjBlMjMwNmFjNWVkOThlNTMxZjRhNjU1NDY2YzgzYTQ5Y2NiODg0ODgzZjcwMDQyOGVlODBhYmI4ZThkYjJiZjE2NGY1ZjM4ODg0NmEzNjlkODNhMmZmMzFiZjFhOGRmNmYxYTE2',
);

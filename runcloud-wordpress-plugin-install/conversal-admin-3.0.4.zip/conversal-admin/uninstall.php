<?php
/**
 * Uninstall cleanup.
 *
 * @package Conversal\Admin
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_transient( 'conversal_admin_deactivated_legacy' );
delete_site_transient( 'conversal_admin_registry' );
delete_site_option( 'conversal_admin_update_status' );
wp_clear_scheduled_hook( 'conversal_admin_critical_check' );

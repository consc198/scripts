# Conversal Admin

WordPress-plugin die de beheeromgeving van Conversal-klanten in de Conversal-huisstijl zet. De plugin bevat ook de Conversal-dashboardwidgets en een eigen updatekanaal via de private Verdaccio-registry.

Opvolger van **Conversal Backend 2.x** (`conversal-backend`). De oude plugin wordt bij activatie automatisch gedeactiveerd.

| | |
|---|---|
| Pakket | `@conversal/conversal-admin` op Verdaccio |
| Pluginmap | `wp-content/plugins/conversal-admin/` |
| Vereisten | WordPress 6.6+ (getest t/m 7.1), PHP 7.4+ met de extensies Phar en Zip |
| Talen | Engels (bron), Nederlands (nl_BE, nl_NL) |
| Licentie | GPL-2.0-or-later |

Wil je meewerken of een release maken? Lees dan [CONTRIBUTING.md](CONTRIBUTING.md).

---

## Functionaliteiten

### Huisstijl

Gebaseerd op de kleuren en logo's uit het Conversal-brandbook. De admin laadt geen webfonts en gebruikt het systeemfont van WordPress. Alleen de loginpagina gebruikt Plus Jakarta Sans, meegeleverd in de plugin (SIL OFL 1.1). Alle kleurcombinaties halen **WCAG 2.1 AA**: tekst minstens 4,5:1, iconen en UI-componenten minstens 3:1.

| Onderdeel | Wat |
|---|---|
| Kleurenschema | Schema `conversal`, gebouwd op de core-SCSS van WordPress en voor elke gebruiker geforceerd. De schemakiezer in het profiel is verborgen. |
| WordPress 6.x | WordPress 6.x zet zijn blauw als vaste kleur in de core-CSS (vanaf 7.0 via de themakleur). Op 6.x laden daarom de bestanden in `assets/wp6-compat/`, één per core-stylesheet en in dezelfde volgorde als core, met de themakleur voor elke blauwe regel in de admin, de mediabibliotheek en de Customizer. Ze zijn gegenereerd: `npm run wp6-compat -- <pad naar WordPress 6.x> <pad naar WordPress 7.x>`. |
| Admin bar | Conversal-icoon in plaats van het WordPress-logo, in wp-admin en op de frontend. Op de frontend zonder de blauwe hover- en focuskleuren van core. |
| Block editor | Knoppen, links, toggles en focusranden in teal, ook in de canvas-iframe en via de design-system-tokens (WPDS) van WordPress 7.1. |
| Loginpagina | Volledig in de Conversal-stijl: woordmerk, kaart met titel ("Aanmelden bij …"), foutmeldingen in de kaart, links en taalkeuze eronder, in het font Plus Jakarta Sans (meegeleverd, geen Google Fonts). Een **lichte en donkere modus** volgt standaard de systeeminstelling; de knop rechtsboven wisselt, en die keuze onthoudt de browser. Het logo linkt naar de site zelf. |
| Dashboard | Kaartstijl voor alle widgets: rand, schaduw en lichte header. |
| Footer & favicon | Link naar support.conversal.be met het Conversal-icoon, en de Conversal-favicon in de admin en op de login (tenzij de site een eigen site-icoon heeft). |

Kleurtokens (`assets/src/scss/_tokens.scss`):

| Token | Hex | Gebruik |
|---|---|---|
| `$cv-ink` | `#002023` | Menu, admin bar, login-achtergrond |
| `$cv-forest` | `#00483F` | Submenu, hover op donker |
| `$cv-teal` | `#00685A` | Primaire actiekleur: knoppen, links, focus |
| `$cv-mint` | `#00FFA4` | Accent, **alleen** op donkere vlakken |
| `$cv-green` | `#00D27D` | Accent, altijd met donkere tekst |
| `$cv-mist` | `#E2EEF0` | Lichte vlakken, widgetheaders |
| `$cv-orange` / `$cv-orange-text` | `#FF3300` / `#CC2900` | Destructieve acties: randen en iconen / tekst |
| `$cv-login-light` / `$cv-login-dark` | | Kleuren van de loginpagina per modus (kaart, velden, knoppen, meldingen) |

### Dashboard en menu

- **Opgeruimd dashboard:** het welkomstpaneel en de standaardwidgets van WordPress zijn weg (Snel concept, Activiteit, In één oogopslag, WordPress-nieuws, …).
- **Conversal-widgets**, zichtbaar voor gebruikers met `publish_pages`:
  - **Welkom!**: tekst van `tools.conversal.be/widget/text`, in een iframe.
  - **In de kijker**: afbeelding van `tools.conversal.be/widgets/conversal-image.png`, bij elke paginalading vers opgehaald.
  - **Conversal Facebook**: de tijdlijn van facebook.com/conversal.

  De inhoud wordt centraal beheerd op tools.conversal.be. Een plugin-update is daarvoor niet nodig.
- **Menu-items** Support, Handleidingen en Status (`publish_pages`): ze openen support.conversal.be, handleidingen.conversal.be en status.conversal.be in een nieuw tabblad.
- **Opdrachtpaneel (⌘K / Ctrl+K)** ook op de frontend, voor gebruikers met `edit_posts`.
- **Yoast SEO:** de metabox staat onderaan in de editor.

### Updates

De plugin werkt zichzelf bij vanuit Verdaccio, zonder ManageWP of een andere externe tool.

1. Elke site vraagt de registry naar de nieuwste versie: via de standaard updatecheck van WordPress (twee keer per dag, en elk uur bij een bezoek aan de admin), en elke 15 minuten voor kritieke updates.
2. Een nieuwe versie verschijnt in **Plugins** als gewone update, met changelog onder "Details bekijken".
3. De auto-updater van WordPress installeert de update, met onderhoudsmodus en rollback bij een fatale fout.
4. Een versie met de npm-tag `critical` wordt binnen ongeveer 15 minuten op alle sites geïnstalleerd, ook waar auto-updates uit staan.
   Zet die tag na de release met de workflow **Mark critical** (Actions → Mark critical → Run workflow, met het versienummer).

Veiligheid:

- Elk pakket wordt gecontroleerd tegen de sha512-checksum uit de registry. Een afwijkend pakket wordt geweigerd.
- Sites lezen met een read-only account (`conversal-wordpress`). Dat token kan niet publiceren.
- Een pluginmap met `.git` (een ontwikkelmap) krijgt nooit updates, zodat je werk niet overschreven wordt.

Onder de plugin in **Plugins** zie je de status, bijvoorbeeld "Updates via Conversal, 5 minuten geleden gecontroleerd", of een foutmelding als de registry niet bereikbaar is.

Instellingen per site, als constante in `wp-config.php`:

| Constante | Standaard | Doel |
|---|---|---|
| `CONVERSAL_ADMIN_REGISTRY` | uit de build | Andere registry-URL, bv. om te testen |
| `CONVERSAL_ADMIN_REGISTRY_TOKEN` | uit de build | Ander read-only token |
| `CONVERSAL_ADMIN_CHANNEL` | `latest` | `beta` om pre-releases te volgen (testsites) |
| `CONVERSAL_ADMIN_AUTO_UPDATE` | `true` | `false`: updates alleen tonen, niet automatisch installeren. Kritieke updates gaan altijd door. |

Automatische installatie werkt alleen als WordPress bestanden mag schrijven (geen `DISALLOW_FILE_MODS`, geen FTP-gegevens nodig) en WP-cron draait.

### Compatibiliteit met oudere plugins

Bij activatie, en daarna bij elke admin-paginalading, deactiveert Conversal Admin deze plugins met een melding:
`conversal-backend`, `conversal-backend-old`, `conversal-admin-styling`, `conversal-backend-plugin-new`.

---

## Uitbreiden via hooks

| Filter | Doel |
|---|---|
| `conversal_admin/services` | Lijst van services (features) die geladen worden: aanvullen of uitschakelen |
| `conversal_admin/menu_items` | Menu-items Support, Handleidingen en Status aanpassen |
| `conversal_admin/widget_urls` | Bron-URL's van de dashboardwidgets aanpassen |

Voorbeeld: de Facebook-widget op één site andere inhoud geven.

```php
add_filter( 'conversal_admin/widget_urls', function ( array $urls ): array {
	$urls['facebook_page'] = 'https://www.facebook.com/andere-pagina';
	return $urls;
} );
```

---

## Changelog

Zie [CHANGELOG.md](CHANGELOG.md).

# Changelog

## 3.0.4

- On WordPress 6.x, every place where core hardcodes its blue (links, buttons, focus rings, checkboxes, list tables, media library, Customizer and more) uses the Conversal theme color. WordPress 7.0+ already does this itself, so the extra stylesheets only load below 7.0.
- The Customizer uses the Conversal theme color on every WordPress version.
- Active plugins on the Plugins screen are tinted in Conversal teal on WordPress 6.x as well; before 7.0, WordPress hardcoded blue there.
- Notification bubbles in the admin menu (for example the update count next to Plugins) stay visible in mint on the current and hovered menu item; they used to blend into the menu background.

## 3.0.3

- Legacy Conversal Backend plugins are also detected and deactivated when they were installed from a GitHub archive into a versioned folder (such as `conversal-backend-2.6.0.2/`), and when they are network-activated on multisite.

## 3.0.2

- The login screen follows the new Conversal login design: Conversal wordmark, a card with the title "Log in to <site>", error messages inside the card, and the links, privacy link and language switcher below it, in Plus Jakarta Sans (bundled, no Google Fonts).
- Light and dark mode on the login screen. By default it follows the system setting; a button at the top right switches, and the browser remembers that choice.

## 3.0.1

- Requires PHP 7.4 instead of 8.1, so older client sites can run the plugin.
- Development checkouts (a plugin folder with `.git`) are never updated, so a local working copy cannot be overwritten.
- The "View details" modal shows the changelog from the release itself; README.md is now the package page on Verdaccio and GitHub.
- Package metadata (description, author) updated.

## 3.0.0

- Complete rewrite as `conversal-admin` (namespaced PHP 8.1, `@wordpress/scripts` build, WPCS + PHPStan).
- New Conversal branding from the brand book: admin color scheme, login screen, admin bar, footer, favicon, dashboard widgets.
- Feature parity with Conversal Backend 2.6.0.3, with these fixes:
  - color scheme CSS now matches the body class;
  - welcome panel removal works;
  - login logo links to the site;
  - no runaway timers in admin JS.
- Automatically deactivates the legacy Conversal Backend plugin and earlier restyling attempts.
- Updates from the private Verdaccio registry (`@conversal/conversal-admin`): shown on the Plugins screen, installed by the WordPress auto-updater, with sha512 integrity checks. Releases tagged `critical` are installed on every site within about 15 minutes.

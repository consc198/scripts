=== Conversal Admin ===
Contributors: conversal
Tags: admin, branding, dashboard
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 3.0.4
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Conversal-branded WordPress admin experience for Conversal clients.

== Description ==

* Conversal admin color scheme (enforced for all users)
* Branded login screen, admin bar, footer and favicon
* Conversal dashboard widgets (Welcome, In the spotlight, Facebook), managed remotely on tools.conversal.be
* Support, Manuals and Status menu links
* Replaces and deactivates the legacy "Conversal Backend" plugin

== Changelog ==

= 3.0.1 =
* Requires PHP 7.4 instead of 8.1.
* Development checkouts (a plugin folder with .git) are never updated.
* The "View details" modal shows the changelog of the release.

= 3.0.0 =
* Complete rewrite on a modern plugin boilerplate with the new Conversal brand.
